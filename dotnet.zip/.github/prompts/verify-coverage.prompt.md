---
description: "Self-verify completeness: run the Definition of Done, orphan reports, and update the dashboard"
agent: agent
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "findTestFiles", "problems", "fetch", "editFiles"]
argument-hint: "targetModule e.g. ORD  (or 'all' for the whole spec set)"
---

# Task: Verify coverage & prove completeness

This is the quality gate that turns "I think it's done" into provable coverage. Follow
`.github/copilot-instructions.md`. **Read‑only** (you only update `specs/` Markdown).

## Steps for `${input:targetModule}`
1. **Definition of Done** — verify, citing counts:
   - Every `.aspx`/`.ascx` in the module has a `SCR-` spec (N pages / N specs).
   - Every code‑behind event handler is traced to a `UC` or `BR`, or marked `[DEAD-CODE?]`.
   - Every public BLL/service method is traced to ≥1 rule or `[DEAD-CODE?]`.
   - Every EF entity & property is in the data dictionary.
   - Every validator, every authorization check, and every stored proc/raw SQL → a rule or doc reference.
   - Every `BR` has citation + Confidence + Status + Enforcement layer.
2. **Orphan reports** — list: rules with no requirement, requirements with no rule, screens with no use case,
   entities with no rule. Each orphan is a gap to resolve or justify.
3. **Dangling‑ID check** — every referenced `BR-/UC-/SCR-/ENT-/PRC-` ID exists.
4. **Confidence/status rollup** — count Confirmed / Assumed / Needs‑business‑input / Dead‑code.

## Output
- Update the module's Definition‑of‑Done checklist and the **coverage dashboard** in `specs/00-index.md`
  (artifact inventory ✅/⚠/🚫, % confirmed, % needs‑input, DoD ✅/⛔).
- Ensure every `[NEEDS-BUSINESS-INPUT]` is consolidated in `specs/cross-cutting/13-open-questions.md`.
- Report the orphan list and any DoD box that is **not** yet checked, with the exact files still uncovered.
A module is **Done** only when every artifact row is ✅ or explicitly justified and all DoD boxes are checked.
