---
applyTo: "**/mapper/**/*.java,**/*Mapper.java"
description: "MapStruct conventions"
---

- `@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.ERROR, nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS)`.
- Records as targets: rely on canonical-constructor mapping; do NOT generate or use builders for record targets.
- `@Mapping(source = "...", target = "...")` for every field — implicit name-based mapping is acceptable only when name and type match exactly.
- Cross-type conversions go in `@Named` helper methods on the same mapper or on a shared `CommonConversions` class — never inline.
- One mapper per (sourceType, targetType) pair. Do not mix multiple direction pairs in one mapper unless they share helpers.
- Generated impls live in `target/generated-sources/annotations/` and are gitignored.
- Test every mapper: build a fully-populated source, map it, assert every target field. AssertJ `recursivelyEqualTo` is acceptable when shapes match.
- Hand-written mapping is fine for 1–2 fields; reach for MapStruct when there are ≥3 fields, conversions, or nested mapping.
- See `docs/snippets/MapStructRecordMapperExample.java`.
