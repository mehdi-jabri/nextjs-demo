---
name: api-integration
description: Expert knowledge for $fetch, useFetch, and tRPC type-safe API integrations. Use when implementing API calls, server communication, or building type-safe client-server interfaces.
---

# API Integration Skill (Nuxt 4)

## Nuxt 4 Data Fetching Changes

### Key Differences from Nuxt 3
- **Singleton pattern**: Same key shares `data`, `error`, `status` refs
- **Shallow reactivity**: `data` is `shallowRef` by default (use `deep: true` if needed)
- **Default values**: `data`/`error` default to `undefined` (not `null`)
- **Reactive keys**: Use getters for auto-refetching
- **getCachedData context**: Now receives `ctx.cause` for request type

## Nuxt $fetch Patterns

### Basic Usage
```typescript
// GET request
const users = await $fetch<User[]>('/api/users')

// POST request
const newUser = await $fetch<User>('/api/users', {
  method: 'POST',
  body: {
    name: 'John Doe',
    email: 'john@example.com',
  },
})

// With query parameters
const filtered = await $fetch<User[]>('/api/users', {
  query: {
    role: 'admin',
    active: true,
  },
})

// With headers
const data = await $fetch('/api/protected', {
  headers: {
    Authorization: `Bearer ${token}`,
  },
})
```

### Error Handling
```typescript
try {
  const result = await $fetch('/api/resource')
} catch (error) {
  if (error instanceof FetchError) {
    // Handle specific HTTP errors
    switch (error.statusCode) {
      case 400:
        console.error('Validation error:', error.data)
        break
      case 401:
        navigateTo('/login')
        break
      case 403:
        throw createError({ statusCode: 403, message: 'Access denied' })
      case 404:
        throw createError({ statusCode: 404, message: 'Not found' })
      default:
        console.error('API error:', error.message)
    }
  }
}
```

### Custom $fetch Wrapper
```typescript
// composables/useApi.ts
interface ApiOptions extends RequestInit {
  query?: Record<string, any>
}

export function useApi() {
  const config = useRuntimeConfig()
  const { data: session } = useAuth()

  async function api<T>(endpoint: string, options: ApiOptions = {}): Promise<T> {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...options.headers,
    }

    // Add auth token if authenticated
    if (session.value?.user) {
      headers.Authorization = `Bearer ${session.value.accessToken}`
    }

    try {
      return await $fetch<T>(endpoint, {
        baseURL: config.public.apiBase,
        ...options,
        headers,
      })
    } catch (error) {
      // Global error handling
      if (error instanceof FetchError && error.statusCode === 401) {
        await refreshToken()
        // Retry request
        return api<T>(endpoint, options)
      }
      throw error
    }
  }

  return {
    get: <T>(url: string, options?: ApiOptions) => api<T>(url, { ...options, method: 'GET' }),
    post: <T>(url: string, body: any, options?: ApiOptions) => api<T>(url, { ...options, method: 'POST', body }),
    put: <T>(url: string, body: any, options?: ApiOptions) => api<T>(url, { ...options, method: 'PUT', body }),
    patch: <T>(url: string, body: any, options?: ApiOptions) => api<T>(url, { ...options, method: 'PATCH', body }),
    delete: <T>(url: string, options?: ApiOptions) => api<T>(url, { ...options, method: 'DELETE' }),
  }
}
```

## useFetch & useAsyncData (Nuxt 4)

### useFetch (Recommended for Simple Cases)
```vue
<script setup lang="ts">
// Basic fetch with auto-typing - data is shallowRef in Nuxt 4
const { data: users, pending, error, refresh, status } = await useFetch<User[]>('/api/users')

// Check for undefined (Nuxt 4 default, not null)
if (users.value === undefined) {
  // Data not yet loaded
}

// With options - use deep: true if mutating data properties
const { data: posts } = await useFetch<Post[]>('/api/posts', {
  query: { limit: 10 },
  pick: ['id', 'title'], // Only pick specific fields
  transform: (data) => data.map(post => ({ ...post, slug: slugify(post.title) })),
  default: () => [], // Default value (used when clearing too)
  deep: true, // Enable deep reactivity if you modify nested properties
})

// Lazy fetch (doesn't block navigation)
const { data, pending } = useLazyFetch('/api/slow-endpoint')

// Reactive parameters with getter keys (Nuxt 4)
const page = ref(1)
const { data } = await useFetch(
  () => `/api/posts?page=${page.value}`, // Getter as URL
  {
    key: () => `posts-page-${page.value}`, // Getter as key - auto refetches
    watch: [page], // Also watch for changes
  }
)
</script>
```

### useAsyncData (For Complex Logic)
```vue
<script setup lang="ts">
// Custom async function - singleton behavior (same key shares refs)
const { data: dashboard } = await useAsyncData('dashboard', async () => {
  const [users, posts, stats] = await Promise.all([
    $fetch<User[]>('/api/users'),
    $fetch<Post[]>('/api/posts'),
    $fetch<Stats>('/api/stats'),
  ])
  
  return { users, posts, stats }
})

// IMPORTANT: Extract shared data fetching to composables
// to ensure consistent options for same key
function usePostData(postId: MaybeRef<string>) {
  return useAsyncData(
    () => `post-${unref(postId)}`,
    () => $fetch<Post>(`/api/posts/${unref(postId)}`),
    { deep: true } // Keep options consistent
  )
}

// getCachedData with Nuxt 4 context
const { data } = await useAsyncData('cached-data', fetchData, {
  getCachedData: (key, nuxtApp, ctx) => {
    // ctx.cause: 'initial' | 'refresh:hook' | 'refresh:manual' | 'watch'
    if (ctx.cause === 'refresh:manual') return undefined // Force refetch
    return nuxtApp.payload.data[key]
  }
})
</script>
```

### Refresh Patterns
```vue
<script setup lang="ts">
const { data, refresh, status } = await useFetch('/api/data')

// Manual refresh
async function handleRefresh() {
  await refresh()
}

// Auto-refresh interval
const intervalId = setInterval(refresh, 30000)
onUnmounted(() => clearInterval(intervalId))

// Refresh on window focus
useEventListener('focus', refresh)
</script>
```

## Server API Routes

### Basic Handlers
```typescript
// server/api/users/index.get.ts
export default defineEventHandler(async (event) => {
  const query = getQuery(event)
  const users = await prisma.user.findMany({
    where: query.role ? { role: query.role as string } : undefined,
    take: Number(query.limit) || 10,
  })
  return users
})

// server/api/users/index.post.ts
export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  const user = await prisma.user.create({ data: body })
  return user
})

// server/api/users/[id].get.ts
export default defineEventHandler(async (event) => {
  const id = getRouterParam(event, 'id')
  const user = await prisma.user.findUnique({ where: { id } })
  
  if (!user) {
    throw createError({ statusCode: 404, message: 'User not found' })
  }
  
  return user
})

// server/api/users/[id].patch.ts
export default defineEventHandler(async (event) => {
  const id = getRouterParam(event, 'id')
  const body = await readBody(event)
  
  const user = await prisma.user.update({
    where: { id },
    data: body,
  })
  
  return user
})

// server/api/users/[id].delete.ts
export default defineEventHandler(async (event) => {
  const id = getRouterParam(event, 'id')
  await prisma.user.delete({ where: { id } })
  return { success: true }
})
```

### Server Middleware
```typescript
// server/middleware/auth.ts
export default defineEventHandler(async (event) => {
  const protectedRoutes = ['/api/admin', '/api/user']
  const isProtected = protectedRoutes.some(route => 
    event.path.startsWith(route)
  )
  
  if (isProtected) {
    const session = await getServerSession(event)
    if (!session) {
      throw createError({ statusCode: 401, message: 'Unauthorized' })
    }
    event.context.session = session
  }
})
```

### Server Utilities
```typescript
// server/utils/db.ts
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export default prisma

// server/utils/validate.ts
import { z } from 'zod'

export async function validateBody<T>(
  event: H3Event, 
  schema: z.ZodSchema<T>
): Promise<T> {
  const body = await readBody(event)
  const result = schema.safeParse(body)
  
  if (!result.success) {
    throw createError({
      statusCode: 400,
      message: 'Validation failed',
      data: result.error.flatten(),
    })
  }
  
  return result.data
}
```

## tRPC Integration

### Setup
```bash
npm install @trpc/server @trpc/client trpc-nuxt zod
```

### Server Setup
```typescript
// server/trpc/trpc.ts
import { initTRPC, TRPCError } from '@trpc/server'
import type { H3Event } from 'h3'
import superjson from 'superjson'

export interface Context {
  event: H3Event
  session: Session | null
}

const t = initTRPC.context<Context>().create({
  transformer: superjson,
})

export const router = t.router
export const publicProcedure = t.procedure

export const protectedProcedure = t.procedure.use(({ ctx, next }) => {
  if (!ctx.session) {
    throw new TRPCError({ code: 'UNAUTHORIZED' })
  }
  return next({
    ctx: { ...ctx, session: ctx.session },
  })
})
```

### Router Definition
```typescript
// server/trpc/routers/user.ts
import { z } from 'zod'
import { router, publicProcedure, protectedProcedure } from '../trpc'

export const userRouter = router({
  list: publicProcedure
    .input(z.object({
      limit: z.number().min(1).max(100).default(10),
      cursor: z.string().optional(),
    }))
    .query(async ({ input }) => {
      const users = await prisma.user.findMany({
        take: input.limit + 1,
        cursor: input.cursor ? { id: input.cursor } : undefined,
      })
      
      let nextCursor: string | undefined
      if (users.length > input.limit) {
        const nextItem = users.pop()
        nextCursor = nextItem?.id
      }
      
      return { users, nextCursor }
    }),

  byId: publicProcedure
    .input(z.object({ id: z.string() }))
    .query(async ({ input }) => {
      const user = await prisma.user.findUnique({
        where: { id: input.id },
      })
      if (!user) {
        throw new TRPCError({ code: 'NOT_FOUND' })
      }
      return user
    }),

  create: protectedProcedure
    .input(z.object({
      name: z.string().min(1),
      email: z.string().email(),
    }))
    .mutation(async ({ input, ctx }) => {
      return prisma.user.create({
        data: {
          ...input,
          createdBy: ctx.session.user.id,
        },
      })
    }),

  update: protectedProcedure
    .input(z.object({
      id: z.string(),
      name: z.string().min(1).optional(),
      email: z.string().email().optional(),
    }))
    .mutation(async ({ input }) => {
      const { id, ...data } = input
      return prisma.user.update({ where: { id }, data })
    }),

  delete: protectedProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      await prisma.user.delete({ where: { id: input.id } })
      return { success: true }
    }),
})
```

### App Router
```typescript
// server/trpc/routers/index.ts
import { router } from '../trpc'
import { userRouter } from './user'
import { postRouter } from './post'

export const appRouter = router({
  user: userRouter,
  post: postRouter,
})

export type AppRouter = typeof appRouter
```

### API Handler
```typescript
// server/api/trpc/[trpc].ts
import { createNuxtApiHandler } from 'trpc-nuxt'
import { appRouter } from '~/server/trpc/routers'
import { createContext } from '~/server/trpc/context'

export default createNuxtApiHandler({
  router: appRouter,
  createContext,
})
```

### Client Usage
```typescript
// plugins/trpc.ts
import { createTRPCNuxtClient, httpBatchLink } from 'trpc-nuxt/client'
import type { AppRouter } from '~/server/trpc/routers'

export default defineNuxtPlugin(() => {
  const client = createTRPCNuxtClient<AppRouter>({
    links: [
      httpBatchLink({
        url: '/api/trpc',
      }),
    ],
  })

  return {
    provide: { trpc: client },
  }
})

// In components
const { $trpc } = useNuxtApp()

// Query
const { data: users } = await $trpc.user.list.useQuery({ limit: 20 })

// Mutation
const createUser = $trpc.user.create.useMutation()
await createUser.mutateAsync({ name: 'John', email: 'john@example.com' })
```

## Best Practices

1. **Type everything** - Use generics with $fetch
2. **Centralize API logic** - Use composables or tRPC
3. **Handle errors consistently** - Global error handling
4. **Use proper HTTP methods** - GET, POST, PATCH, DELETE
5. **Validate inputs** - Server-side with Zod
6. **Cache appropriately** - useFetch caches by default
7. **Use server utilities** - Share validation, DB access
8. **Implement retry logic** - For transient failures
