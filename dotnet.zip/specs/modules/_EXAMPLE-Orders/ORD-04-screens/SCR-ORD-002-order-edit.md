# Screen Spec — SCR-ORD-002: Order Edit  ⭐ EXAMPLE

> Fictional reference. Target‑agnostic. Back to [module index](../ORD-00-module-index.md).

- **Source page:** `OrderEdit.aspx` · **Code-behind:** `OrderEdit.aspx.cs` · **Master:** `Site.Master`
- **URL / route:** `OrderEdit.aspx?orderId={id}&mode={new|edit}`
- **Actors with access:** Sales, Admin (see [D10](../../../cross-cutting/10-security-authorization.md)) ·
  **Authorization source:** `web.config:<location path="Orders">`; `OrderEdit.aspx.cs:Page_Load:42`
- **Related use cases:** UC-ORD-001, UC-ORD-003 · **Related rules:** BR-ORD-001/002/005/010/011 ·
  **Related entities:** ENT-Order, ENT-OrderLine
- **Confidence:** High · **Status:** Confirmed

## Purpose
Lets a salesperson build, edit, save, and place a customer order with its product lines.

## Layout / wireframe (textual)
Header (order no, customer dropdown, status) · Lines grid (product, qty, unit price, discount, subtotal,
remove) · Add-line panel · Footer (total, **Save Draft**, **Place Order**, **Cancel**).

## Controls inventory
| Control ID | Label | Type | Bound field (D6) | Required? | Validation rules | Default | Visible/Enabled when | Source (file:line) |
|---|---|---|---|---|---|---|---|---|
| ddlCustomer | Customer | DropDownList | Order.CustomerId | Yes | must be selected | (none) | always | `OrderEdit.aspx:30`; `.cs:60` |
| gvLines | Lines | GridView | OrderLine[] | — | — | — | always | `OrderEdit.aspx:44` |
| txtQty | Qty | TextBox | OrderLine.Quantity | Yes | integer > 0 (BR-ORD-002) | — | add/edit line | `OrderEdit.aspx:62` |
| txtDiscount | Discount | TextBox | OrderLine.DiscountRate | No | 0..0.5 (BR-ORD-011) | 0 | add/edit line | `OrderEdit.aspx:70` |
| lblTotal | Total | Label | Order.Total | — | display only (BR-ORD-010) | 0.00 | always | `OrderEdit.aspx:90` |
| btnSave | Save Draft | Button | — | — | CausesValidation=false | — | role Sales/Admin | `.cs:110` |
| btnPlace | Place Order | Button | — | — | triggers full validation (BR-ORD-001/005/015) | — | role Sales/Admin | `.cs:180` |

## Actions / buttons
| Action | Trigger | Behavior | Rules | Navigates to | Source |
|---|---|---|---|---|---|
| Add line | btnAddLine click | Validates qty>0; computes subtotal; re-binds grid; recomputes total | BR-ORD-002, BR-ORD-011, BR-ORD-010 | (same page) | `.cs:120-148` |
| Remove line | gvLines RowCommand "Remove" | Removes line; recomputes total | BR-ORD-010 | (same page) | `.cs:150` |
| Save Draft | btnSave click | Persists as Draft (skips full validation) | BR-ORD-010 | OrderList.aspx | `.cs:110` |
| Place Order | btnPlace click | Full validation + reserve stock + status=Placed | BR-ORD-001/005/015 | OrderList.aspx | `.cs:180-205` |

## Field-level validation detail
| Field | Rule | Message shown | Server/Client | Source |
|---|---|---|---|---|
| ddlCustomer | required to place | "Select a customer" | Server (BR-ORD-005) | `.cs:48` |
| txtQty | integer > 0 | "Quantity must be greater than zero" | Both (RangeValidator + server) | `OrderEdit.aspx:62`; `.cs:130` |
| txtDiscount | 0..0.5 | "Discount must be between 0 and 50%" | Client only (`CompareValidator`) `[CONFLICT]` no server check | `OrderEdit.aspx:70` |

## Navigation in / out
```mermaid
flowchart LR
  List[SCR-ORD-001 Order List] -->|New / Edit| This[SCR-ORD-002 Order Edit]
  This -->|Save / Place / Cancel| List
```

## Conditional UI / dynamic behavior
- When `mode=new`, status is forced to Draft and the **Place Order** button is enabled only after at least one
  line exists — Source: `.cs:72-78` — Rule: relates to UC-ORD-003.

## State used
| Key | Store | Set when | Read when | Supports rule |
|---|---|---|---|---|
| `ViewState["Lines"]` | ViewState | on add/remove line | on postback / save | line editing across postbacks |
| `Session["ReturnUrl"]` | Session | on entry | on save/cancel | return navigation |

## Open questions
- [NEEDS-BUSINESS-INPUT] Discount cap (50%) is enforced **client-side only**; is it a real business limit and
  should it be enforced server-side? (Q-014)

## Developer Notes (legacy)
`gvLines` is bound in `!IsPostBack` and re-bound after each add/remove; line working-set held in
`ViewState["Lines"]` (`.cs:200`). `btnSave` sets `CausesValidation=false` to allow saving incomplete drafts.
> Target‑stack (Vue) rebuild guidance is in
> [../../../migration/_EXAMPLE-ORD-migration-notes.md](../../../migration/_EXAMPLE-ORD-migration-notes.md).
