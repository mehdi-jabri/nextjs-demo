# TEMPLATE — Process / Workflow Specification

> One `PRC-<MOD>-NNN` per cross-screen process, lifecycle, or batch job, in `*-07-processes.md`.
> See `_EXAMPLE-Orders/ORD-07-processes.md`.

```
# Process Spec — PRC-<MOD>-NNN: <process name>
- **Type:** User workflow | Scheduled/Batch | Event-driven
- **Trigger:** <user action | schedule (cron/Windows task) | message>
- **Source:** <scheduler config / Global.asax / service class file:line>
- **Related UCs / rules:** UC-… / BR-…
- **Confidence:** … · **Status:** …

## Narrative
<Plain-language end-to-end description.>

## State machine (for lifecycle processes)
```mermaid
stateDiagram-v2
  [*] --> StateA
  StateA --> StateB: event (BR-…)
  StateB --> [*]
```
| Transition | From | To | Guard / condition | Rule | Source |
|---|---|---|---|---|---|
| | | | | BR-… | <file:line> |

## Sequence (for multi-component flows)
```mermaid
sequenceDiagram
  actor U as User
  U->>Web: action
  Web->>BLL: method()
  BLL->>DB: persist
  BLL-->>Web: result
```

## Scheduling / batch detail (if applicable)
| Job | Frequency | Schedule source | What it does | Rules | Source |
|---|---|---|---|---|---|

## Developer Notes (legacy)
<legacy implementation detail>
```
> Target‑stack rebuild guidance lives only in `specs/migration/` (via `/migration-notes`).
