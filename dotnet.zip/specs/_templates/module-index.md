# TEMPLATE — Module Index

> One per module: `specs/modules/<MOD>/<MOD>-00-module-index.md`. The module's local table of contents,
> Definition of Done, and confidence rollup. See `_EXAMPLE-Orders/ORD-00-module-index.md`.

```
# Module <MOD> — <Module name>
- **Status:** Not started | In Progress | In Review | Confirmed
- **Last updated:** <date> · **Source snapshot:** <commit/label> · Back to [index](../../00-index.md)

## Capability overview
<One plain-language paragraph: what this module does for the business.>

## Documents
- Use cases: [<MOD>-03-use-cases.md](<MOD>-03-use-cases.md)
- Business rules: [<MOD>-05-business-rules.md](<MOD>-05-business-rules.md)
- Data dictionary: [<MOD>-06-data-dictionary.md](<MOD>-06-data-dictionary.md)
- Processes: [<MOD>-07-processes.md](<MOD>-07-processes.md)
- Screens: [<MOD>-04-screens/](<MOD>-04-screens/)

## Definition of Done (check every box before "Confirmed")
- [ ] Every .aspx/.ascx in the module has a SCR- spec (count: N / N)
- [ ] Every code-behind event handler traced to a UC or BR, or marked [DEAD-CODE?]
- [ ] Every public BLL/service method traced to ≥1 rule or [DEAD-CODE?]
- [ ] Every EF entity & property in the data dictionary
- [ ] Every validator → a BR
- [ ] Every authorization check → D10 + BR-SEC
- [ ] Every stored proc / raw SQL referenced → described
- [ ] Every BR has citation, confidence, status, enforcement layer
- [ ] No dangling IDs in the traceability matrix
- [ ] All [NEEDS-BUSINESS-INPUT] consolidated into D13
- [ ] Coverage row in 00-index.md updated

## Confidence & status rollup
| | Confirmed | Assumed | Needs-input | Dead-code? |
|---|---|---|---|---|
| Rules | | | | |
| Use cases | | | | |
```
