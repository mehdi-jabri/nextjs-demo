# Active Tasks

## Sprint Overview

**Sprint Goal**: [Define the sprint objective]
**Sprint Duration**: [Start Date] - [End Date]

---

## 🔴 Blocked

| ID | Task | Agent | Blocked By | Days Blocked |
|----|------|-------|------------|--------------|
| - | - | - | - | - |

---

## 🟡 In Progress

| ID | Task | Agent | Priority | Progress | Started |
|----|------|-------|----------|----------|---------|
| - | - | - | - | - | - |

---

## 🟢 Ready (Next Up)

| ID | Task | Agent | Priority | Dependencies | Estimate |
|----|------|-------|----------|--------------|----------|
| - | - | - | - | - | - |

---

## ✅ Completed (This Sprint)

| ID | Task | Agent | Completed | Notes |
|----|------|-------|-----------|-------|
| - | - | - | - | - |

---

## Task Priority Legend

- **🔴 Critical**: Blockers, security issues, production bugs
- **🟠 High**: Core features, customer-facing issues
- **🟡 Medium**: Improvements, non-blocking features
- **🟢 Low**: Nice-to-haves, refactoring

## Agent Assignment Guide

| Agent | Best For |
|-------|----------|
| `frontend-architect` | Architecture, structure, technical decisions |
| `component-developer` | UI components, shadcn-vue, accessibility |
| `feature-implementer` | Full features, API to UI, forms |
| `debugger` | Bug fixes, performance, error resolution |
| `project-orchestrator` | Planning, coordination, tracking |

---

## Notes

- Update this file daily during active development
- Move blocked items back to Ready once unblocked
- Reference task IDs in commit messages (e.g., "T-001: Add login form")
- Link related requirements from `docs/requirements/`

---

## How to Use

### Adding a New Task
```markdown
| T-XXX | Brief task description | agent-name | high | None | 2h |
```

### Moving Task to In Progress
1. Move row from Ready to In Progress
2. Add Started date
3. Add Progress percentage

### Completing a Task
1. Move row to Completed
2. Add Completed date
3. Add any relevant Notes

### Blocking a Task
1. Move row to Blocked section
2. Document what's blocking it
3. Create action item to unblock
