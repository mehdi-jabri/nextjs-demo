---
description: "Add a new HTTP client using @HttpServiceClient (Boot 4)"
mode: agent
---

Follow `.github/copilot-instructions.md`. Use the Boot 4 `@HttpServiceClient` interface pattern, NOT hand-rolled `RestClient`.

## Bucket: YELLOW. Diff must be reviewed before merge.

## Inputs (ask if missing)

- Target service name and base URL property key.
- One operation to scaffold (method, path, request, response).
- Auth: bearer token from current security context, static API key from Key Vault, or none.
- Resilience: timeouts, retry policy, circuit-breaker name.

## Steps

1. Read `docs/snippets/HttpServiceClientExample.java` and follow the pattern.
2. Create the client interface at `<<org>>.<<service-name>>.infrastructure.http.<<vendor>>.<<Vendor>>Client`:
   - `@HttpServiceClient(name = "<<vendor>>")` (or rely on package scanning).
   - One method per operation, request/response are records.
   - JSpecify `@Nullable` on optional inputs.
3. Register the client (only if package scanning is not configured): add `@ImportHttpServices(...)` on `HttpClientsConfig`.
4. Bind the base URL via `@ConfigurationProperties("<<org-prefix>>.<<service-name>>.<<vendor>>.client")` — `baseUrl`, `connectTimeout`, `readTimeout`.
5. Configure Resilience4j: `<<vendor>>` circuit-breaker block in `application.yml` (`resilience4j.circuitbreaker.instances.<<vendor>>.*`) plus `@CircuitBreaker(name = "<<vendor>>")` on the gateway/adapter that USES the client (not on the client interface itself).
6. Add a Mockito unit test for the gateway/adapter that consumes the client. Mock the client interface; verify the adapter translates between domain and DTO correctly.
7. Document the new property prefix in `README.md` § Configuration.

## Banned

- Hand-rolled `RestClient.create()` calls in services.
- `RestTemplate`.
- Hardcoded URLs.
- Real network calls in tests.
