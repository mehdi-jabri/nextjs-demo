# TEMPLATE — Non-Functional Requirement row

> Append rows to `cross-cutting/11-non-functional.md`. Categories to always probe: Performance, Volume/scale,
> Concurrency, Retention/archival, Audit/logging, Localization/i18n, Availability, Compliance, Browser support.

```
| NFR-<CAT>-NNN | <category> | <requirement, observed or implied> | <evidence file:line or [UNVERIFIED]> | High/Medium/Low | Confirmed/Assumed/Needs-business-input |
```
