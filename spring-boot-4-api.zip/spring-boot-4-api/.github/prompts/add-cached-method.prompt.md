---
description: "Add a @Cacheable method with explicit key, TTL, eviction test"
mode: agent
---

Follow `.github/copilot-instructions.md`.

## Bucket

- GREEN if reusing an existing cache name and TTL.
- YELLOW if introducing a new cache name → review the diff.
- RED if changing TTL or eviction policy on an existing cache → plan only.

## Inputs (ask if missing)

- Method to cache (path / signature).
- Cache key (must be derivable from method args; explicit `key = "#argName"` SpEL).
- Cache name (existing or new).
- TTL (only if introducing a new cache).
- Eviction triggers — which mutation methods invalidate this cache and how.

## Steps

1. Read `docs/snippets/RedisCacheConfigExample.java` and the existing `RedisCacheConfiguration` in this repo.
2. Apply `@Cacheable(value = "<<cacheName>>", key = "#<<arg>>")` on the method. Add `unless = "#result == null"` if `null` results should not be cached.
3. If the cache name is new, register a `RedisCacheConfiguration` entry for it in the existing `RedisConfig` bean — explicit TTL, explicit serializer, explicit `disableCachingNullValues()` if appropriate.
4. Add `@CacheEvict` (or `@CachePut`) on every mutation method that invalidates this entry. Be precise — `allEntries = true` is rarely correct.
5. Generate a unit test:
   - Verify `@Cacheable` is present and the key SpEL is correct (string-match on the annotation via reflection or use `MockingDetails`).
   - Verify the eviction methods are annotated correctly.
   - Behavioural caching tests require a Spring context — out of scope for this iteration; flag and skip.
6. Document the new cache name + TTL in `README.md` § Caching.

## Banned

- Global cache TTL.
- `@Cacheable` without an explicit key on methods with > 1 argument.
- Caching results that contain `Authentication`, raw entities, or PII.
