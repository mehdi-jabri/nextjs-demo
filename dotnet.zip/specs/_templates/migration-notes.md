# TEMPLATE — Migration Notes (DEV-ONLY rebuild guidance)

> One per module: `specs/migration/<MOD>-migration-notes.md`. **This is the only place target‑stack content
> (Spring Boot + Vue + PostgreSQL) is allowed.** It is advisory guidance for developers, produced by
> `/migration-notes` **after** the module's English spec is `Confirmed`. Reference spec items by **ID** and
> citation — do not restate business behavior here. See `specs/migration/_EXAMPLE-ORD-migration-notes.md`.

```
# Migration Notes — Module <MOD> (<Module name>)
- **Audience:** developers only · **Source spec:** ../modules/<MOD>/ (Confirmed) · **Status:** Draft
- Back to [migration index](00-migration-index.md)

## Data → PostgreSQL + JPA
| Entity (ENT) | Target table | Notable column mappings (SQL Server → PostgreSQL) | Keys / identity | Optimistic lock | Cascades |
|---|---|---|---|---|---|
| ENT-… | | decimal(18,2)→numeric(18,2); datetime2→timestamp; bit→boolean | identity→GENERATED AS IDENTITY | rowversion→version int/xmin | |

## Rules → Spring Boot
| Rule/UC | Where it belongs (controller/service/validator/domain) | Notes (transaction, re-implement server-side?) |
|---|---|---|
| BR-…/UC-… | service | client-only legacy validator → MUST be enforced server-side |

## Screens → Vue
| Screen (SCR) | Suggested view/components | Client vs server validation | Routing / state (replaces ViewState/Session) |
|---|---|---|---|
| SCR-… | | | |

## Integrations / jobs / reports → target equivalents
| Item (INT/PRC/RPT) | Target approach | Notes |
|---|---|---|

## Risks & anti-patterns to avoid in the rebuild
- Lazy-loading N+1 (EF navigation access) — design explicit fetch/joins.
- `DateTime.Now` (server local) vs. UTC — decide time-zone strategy (see BR-… ).
- Midpoint rounding: legacy uses MidpointRounding.AwayFromZero; Java/PG default differs — replicate explicitly.
- Soft-delete filters must be applied consistently (legacy did so per-repository).

## Open assumptions
- [ASSUMPTION] / [NEEDS-BUSINESS-INPUT] <…>
```
