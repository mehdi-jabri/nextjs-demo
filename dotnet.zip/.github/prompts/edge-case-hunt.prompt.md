---
description: "Sweep the whole codebase for easy-to-miss hidden rules (run after the per-module passes)"
agent: agent
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "findTestFiles", "problems", "fetch", "editFiles"]
argument-hint: "(no argument needed — runs each trap as a search across the solution)"
---

# Task: Edge-case & hidden-rule hunt

Run each of the following as an **explicit search across the whole codebase**; anything found that is not already
captured becomes a new rule/open question. Follow `.github/copilot-instructions.md`. **Read‑only.**

## Traps to hunt
**Web Forms / UI:** dynamic control creation (`new TextBox()`, `LoadControl`, `Controls.Add`, `CreateChildControls`);
`ViewState[...]`‑dependent logic and `EnableViewState="false"` re‑bind code; hidden fields & `Request.Form`/
`Request.Params`; JavaScript‑only validation/calculation, `OnClientClick` returning false, `UpdatePanel`,
`PageMethods`/`[WebMethod]`/`.asmx`; inline `<%# %>`/`DataBinder.Eval`; cross‑page postback (`PreviousPage`);
base page / master code‑behind; `.resx` messages.

**EF6 / Data:** `SaveChanges`/`SaveChangesAsync` overrides; EF interceptors / `DbConfiguration`; stored procedures,
views, functions, **triggers**; migration `Sql(...)` and `Seed()`; `decimal` precision/scale & rounding for money;
`DateTime` kind/timezone & culture; global query / repository‑level soft‑delete & tenant filters applied inconsistently.

**Cross‑cutting:** AutoMapper `AfterMap`/`BeforeMap`/custom resolvers/`ConvertUsing`; conditional/named Ninject
bindings (feature flags, multi‑tenancy, which impl is live); `Global.asax` application/session events and
`Application_Error`; HttpModules/HttpHandlers; config transforms; multi‑tenancy; feature flags; scheduled jobs /
external runner projects; **dead code** (unbuilt projects, unreachable pages, overridden bindings).

## Also capture Non-Functional Requirements (NFRs)
While sweeping, record any NFRs you encounter into `specs/cross-cutting/11-non-functional.md` (template
`specs/_templates/non-functional.md`), each cited: **Performance** (paging sizes, timeouts, caching),
**Volume/scale**, **Concurrency**, **Retention/archival** (or absence of a purge job), **Audit/logging**,
**Localization/i18n** (culture), **Availability**, **Compliance**, **Browser support**. If none is evident for
a category, note it as `[UNVERIFIED]`/`[NEEDS-BUSINESS-INPUT]`.

## Output
- New rules → the relevant module `BR-` catalog (cited); `[DEAD-CODE?]` items recorded but excluded from "live".
- NFRs → `specs/cross-cutting/11-non-functional.md`.
- Update `specs/00-index.md` artifact inventory (flip remaining `Not started` rows, mark dead code justified) and
  add open questions to `13-open-questions.md`. Report a short summary of what each trap‑search found (or "none").
