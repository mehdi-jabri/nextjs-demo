---
description: "Translate confirmed English business specs into French under specs-fr/ (IDs/citations preserved)"
agent: translator
model: Claude Opus 4.6
tools: ["search", "editFiles"]
argument-hint: "targetModule e.g. ORD  (or 'all' for every Confirmed doc)"
---

# Task: Translate confirmed specs to French

Mirror the **Confirmed** English business documents for `${input:targetModule}` into `specs-fr/`, preserving
structure. English under `specs/` stays the source of truth. Follow `.github/copilot-instructions.md` and the
`translator` agent rules. Write **only** under `specs-fr/`.

## Rules
- Translate only docs whose status is `Confirmed`. Mirror paths: `specs/<path>.md` → `specs-fr/<path>.md`.
- Translate business prose to clear, professional French. **Keep verbatim (do not translate):** IDs
  (`BR-/UC-/SCR-/ENT-/PRC-…`), code identifiers, file paths, `file:line` citations, marker tokens
  (`[NEEDS-BUSINESS-INPUT]` …), enum/column names, and Mermaid diagram code (translate only human labels).
- Preserve headings/tables 1:1 so each FR doc tracks its EN source. Add a top line: `> Source (EN): <relative path>`.
- `## Developer Notes (legacy)` may stay in English, marked `*(left in English for developers)*`.
- Do not invent or "improve" — translate faithfully; keep every marker.
- Do **not** translate `specs/migration/` (dev‑only, stays English) unless explicitly asked.

## Output
The French mirror under `specs-fr/` and an updated `specs-fr/README-fr.md` listing translated docs + the
English snapshot they were translated from.
