---
name: state-management
description: Expert knowledge for Pinia stores and TanStack Query (Vue Query) for state management. Use when implementing global state, server state caching, or data fetching patterns.
---

# State Management Skill

## Pinia Store Patterns

### Basic Store Setup
```typescript
// stores/user.ts
import { defineStore } from 'pinia'

interface User {
  id: string
  name: string
  email: string
  role: 'admin' | 'user'
}

interface UserState {
  user: User | null
  isLoading: boolean
  error: string | null
}

export const useUserStore = defineStore('user', () => {
  // State
  const user = ref<User | null>(null)
  const isLoading = ref(false)
  const error = ref<string | null>(null)

  // Getters
  const isAuthenticated = computed(() => !!user.value)
  const isAdmin = computed(() => user.value?.role === 'admin')
  const fullName = computed(() => user.value?.name ?? 'Guest')

  // Actions
  async function fetchUser() {
    isLoading.value = true
    error.value = null
    try {
      const data = await $fetch<User>('/api/user/me')
      user.value = data
    } catch (e) {
      error.value = e instanceof Error ? e.message : 'Failed to fetch user'
    } finally {
      isLoading.value = false
    }
  }

  function setUser(newUser: User) {
    user.value = newUser
  }

  function clearUser() {
    user.value = null
  }

  // Persist to localStorage (optional)
  if (import.meta.client) {
    const saved = localStorage.getItem('user')
    if (saved) user.value = JSON.parse(saved)
    
    watch(user, (newUser) => {
      if (newUser) {
        localStorage.setItem('user', JSON.stringify(newUser))
      } else {
        localStorage.removeItem('user')
      }
    }, { deep: true })
  }

  return {
    // State
    user: readonly(user),
    isLoading: readonly(isLoading),
    error: readonly(error),
    // Getters
    isAuthenticated,
    isAdmin,
    fullName,
    // Actions
    fetchUser,
    setUser,
    clearUser,
  }
})
```

### Store with Options API (Alternative)
```typescript
// stores/cart.ts
export const useCartStore = defineStore('cart', {
  state: () => ({
    items: [] as CartItem[],
    coupon: null as string | null,
  }),

  getters: {
    totalItems: (state) => state.items.reduce((sum, item) => sum + item.quantity, 0),
    subtotal: (state) => state.items.reduce((sum, item) => sum + item.price * item.quantity, 0),
    discount: (state) => state.coupon ? 0.1 : 0,
    total(): number {
      return this.subtotal * (1 - this.discount)
    },
  },

  actions: {
    addItem(product: Product, quantity = 1) {
      const existing = this.items.find(item => item.productId === product.id)
      if (existing) {
        existing.quantity += quantity
      } else {
        this.items.push({
          productId: product.id,
          name: product.name,
          price: product.price,
          quantity,
        })
      }
    },
    removeItem(productId: string) {
      const index = this.items.findIndex(item => item.productId === productId)
      if (index > -1) this.items.splice(index, 1)
    },
    clearCart() {
      this.items = []
      this.coupon = null
    },
  },
})
```

### Store Composition (Using Other Stores)
```typescript
// stores/checkout.ts
export const useCheckoutStore = defineStore('checkout', () => {
  const cartStore = useCartStore()
  const userStore = useUserStore()

  const canCheckout = computed(() => {
    return userStore.isAuthenticated && cartStore.totalItems > 0
  })

  async function processCheckout(paymentInfo: PaymentInfo) {
    if (!canCheckout.value) {
      throw new Error('Cannot checkout')
    }

    const order = await $fetch('/api/orders', {
      method: 'POST',
      body: {
        items: cartStore.items,
        total: cartStore.total,
        payment: paymentInfo,
      },
    })

    cartStore.clearCart()
    return order
  }

  return { canCheckout, processCheckout }
})
```

## TanStack Query (Vue Query)

### Setup
```typescript
// plugins/vue-query.ts
import { VueQueryPlugin, QueryClient } from '@tanstack/vue-query'

export default defineNuxtPlugin((nuxtApp) => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 1000 * 60 * 5, // 5 minutes
        gcTime: 1000 * 60 * 30, // 30 minutes (formerly cacheTime)
        retry: 1,
        refetchOnWindowFocus: false,
      },
    },
  })

  nuxtApp.vueApp.use(VueQueryPlugin, { queryClient })
})
```

### Basic Query
```vue
<script setup lang="ts">
import { useQuery } from '@tanstack/vue-query'

interface Post {
  id: string
  title: string
  content: string
}

const { data: posts, isLoading, error, refetch } = useQuery({
  queryKey: ['posts'],
  queryFn: () => $fetch<Post[]>('/api/posts'),
})
</script>

<template>
  <div>
    <Button @click="() => refetch()">Refresh</Button>
    
    <div v-if="isLoading">Loading...</div>
    <div v-else-if="error">Error: {{ error.message }}</div>
    <div v-else>
      <article v-for="post in posts" :key="post.id">
        <h2>{{ post.title }}</h2>
        <p>{{ post.content }}</p>
      </article>
    </div>
  </div>
</template>
```

### Query with Parameters
```typescript
// composables/usePost.ts
export function usePost(id: MaybeRef<string>) {
  return useQuery({
    queryKey: ['posts', id],
    queryFn: () => $fetch<Post>(`/api/posts/${toValue(id)}`),
    enabled: computed(() => !!toValue(id)),
  })
}

// Usage
const route = useRoute()
const { data: post } = usePost(() => route.params.id as string)
```

### Mutations
```typescript
// composables/useCreatePost.ts
import { useMutation, useQueryClient } from '@tanstack/vue-query'

interface CreatePostInput {
  title: string
  content: string
}

export function useCreatePost() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: (input: CreatePostInput) =>
      $fetch<Post>('/api/posts', {
        method: 'POST',
        body: input,
      }),
    onSuccess: (newPost) => {
      // Invalidate and refetch posts list
      queryClient.invalidateQueries({ queryKey: ['posts'] })
      
      // Or optimistically update the cache
      queryClient.setQueryData(['posts'], (old: Post[] | undefined) => {
        return old ? [...old, newPost] : [newPost]
      })
    },
    onError: (error) => {
      console.error('Failed to create post:', error)
    },
  })
}

// Usage in component
const { mutate: createPost, isPending } = useCreatePost()

function handleSubmit() {
  createPost({ title: 'New Post', content: 'Content here' })
}
```

### Optimistic Updates
```typescript
export function useUpdatePost() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Post> }) =>
      $fetch<Post>(`/api/posts/${id}`, {
        method: 'PATCH',
        body: data,
      }),
    
    onMutate: async ({ id, data }) => {
      // Cancel any outgoing refetches
      await queryClient.cancelQueries({ queryKey: ['posts', id] })
      
      // Snapshot previous value
      const previousPost = queryClient.getQueryData(['posts', id])
      
      // Optimistically update
      queryClient.setQueryData(['posts', id], (old: Post | undefined) => 
        old ? { ...old, ...data } : undefined
      )
      
      return { previousPost }
    },
    
    onError: (err, variables, context) => {
      // Rollback on error
      if (context?.previousPost) {
        queryClient.setQueryData(['posts', variables.id], context.previousPost)
      }
    },
    
    onSettled: (data, error, { id }) => {
      // Always refetch after error or success
      queryClient.invalidateQueries({ queryKey: ['posts', id] })
    },
  })
}
```

### Infinite Queries (Pagination)
```typescript
export function useInfinitePostList() {
  return useInfiniteQuery({
    queryKey: ['posts', 'infinite'],
    queryFn: ({ pageParam }) =>
      $fetch<{ posts: Post[]; nextCursor: string | null }>('/api/posts', {
        query: { cursor: pageParam, limit: 10 },
      }),
    initialPageParam: null as string | null,
    getNextPageParam: (lastPage) => lastPage.nextCursor,
    getPreviousPageParam: (firstPage) => null,
  })
}

// Usage
const {
  data,
  fetchNextPage,
  hasNextPage,
  isFetchingNextPage,
} = useInfinitePostList()

const allPosts = computed(() => 
  data.value?.pages.flatMap(page => page.posts) ?? []
)
```

### Query Keys Factory
```typescript
// lib/queryKeys.ts
export const queryKeys = {
  posts: {
    all: ['posts'] as const,
    lists: () => [...queryKeys.posts.all, 'list'] as const,
    list: (filters: PostFilters) => [...queryKeys.posts.lists(), filters] as const,
    details: () => [...queryKeys.posts.all, 'detail'] as const,
    detail: (id: string) => [...queryKeys.posts.details(), id] as const,
  },
  users: {
    all: ['users'] as const,
    detail: (id: string) => [...queryKeys.users.all, id] as const,
  },
}

// Usage
useQuery({
  queryKey: queryKeys.posts.detail(postId),
  queryFn: () => fetchPost(postId),
})

// Invalidate all post queries
queryClient.invalidateQueries({ queryKey: queryKeys.posts.all })
```

## Combining Pinia and TanStack Query

### Pattern: Pinia for UI State, Query for Server State
```typescript
// stores/ui.ts - UI state only
export const useUIStore = defineStore('ui', () => {
  const sidebarOpen = ref(true)
  const selectedPostId = ref<string | null>(null)
  const viewMode = ref<'grid' | 'list'>('grid')

  return {
    sidebarOpen,
    selectedPostId,
    viewMode,
    toggleSidebar: () => sidebarOpen.value = !sidebarOpen.value,
  }
})

// composables/usePosts.ts - Server state
export function usePosts() {
  return useQuery({
    queryKey: ['posts'],
    queryFn: fetchPosts,
  })
}

// In component - combine both
const uiStore = useUIStore()
const { data: posts } = usePosts()

const selectedPost = computed(() => 
  posts.value?.find(p => p.id === uiStore.selectedPostId)
)
```

## Best Practices

1. **Pinia for**: UI state, user preferences, local-only data
2. **TanStack Query for**: Server data, caching, background refetching
3. **Keep stores focused**: Single responsibility principle
4. **Use readonly()**: Prevent accidental state mutations
5. **Type everything**: Full TypeScript support
6. **Query key consistency**: Use a factory pattern
7. **Handle loading/error states**: Always show feedback
8. **Optimistic updates**: For better UX on mutations
