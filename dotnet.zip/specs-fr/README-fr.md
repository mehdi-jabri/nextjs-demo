# Spécifications (Français)

> **Statut :** non démarré · **Dernière mise à jour :** _(date)_
>
> Ce dossier contient la **traduction française** des spécifications métier confirmées. La **source de
> vérité reste l'anglais** sous [`../specs/`](../specs/00-index.md) ; ce dossier en est un miroir produit par
> la commande `/translate-fr` (agent `translator`) **après** confirmation de chaque module.
>
> Règles de traduction : les identifiants (`BR-/UC-/SCR-/ENT-…`), les chemins de fichiers, les citations
> `fichier:ligne`, les marqueurs (`[NEEDS-BUSINESS-INPUT]`, …) et le code Mermaid **ne sont pas traduits**.
> Le dossier `specs/migration/` (destiné aux développeurs) reste en anglais.

## Documents traduits
| Document (FR) | Source (EN) | Module | Statut |
|---|---|---|---|
| _(aucun pour l'instant — lancer `/translate-fr`)_ | | | Non démarré |

## Guide de lecture (métier)
À traduire depuis [`../specs/00-index.md`](../specs/00-index.md) une fois les modules confirmés :
vue d'ensemble du système, cas d'usage, règles métier, processus, rapports, et le journal des
**questions ouvertes** à valider par le métier.
