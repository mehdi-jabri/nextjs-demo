---
name: auth-forms
description: Expert knowledge for @sidebase/nuxt-auth authentication and VeeValidate with Zod schema validation. Use when implementing authentication, authorization, form validation, or user input handling.
---

# Authentication & Forms Skill

## @sidebase/nuxt-auth Setup

### Installation & Configuration
```bash
npm install @sidebase/nuxt-auth next-auth@4.21.1
```

```typescript
// nuxt.config.ts
export default defineNuxtConfig({
  modules: ['@sidebase/nuxt-auth'],
  auth: {
    baseURL: process.env.AUTH_ORIGIN,
    provider: {
      type: 'authjs',
    },
    globalAppMiddleware: {
      isEnabled: true,
      allow404WithoutAuth: true,
    },
  },
})
```

### Auth.js Handler
```typescript
// server/api/auth/[...].ts
import { NuxtAuthHandler } from '#auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import GithubProvider from 'next-auth/providers/github'
import GoogleProvider from 'next-auth/providers/google'

export default NuxtAuthHandler({
  secret: process.env.AUTH_SECRET,
  pages: {
    signIn: '/login',
    signOut: '/logout',
    error: '/auth/error',
    newUser: '/onboarding',
  },
  providers: [
    // OAuth Providers
    GithubProvider.default({
      clientId: process.env.GITHUB_CLIENT_ID,
      clientSecret: process.env.GITHUB_CLIENT_SECRET,
    }),
    GoogleProvider.default({
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    }),
    
    // Credentials Provider
    CredentialsProvider.default({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          throw new Error('Email and password required')
        }

        // Verify credentials against database
        const user = await prisma.user.findUnique({
          where: { email: credentials.email },
        })

        if (!user || !await bcrypt.compare(credentials.password, user.passwordHash)) {
          throw new Error('Invalid email or password')
        }

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user, account }) {
      if (user) {
        token.id = user.id
        token.role = user.role
      }
      return token
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string
        session.user.role = token.role as string
      }
      return session
    },
  },
})
```

### Using Auth in Components
```vue
<script setup lang="ts">
const { data: session, status, signIn, signOut } = useAuth()

const isAuthenticated = computed(() => status.value === 'authenticated')
const user = computed(() => session.value?.user)
</script>

<template>
  <div>
    <div v-if="status === 'loading'">Loading...</div>
    
    <div v-else-if="isAuthenticated">
      <p>Welcome, {{ user?.name }}</p>
      <Button @click="signOut()">Sign Out</Button>
    </div>
    
    <div v-else>
      <Button @click="signIn('github')">Sign in with GitHub</Button>
      <Button @click="signIn('google')">Sign in with Google</Button>
      <NuxtLink to="/login">Sign in with Email</NuxtLink>
    </div>
  </div>
</template>
```

### Protected Pages Middleware
```typescript
// middleware/auth.ts
export default defineNuxtRouteMiddleware((to) => {
  const { status } = useAuth()
  
  if (status.value !== 'authenticated') {
    return navigateTo({
      path: '/login',
      query: { redirect: to.fullPath },
    })
  }
})

// Usage in page
definePageMeta({
  middleware: 'auth',
})
```

### Role-Based Access
```typescript
// middleware/admin.ts
export default defineNuxtRouteMiddleware(() => {
  const { data: session } = useAuth()
  
  if (session.value?.user?.role !== 'admin') {
    throw createError({
      statusCode: 403,
      statusMessage: 'Access Denied',
    })
  }
})
```

## VeeValidate + Zod

### Setup
```bash
npm install vee-validate @vee-validate/zod zod
```

### Form Schema with Zod
```typescript
// schemas/auth.ts
import { z } from 'zod'
import { toTypedSchema } from '@vee-validate/zod'

// Login schema
export const loginSchema = z.object({
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Invalid email address'),
  password: z
    .string()
    .min(1, 'Password is required')
    .min(8, 'Password must be at least 8 characters'),
  rememberMe: z.boolean().optional(),
})

export const loginFormSchema = toTypedSchema(loginSchema)
export type LoginFormValues = z.infer<typeof loginSchema>

// Registration schema with password confirmation
export const registerSchema = z
  .object({
    name: z
      .string()
      .min(1, 'Name is required')
      .min(2, 'Name must be at least 2 characters'),
    email: z
      .string()
      .min(1, 'Email is required')
      .email('Invalid email address'),
    password: z
      .string()
      .min(1, 'Password is required')
      .min(8, 'Password must be at least 8 characters')
      .regex(/[A-Z]/, 'Password must contain an uppercase letter')
      .regex(/[a-z]/, 'Password must contain a lowercase letter')
      .regex(/[0-9]/, 'Password must contain a number'),
    confirmPassword: z.string().min(1, 'Please confirm your password'),
    acceptTerms: z.literal(true, {
      errorMap: () => ({ message: 'You must accept the terms' }),
    }),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  })

export const registerFormSchema = toTypedSchema(registerSchema)
export type RegisterFormValues = z.infer<typeof registerSchema>
```

### Complete Login Form
```vue
<script setup lang="ts">
import { useForm } from 'vee-validate'
import { loginFormSchema, type LoginFormValues } from '@/schemas/auth'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'

const { signIn } = useAuth()
const router = useRouter()
const route = useRoute()

const { handleSubmit, isSubmitting, setFieldError } = useForm<LoginFormValues>({
  validationSchema: loginFormSchema,
  initialValues: {
    email: '',
    password: '',
    rememberMe: false,
  },
})

const onSubmit = handleSubmit(async (values) => {
  try {
    const result = await signIn('credentials', {
      email: values.email,
      password: values.password,
      redirect: false,
    })

    if (result?.error) {
      setFieldError('password', 'Invalid email or password')
      return
    }

    const redirect = route.query.redirect as string || '/dashboard'
    router.push(redirect)
  } catch (error) {
    setFieldError('password', 'An error occurred. Please try again.')
  }
})
</script>

<template>
  <form @submit="onSubmit" class="space-y-6">
    <FormField v-slot="{ componentField }" name="email">
      <FormItem>
        <FormLabel>Email</FormLabel>
        <FormControl>
          <Input
            type="email"
            placeholder="you@example.com"
            autocomplete="email"
            v-bind="componentField"
          />
        </FormControl>
        <FormMessage />
      </FormItem>
    </FormField>

    <FormField v-slot="{ componentField }" name="password">
      <FormItem>
        <div class="flex items-center justify-between">
          <FormLabel>Password</FormLabel>
          <NuxtLink to="/forgot-password" class="text-sm text-primary">
            Forgot password?
          </NuxtLink>
        </div>
        <FormControl>
          <Input
            type="password"
            placeholder="••••••••"
            autocomplete="current-password"
            v-bind="componentField"
          />
        </FormControl>
        <FormMessage />
      </FormItem>
    </FormField>

    <FormField v-slot="{ value, handleChange }" name="rememberMe">
      <FormItem class="flex items-center space-x-2">
        <FormControl>
          <Checkbox
            :checked="value"
            @update:checked="handleChange"
          />
        </FormControl>
        <FormLabel class="!mt-0">Remember me</FormLabel>
      </FormItem>
    </FormField>

    <Button type="submit" class="w-full" :disabled="isSubmitting">
      <Loader2 v-if="isSubmitting" class="mr-2 h-4 w-4 animate-spin" />
      {{ isSubmitting ? 'Signing in...' : 'Sign in' }}
    </Button>
  </form>
</template>
```

### Dynamic Form Fields
```vue
<script setup lang="ts">
import { useForm, useFieldArray } from 'vee-validate'
import { toTypedSchema } from '@vee-validate/zod'
import { z } from 'zod'

const schema = toTypedSchema(
  z.object({
    members: z.array(
      z.object({
        name: z.string().min(1, 'Name is required'),
        email: z.string().email('Invalid email'),
        role: z.enum(['admin', 'member', 'viewer']),
      })
    ).min(1, 'At least one member is required'),
  })
)

const { handleSubmit, control } = useForm({
  validationSchema: schema,
  initialValues: {
    members: [{ name: '', email: '', role: 'member' }],
  },
})

const { fields, push, remove } = useFieldArray({ control, name: 'members' })
</script>

<template>
  <form @submit="handleSubmit(onSubmit)">
    <div v-for="(field, index) in fields" :key="field.key" class="flex gap-4">
      <FormField :name="`members.${index}.name`" v-slot="{ componentField }">
        <Input v-bind="componentField" placeholder="Name" />
      </FormField>
      
      <FormField :name="`members.${index}.email`" v-slot="{ componentField }">
        <Input v-bind="componentField" type="email" placeholder="Email" />
      </FormField>
      
      <FormField :name="`members.${index}.role`" v-slot="{ componentField }">
        <Select v-bind="componentField">
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="admin">Admin</SelectItem>
            <SelectItem value="member">Member</SelectItem>
            <SelectItem value="viewer">Viewer</SelectItem>
          </SelectContent>
        </Select>
      </FormField>
      
      <Button type="button" variant="ghost" @click="remove(index)">
        <Trash class="h-4 w-4" />
      </Button>
    </div>
    
    <Button type="button" variant="outline" @click="push({ name: '', email: '', role: 'member' })">
      Add Member
    </Button>
  </form>
</template>
```

### Custom Zod Validators
```typescript
// schemas/custom.ts
import { z } from 'zod'

// Phone number
export const phoneSchema = z
  .string()
  .regex(/^\+?[1-9]\d{1,14}$/, 'Invalid phone number')

// URL with specific domains
export const safeUrlSchema = z
  .string()
  .url()
  .refine(
    (url) => {
      const allowed = ['github.com', 'linkedin.com']
      return allowed.some(domain => url.includes(domain))
    },
    'Only GitHub and LinkedIn URLs are allowed'
  )

// File upload validation
export const imageFileSchema = z
  .instanceof(File)
  .refine((file) => file.size <= 5 * 1024 * 1024, 'Max file size is 5MB')
  .refine(
    (file) => ['image/jpeg', 'image/png', 'image/webp'].includes(file.type),
    'Only JPEG, PNG, and WebP are allowed'
  )

// Date range
export const dateRangeSchema = z
  .object({
    startDate: z.date(),
    endDate: z.date(),
  })
  .refine(
    (data) => data.endDate > data.startDate,
    { message: 'End date must be after start date', path: ['endDate'] }
  )
```

### Server-Side Validation
```typescript
// server/api/users/register.post.ts
import { z } from 'zod'

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().min(2),
})

export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  
  // Validate
  const result = registerSchema.safeParse(body)
  if (!result.success) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Validation failed',
      data: result.error.flatten(),
    })
  }

  // Process valid data
  const { email, password, name } = result.data
  // ... create user
})
```

## Best Practices

1. **Validate on both client and server** - Never trust client-side only
2. **Use Zod for schema definitions** - Single source of truth
3. **Show inline errors** - Clear, contextual feedback
4. **Debounce async validation** - Avoid excessive API calls
5. **Secure sensitive routes** - Use middleware consistently
6. **Handle auth state globally** - Single source of truth
7. **Implement proper error pages** - /login, /error, /unauthorized
8. **Use httpOnly cookies** - Secure session storage
