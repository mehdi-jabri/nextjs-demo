# 02 — Glossary / Ubiquitous Language

> **Status:** Not started · **Last updated:** _(date)_ · Back to [index](00-index.md).
>
> The canonical business vocabulary. Critical for the rebuild: the team must agree terms before translating to a
> new domain model. The **legacy code identifier** column connects business terms to the code so developers can
> trace them. Use these canonical terms consistently across all specs.

| Term (canonical) | Definition (plain language) | Synonyms / legacy names | Legacy code identifier(s) | Related entity (D6) | Confidence | Status |
|---|---|---|---|---|---|---|
| _(example)_ Order | A customer request to purchase one or more items | "Commande", tbl_Ord | `Order.cs`; `dbo.Orders` | ENT-Order | High | Confirmed |
| | | | | | | |
