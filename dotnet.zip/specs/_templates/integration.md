# TEMPLATE — Integration / Interface Specification

> One `INT-NNN` per external interface, appended in `cross-cutting/08-integrations.md`.

```
# Integration Spec — INT-NNN: <external system / interface name>
- **Direction:** Inbound | Outbound | Bidirectional
- **Protocol / format:** SOAP/WCF | REST | file (CSV/XML) | SQL link | email/SMTP | queue
- **Source:** <web.config endpoint / service reference / file watcher class file:line>
- **Trigger / frequency:** <on demand | scheduled | event>
- **Confidence:** … · **Status:** …

## Purpose (business)
<Why this integration exists — one plain sentence.>

## Contract
| Field | Type | Required | Meaning | Maps to entity (D6) | Source |
|---|---|---|---|---|---|

## Authentication / credentials (describe, never copy secrets)
| Mechanism | Where configured | Source |
|---|---|---|

## Error / retry behavior
| Condition | Behavior | Rule | Source |
|---|---|---|---|

## Open questions
- [NEEDS-BUSINESS-INPUT] SLA / availability expectation for <external system>?

## Developer Notes (legacy)
<legacy implementation detail>
```
> Target‑stack rebuild guidance lives only in `specs/migration/` (via `/migration-notes`).
