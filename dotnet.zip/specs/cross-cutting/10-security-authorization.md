# 10 — Security & Authorization Model

> **Status:** Not started · **Last updated:** _(date)_ · Back to [index](../00-index.md).
> Populated by `/extract-security`. Every line cited to source.

## Authentication
- Mechanism: _(Forms / Windows / custom)_ — Source: `web.config:<authentication>`; `Login.aspx.cs:line`
- Password policy / lockout: _(from membership provider config)_ — Source:

## Roles
| Role | Description | Source |
|---|---|---|
| | | |

## Authorization matrix (screen/feature × role)
| Screen / feature | Role A | Role B | Role C | Source |
|---|---|---|---|---|
| _(example)_ SCR-ORD-002 Edit Order | ✅ | 👁 | ⛔ | `web.config:<location>`; `OrderEdit.aspx.cs:Page_Load` |

Legend: ✅ full · 👁 read‑only · ⛔ none.

## Data-level / row-level rules
- `BR-SEC-NNN`: _(e.g. users see only their region's records)_ — Source:

## Sensitive operations & audit
| Operation | Who can | Logged? | Source |
|---|---|---|---|
| | | | |
