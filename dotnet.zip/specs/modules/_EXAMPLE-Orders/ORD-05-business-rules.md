# ORD — Business Rules Catalog  ⭐ EXAMPLE

> Fictional reference. Shows the required catalog format: a summary table, then a full record per rule, each
> cited and carrying Category, Enforcement layer, Confidence, and Status. Back to [module index](ORD-00-module-index.md).

## Summary
| ID | Name | Category | Trigger | Confidence | Status | Source |
|---|---|---|---|---|---|---|
| BR-ORD-001 | Minimum order total | Validation | On order submit | High | Confirmed | `OrderService.cs:55` |
| BR-ORD-002 | Order line quantity positive | Validation | On add/edit line | High | Confirmed | `OrderEdit.aspx:62`; `OrderService.cs:88` |
| BR-ORD-005 | Customer required to place order | Validation | On order submit | High | Confirmed | `OrderService.cs:48` |
| BR-ORD-010 | Order total derivation | Calculation | On line change / save | High | Confirmed | `OrderService.cs:160` |
| BR-ORD-011 | Line subtotal & discount | Calculation | On line change | High | Confirmed | `OrderLine.cs:33`; `OrderMappingProfile.cs:21` |
| BR-ORD-015 | Stock check before placing | Process/Workflow | On order submit | Medium | Needs-business-input | `OrderService.cs:120`; `usp_ReserveStock` |
| BR-ORD-020 | Cancellation window | Process/Workflow | On cancel | Medium | Needs-business-input | `OrderService.cs:210` |
| BR-ORD-030 | Soft-delete hides orders | Data integrity | On any query | High | Confirmed | `ShopContext.cs:74` |
| BR-ORD-040 | Legacy bulk-import bypass | Validation | (none found) | Low | Dead-code? | `OrderImport.cs:35` |

---

### BR-ORD-001 — Minimum order total
- **Category:** Validation  ·  **Rule type:** Operative/Behavioral
- **Statement:** It is obligatory that an order's total be at least 10.00 before the order can be placed.
- **Trigger / Condition:** User submits an order (clicks **Place Order**) where total < 10.00.
- **Inputs:** Order total (BR-ORD-010).
- **Logic / Condition:** `if (order.Total < MinimumOrderTotal) throw new BusinessException(...)`, where
  `MinimumOrderTotal = 10.00m` is a hardcoded literal.
- **Action / Outcome:** The submission is rejected and the message *"Minimum order is $10.00"* is shown; the order
  stays in `Draft`.
- **Exceptions:** Orders created by role **Admin** appear to bypass this check (`if (!User.IsInRole("Admin"))` guard). `[UNVERIFIED]`
- **Enforcement layer:** Server/BLL (no client-side equivalent found → the rebuild must enforce this server-side).
- **Source location(s):** `OrderService.cs:55-62`; message string `Strings.resx:OrderMinTotal`.
- **Related rules:** BR-ORD-010 (total derivation).
- **Related artifacts:** UC-ORD-003, SCR-ORD-002, ENT-Order.
- **Examples:** Total $9.99 → rejected. Total $10.00 → accepted.
- **Confidence:** High  ·  **Status:** Confirmed
- **Notes:** Threshold `10.00` is hardcoded (`OrderService.cs:57`) — recommend making it configurable in the rebuild.
  The admin bypass is raised as open question **Q-001**.

### BR-ORD-010 — Order total derivation
- **Category:** Calculation/Derivation  ·  **Rule type:** Operative/Behavioral
- **Statement:** It is necessary that an order's total equal the sum of its line subtotals, rounded to 2 decimals.
- **Trigger / Condition:** Whenever a line is added/edited/removed, and again on save.
- **Logic / Formula:** `Total = Math.Round(Sum(line.Subtotal), 2, MidpointRounding.AwayFromZero)`; each
  `line.Subtotal` per BR-ORD-011. No tax or shipping is added at this stage. `[NEEDS-BUSINESS-INPUT]` whether tax/shipping
  apply elsewhere (none found in this module).
- **Action / Outcome:** `Order.Total` is updated and displayed in the order summary.
- **Enforcement layer:** Server/BLL.
- **Source location(s):** `OrderService.cs:160-168`.
- **Related rules:** BR-ORD-011, BR-ORD-001.
- **Related artifacts:** UC-ORD-003, SCR-ORD-002, ENT-Order.
- **Examples:** Lines [3×$2.00, 1×$5.00] → $11.00. Rounding: subtotal $0.005 → $0.01 (away from zero).
- **Confidence:** High  ·  **Status:** Confirmed
- **Notes:** Midpoint rounding mode is `AwayFromZero` (`OrderService.cs:160`) — capture it exactly; the rebuild
  must replicate this rounding (the rounding-mismatch risk is recorded in the dev-only migration notes, not here).

### BR-ORD-011 — Line subtotal & discount
- **Category:** Calculation/Derivation  ·  **Rule type:** Operative/Behavioral
- **Statement:** It is necessary that a line subtotal equal `UnitPrice × Quantity × (1 − DiscountRate)`.
- **Trigger / Condition:** On line quantity, price, or discount change.
- **Logic / Formula:** `Subtotal = UnitPrice * Quantity * (1 - DiscountRate)`; `DiscountRate` is 0..0.5
  (validated elsewhere) and is projected onto the line DTO by `OrderMappingProfile` (AfterMap).
- **Action / Outcome:** `OrderLine.Subtotal` updated; feeds BR-ORD-010.
- **Enforcement layer:** Multiple (entity property `OrderLine.cs:33` + AutoMapper `OrderMappingProfile.cs:21`).
- **Source location(s):** `OrderLine.cs:33-39`; `OrderMappingProfile.cs:21`.
- **Related rules:** BR-ORD-010.
- **Examples:** $2.00 × 3 × (1 − 0.10) = $5.40.
- **Confidence:** High  ·  **Status:** Confirmed

### BR-ORD-015 — Stock check before placing
- **Category:** Process/Workflow  ·  **Rule type:** Operative/Behavioral
- **Statement:** It is prohibited to place an order for a quantity exceeding available stock.
- **Trigger / Condition:** On **Place Order**, before status moves to `Placed`.
- **Logic / Condition:** `OrderService.PlaceOrder` calls stored procedure `usp_ReserveStock`; if it returns a
  non-zero failure code the order is rejected.
- **Action / Outcome:** Order rejected with *"Insufficient stock for {product}"*; stays `Draft`. `[UNVERIFIED]` whether
  partial fulfilment is offered — a code path exists (`OrderService.cs:140`) but appears unreachable from the UI `[DEAD-CODE?]`.
- **Enforcement layer:** Database (`usp_ReserveStock`) + Server/BLL.
- **Source location(s):** `OrderService.cs:120-138`; `usp_ReserveStock` (proc body not yet read).
- **Related artifacts:** UC-ORD-003, PRC-ORD-001.
- **Confidence:** Medium  ·  **Status:** Needs-business-input
- **Notes:** Proc body must be scripted from the DB to confirm exact logic — raised as open question **Q-014**.

### BR-ORD-020 — Cancellation window
- **Category:** Process/Workflow  ·  **Rule type:** Operative/Behavioral
- **Statement:** It is prohibited to cancel an order more than 24 hours after it was placed.
- **Trigger / Condition:** On **Cancel** for an order in status `Placed`.
- **Logic / Condition:** `if ((DateTime.Now - order.PlacedDate).TotalHours > 24) throw ...`. Uses server local time
  (`DateTime.Now`, not UTC). `[SUSPECTED-BUG]` time-zone sensitivity.
- **Action / Outcome:** Cancellation rejected with *"Orders can only be cancelled within 24 hours"*.
- **Enforcement layer:** Server/BLL.
- **Source location(s):** `OrderService.cs:210-218`.
- **Related artifacts:** UC-ORD-005 (not shown), PRC-ORD-001.
- **Confidence:** Medium  ·  **Status:** Needs-business-input
- **Notes:** Confirm the 24h window and whether it should be business hours / time-zone aware — open question **Q-014**.

### BR-ORD-030 — Soft-delete hides orders
- **Category:** Data integrity  ·  **Rule type:** Structural/Definitional
- **Statement:** It is necessary that orders flagged deleted never appear in any list or query.
- **Trigger / Condition:** On every order query.
- **Logic / Condition:** `SaveChanges` converts deletes to `IsDeleted = true`; all repository queries add
  `.Where(o => !o.IsDeleted)`.
- **Enforcement layer:** Database/ORM (`ShopContext.SaveChanges` override + repository filter).
- **Source location(s):** `ShopContext.cs:74-90`; `OrderRepository.cs:25`.
- **Confidence:** High  ·  **Status:** Confirmed

### BR-ORD-040 — Legacy bulk-import bypass `[DEAD-CODE?]`
- **Category:** Validation  ·  **Rule type:** Operative/Behavioral
- **Statement:** (Legacy) Bulk-imported orders skip the minimum-total check.
- **Trigger / Condition:** None found — `OrderImport.RunImport()` has no caller, route, or job binding.
- **Enforcement layer:** Server/BLL (not live).
- **Source location(s):** `OrderImport.cs:35`.
- **Confidence:** Low  ·  **Status:** Dead-code?
- **Notes:** Recorded for completeness; **do not** port unless business confirms it is still used. Raised in D13.
