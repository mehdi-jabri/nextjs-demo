---
description: "Build the security & authorization model (roles, page/feature matrix, auth rules)"
agent: agent
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "findTestFiles", "problems", "fetch", "editFiles"]
argument-hint: "(no argument needed — scans config + code-behind + services)"
---

# Task: Extract the security & authorization model

Follow `.github/instructions/config-crosscutting.instructions.md` and `.github/copilot-instructions.md`. **Read‑only.**

## Steps
1. **Authentication** — mode (Forms/Windows/custom) from `web.config`, login/logout/registration/password‑reset
   flows, lockout & password policy (membership provider config).
2. **Roles** — from `web.config <roleManager>` / role tables / `Roles` API / enums.
3. **Authorization** — root and per‑folder `<authorization>`/`<location>`, `User.IsInRole(...)`,
   `[PrincipalPermission]`, programmatic show/hide, menu gating, and row‑level/data‑level rules
   (e.g. "users see only their region's orders").
4. **Sensitive operations & audit** — which actions are restricted and which are logged.

## Output
- `specs/cross-cutting/10-security-authorization.md`: roles table, authentication rules, the **page/feature ×
  role authorization matrix** (✅ full · 👁 read · ⛔ none), data‑level rules, audited operations — each cited.
- Each authorization rule → a `BR-SEC-NNN` entry (link from screens/use cases).
- Add unknowns to `13-open-questions.md`; update `specs/00-index.md` coverage.
