---
name: testing
description: 'Expert knowledge for Vitest unit testing and Playwright E2E testing. Use when implementing tests, setting up test infrastructure, or following TDD practices. By default, test implementation is SKIPPED unless explicitly requested.'
---

# Testing Skill

## Test Implementation Policy

**DEFAULT BEHAVIOR: Tests are SKIPPED unless explicitly requested.**

When implementing features:
- ✅ Focus on feature implementation first
- ✅ Only write tests when user explicitly asks for them
- ✅ Skip test files unless "with tests" or "add tests" is mentioned

### When to Implement Tests

IMPLEMENT tests when user says:
- "Add tests", "Write tests", "Include tests"
- "With unit tests", "With E2E tests"
- "Test this", "Create test file"
- "TDD", "Test-driven"

SKIP tests (default) when:
- User just asks for a feature implementation
- User doesn't mention testing
- Quick prototyping or scaffolding

### Environment Variable Override

```bash
# Force enable tests in CI/CD
SKIP_TESTS=false npm run build

# Explicitly skip (default behavior)
SKIP_TESTS=true npm run dev
```

```typescript
// Check test mode in code
const SKIP_TESTS = process.env.SKIP_TESTS !== 'false' // Defaults to true (skip)
```

## Vitest Setup

### Configuration
```typescript
// vitest.config.ts
import { defineConfig } from 'vitest/config'
import vue from '@vitejs/plugin-vue'
import { fileURLToPath } from 'node:url'

export default defineConfig({
  plugins: [vue()],
  test: {
    globals: true,
    environment: 'happy-dom',
    setupFiles: ['./test/setup.ts'],
    include: ['**/*.{test,spec}.{js,ts,vue}'],
    exclude: ['node_modules', 'dist', '.nuxt'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      exclude: ['node_modules', 'test', '**/*.d.ts'],
    },
  },
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
      '~': fileURLToPath(new URL('./', import.meta.url)),
    },
  },
})
```

### Test Setup
```typescript
// test/setup.ts
import { config } from '@vue/test-utils'
import { vi } from 'vitest'

// Global mocks
vi.mock('vue-router', () => ({
  useRoute: () => ({
    params: {},
    query: {},
  }),
  useRouter: () => ({
    push: vi.fn(),
    replace: vi.fn(),
  }),
}))

// Global stubs
config.global.stubs = {
  NuxtLink: true,
  ClientOnly: true,
}

// Reset mocks after each test
afterEach(() => {
  vi.clearAllMocks()
})
```

## Component Testing

### Basic Component Test
```typescript
// components/Button.test.ts
import { describe, it, expect, vi } from 'vitest'
import { mount } from '@vue/test-utils'
import Button from './Button.vue'

describe('Button', () => {
  it('renders slot content', () => {
    const wrapper = mount(Button, {
      slots: {
        default: 'Click me',
      },
    })
    expect(wrapper.text()).toContain('Click me')
  })

  it('emits click event', async () => {
    const wrapper = mount(Button)
    await wrapper.trigger('click')
    expect(wrapper.emitted('click')).toHaveLength(1)
  })

  it('applies variant classes', () => {
    const wrapper = mount(Button, {
      props: { variant: 'destructive' },
    })
    expect(wrapper.classes()).toContain('bg-destructive')
  })

  it('is disabled when loading', () => {
    const wrapper = mount(Button, {
      props: { loading: true },
    })
    expect(wrapper.attributes('disabled')).toBeDefined()
  })
})
```

### Testing with Props and Slots
```typescript
// components/Card.test.ts
import { describe, it, expect } from 'vitest'
import { mount } from '@vue/test-utils'
import Card from './Card.vue'

describe('Card', () => {
  it('renders with all slots', () => {
    const wrapper = mount(Card, {
      slots: {
        header: '<h2>Header</h2>',
        default: '<p>Content</p>',
        footer: '<button>Action</button>',
      },
    })

    expect(wrapper.find('h2').text()).toBe('Header')
    expect(wrapper.find('p').text()).toBe('Content')
    expect(wrapper.find('button').text()).toBe('Action')
  })

  it('conditionally renders footer', () => {
    const wrapper = mount(Card, {
      props: { showFooter: false },
    })
    expect(wrapper.find('[data-testid="footer"]').exists()).toBe(false)
  })
})
```

### Testing Form Components
```typescript
// components/LoginForm.test.ts
import { describe, it, expect, vi } from 'vitest'
import { mount, flushPromises } from '@vue/test-utils'
import LoginForm from './LoginForm.vue'

describe('LoginForm', () => {
  it('validates required fields', async () => {
    const wrapper = mount(LoginForm)
    
    await wrapper.find('form').trigger('submit')
    await flushPromises()

    expect(wrapper.text()).toContain('Email is required')
    expect(wrapper.text()).toContain('Password is required')
  })

  it('submits valid form', async () => {
    const onSubmit = vi.fn()
    const wrapper = mount(LoginForm, {
      props: { onSubmit },
    })

    await wrapper.find('input[type="email"]').setValue('test@example.com')
    await wrapper.find('input[type="password"]').setValue('password123')
    await wrapper.find('form').trigger('submit')
    await flushPromises()

    expect(onSubmit).toHaveBeenCalledWith({
      email: 'test@example.com',
      password: 'password123',
    })
  })

  it('shows loading state during submission', async () => {
    const wrapper = mount(LoginForm, {
      props: {
        onSubmit: () => new Promise(r => setTimeout(r, 100)),
      },
    })

    await wrapper.find('input[type="email"]').setValue('test@example.com')
    await wrapper.find('input[type="password"]').setValue('password123')
    await wrapper.find('form').trigger('submit')

    expect(wrapper.find('button[type="submit"]').attributes('disabled')).toBeDefined()
    expect(wrapper.text()).toContain('Loading')
  })
})
```

## Composable Testing

```typescript
// composables/useCounter.test.ts
import { describe, it, expect } from 'vitest'
import { useCounter } from './useCounter'

describe('useCounter', () => {
  it('initializes with default value', () => {
    const { count } = useCounter()
    expect(count.value).toBe(0)
  })

  it('initializes with custom value', () => {
    const { count } = useCounter(10)
    expect(count.value).toBe(10)
  })

  it('increments count', () => {
    const { count, increment } = useCounter()
    increment()
    expect(count.value).toBe(1)
  })

  it('computes double', () => {
    const { count, double, increment } = useCounter(5)
    expect(double.value).toBe(10)
    increment()
    expect(double.value).toBe(12)
  })
})
```

## API/Store Testing

```typescript
// stores/user.test.ts
import { describe, it, expect, vi, beforeEach } from 'vitest'
import { setActivePinia, createPinia } from 'pinia'
import { useUserStore } from './user'

// Mock $fetch
vi.mock('#app', () => ({
  $fetch: vi.fn(),
}))

describe('useUserStore', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    vi.clearAllMocks()
  })

  it('initializes with null user', () => {
    const store = useUserStore()
    expect(store.user).toBeNull()
    expect(store.isAuthenticated).toBe(false)
  })

  it('fetches user successfully', async () => {
    const mockUser = { id: '1', name: 'John', email: 'john@test.com' }
    vi.mocked($fetch).mockResolvedValue(mockUser)

    const store = useUserStore()
    await store.fetchUser()

    expect(store.user).toEqual(mockUser)
    expect(store.isAuthenticated).toBe(true)
    expect(store.error).toBeNull()
  })

  it('handles fetch error', async () => {
    vi.mocked($fetch).mockRejectedValue(new Error('Network error'))

    const store = useUserStore()
    await store.fetchUser()

    expect(store.user).toBeNull()
    expect(store.error).toBe('Network error')
  })
})
```

## Playwright E2E Testing

### Configuration
```typescript
// playwright.config.ts
import { defineConfig, devices } from '@playwright/test'

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',
  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
    {
      name: 'Mobile Chrome',
      use: { ...devices['Pixel 5'] },
    },
  ],
  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
})
```

### Page Object Model
```typescript
// e2e/pages/LoginPage.ts
import { type Page, type Locator, expect } from '@playwright/test'

export class LoginPage {
  readonly page: Page
  readonly emailInput: Locator
  readonly passwordInput: Locator
  readonly submitButton: Locator
  readonly errorMessage: Locator

  constructor(page: Page) {
    this.page = page
    this.emailInput = page.getByLabel('Email')
    this.passwordInput = page.getByLabel('Password')
    this.submitButton = page.getByRole('button', { name: 'Sign in' })
    this.errorMessage = page.getByRole('alert')
  }

  async goto() {
    await this.page.goto('/login')
  }

  async login(email: string, password: string) {
    await this.emailInput.fill(email)
    await this.passwordInput.fill(password)
    await this.submitButton.click()
  }

  async expectError(message: string) {
    await expect(this.errorMessage).toContainText(message)
  }
}
```

### E2E Tests
```typescript
// e2e/auth.spec.ts
import { test, expect } from '@playwright/test'
import { LoginPage } from './pages/LoginPage'

test.describe('Authentication', () => {
  test('successful login redirects to dashboard', async ({ page }) => {
    const loginPage = new LoginPage(page)
    await loginPage.goto()
    await loginPage.login('user@example.com', 'password123')
    
    await expect(page).toHaveURL('/dashboard')
    await expect(page.getByText('Welcome')).toBeVisible()
  })

  test('invalid credentials show error', async ({ page }) => {
    const loginPage = new LoginPage(page)
    await loginPage.goto()
    await loginPage.login('wrong@example.com', 'wrongpassword')
    
    await loginPage.expectError('Invalid email or password')
    await expect(page).toHaveURL('/login')
  })

  test('logout returns to home', async ({ page }) => {
    // Login first
    await page.goto('/login')
    await page.getByLabel('Email').fill('user@example.com')
    await page.getByLabel('Password').fill('password123')
    await page.getByRole('button', { name: 'Sign in' }).click()
    
    // Then logout
    await page.getByRole('button', { name: 'Logout' }).click()
    
    await expect(page).toHaveURL('/')
  })
})
```

### Visual Regression Testing
```typescript
// e2e/visual.spec.ts
import { test, expect } from '@playwright/test'

test('homepage visual regression', async ({ page }) => {
  await page.goto('/')
  await expect(page).toHaveScreenshot('homepage.png', {
    maxDiffPixels: 100,
  })
})

test('component states', async ({ page }) => {
  await page.goto('/components')
  
  // Default state
  await expect(page.getByTestId('button')).toHaveScreenshot('button-default.png')
  
  // Hover state
  await page.getByTestId('button').hover()
  await expect(page.getByTestId('button')).toHaveScreenshot('button-hover.png')
})
```

## npm Scripts

```json
{
  "scripts": {
    "test": "vitest",
    "test:run": "vitest run",
    "test:coverage": "vitest run --coverage",
    "test:ui": "vitest --ui",
    "test:e2e": "playwright test",
    "test:e2e:ui": "playwright test --ui",
    "test:e2e:debug": "playwright test --debug",
    "test:all": "vitest run && playwright test"
  }
}
```

## Best Practices

1. **Test behavior, not implementation** - Focus on what, not how
2. **Use data-testid sparingly** - Prefer accessible selectors
3. **Mock external dependencies** - Isolate units under test
4. **Write deterministic tests** - No flaky network calls
5. **Use Page Object Model** - Reusable E2E patterns
6. **Run tests in CI** - Automated quality gates
7. **Measure coverage** - But don't chase 100%
8. **Test error states** - Not just happy paths
