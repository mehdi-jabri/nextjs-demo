# Nuxt.js Frontend Development Agent

This workspace is configured for autonomous AI-driven frontend development with skills, subagents, and auto-applied instructions.

## Project Stack

- **Framework**: Nuxt 3 (Vue 3 with Composition API)
- **UI Components**: shadcn-vue (Radix Vue primitives)
- **Styling**: Tailwind CSS 4
- **State Management**: Pinia + TanStack Query (Vue Query)
- **Authentication**: @sidebase/nuxt-auth
- **Form Handling**: VeeValidate + Zod
- **API Layer**: VueUse's built-in $fetch (or tRPC for type-safe APIs)
- **Testing**: Vitest + Playwright (SKIPPED by default, enabled on request)
- **Utilities**: VueUse composables

## Testing Policy

**Tests are SKIPPED by default** to focus on feature delivery.

Implement tests ONLY when explicitly requested:
- User says: "add tests", "with tests", "write unit tests", "TDD"
- CI/CD: Set `SKIP_TESTS=false` to enable

```bash
# Default: skip test implementation
SKIP_TESTS=true  # (default)

# Enable tests in CI/CD
SKIP_TESTS=false npm run build
```

## Development Workflow
### Auto-Applied Instructions

The `.github/instructions/` folder contains coding standards that auto-apply:

| File Pattern | Instruction Applied |
|--------------|---------------------|
| `**/*.vue` | Vue component standards |
| `**/*.ts` | TypeScript conventions |
| `server/api/**/*.ts` | API route patterns |
| `stores/**/*.ts` | Pinia store patterns |
| `schemas/**/*.ts` | Zod schema standards |
### Task Management
All requirements and features are tracked in the `docs/` folder:
- `docs/requirements/` - Product requirements, user stories, specs
- `docs/tasks/` - Task breakdowns, implementation status, priorities
- `docs/tasks/active.md` - Current active tasks with status

### Subagent Orchestration
When implementing complex features:
1. **project-orchestrator** agent coordinates the work
2. **frontend-architect** plans component architecture and data flow
3. **component-developer** implements Vue components
4. **feature-implementer** builds complete features
5. **debugger** troubleshoots issues

### Skills System
Skills provide domain expertise, loaded on-demand:

| Skill | Trigger |
|-------|---------|
| `nuxt-development` | Nuxt config, routing, SSR, data fetching |
| `vue-shadcn` | Vue components, shadcn-vue, Tailwind |
| `state-management` | Pinia stores, TanStack Query |
| `auth-forms` | Authentication, VeeValidate, Zod |
| `api-integration` | $fetch, tRPC, API routes |
| `testing` | Vitest, Playwright (when requested) |
| `ui-ux-design` | Design systems, accessibility |

## Conventions

### File Structure
```
src/
├── components/       # Shared UI components
│   ├── ui/          # shadcn-vue base components
│   └── common/      # Common business components
├── composables/     # Vue composables
├── layouts/         # Nuxt layouts
├── pages/           # File-based routing
├── stores/          # Pinia stores
├── server/          # Server routes and middleware
│   ├── api/         # API endpoints
│   └── middleware/  # Server middleware
├── utils/           # Utility functions
└── types/           # TypeScript types
```

### Coding Standards
- Use TypeScript with strict mode
- Prefer `<script setup>` syntax for Vue components
- Use Composition API with `defineComponent` for complex components
- Follow Vue 3 naming conventions (PascalCase for components)
- Use `useFetch` or `useAsyncData` for data fetching in Nuxt
- Implement proper error boundaries and loading states
- Always add proper TypeScript types

### Component Structure
```vue
<script setup lang="ts">
// 1. Imports
// 2. Props & Emits
// 3. Composables
// 4. Reactive state
// 5. Computed properties
// 6. Methods
// 7. Lifecycle hooks
</script>

<template>
  <!-- Single root element recommended -->
</template>

<style scoped>
/* Tailwind @apply for complex styles */
</style>
```

### State Management Patterns
- Use Pinia for global application state
- Use TanStack Query for server state (caching, refetching)
- Use Vue refs/reactive for local component state
- Never mutate state directly outside stores

## Environment Variables
- `SKIP_TESTS=true` - Skip test implementation (DEFAULT)
- `SKIP_TESTS=false` - Enable test implementation (for CI/CD)
- `NUXT_PUBLIC_API_BASE` - API base URL

## Quick Commands
- `pnpm dev` - Start development server
- `pnpm build` - Build for production
- `pnpm test` - Run tests (skipped if SKIP_TESTS=true)
- `pnpm lint` - Lint code
- `pnpm typecheck` - TypeScript type checking

## Important Notes

1. **Tests are SKIPPED by default** - Only implement tests when explicitly requested
2. **Check `docs/tasks/active.md`** for current task status before starting work
3. **Update task status** after completing work
4. **Use appropriate subagent** for specialized tasks
5. **Instructions auto-apply** based on file patterns
6. **Skills load on-demand** when domain expertise is needed
5. **Commit frequently** with meaningful messages
