---
applyTo: "**/*Service*.cs, **/*Manager*.cs, **/*Handler*.cs, **/*Workflow*.cs, **/*Business*/**/*.cs, **/*BLL*/**/*.cs, **/*Domain*/**/*.cs, **/*Application*/**/*.cs"
description: "How to read the Business Logic tier and extract calculations, workflows, invariants, and validation"
---

# Reading the Business Logic tier (C# services/managers)

The method body is the procedure. For every **public** method extract: preconditions (guard clauses),
the computation/decision, postconditions, and side effects (what it persists, sends, or logs).

## What to extract
1. **Validation** — guard clauses (`if (x == null) throw …`, `if (amount <= 0) throw new BusinessException(…)`),
   FluentValidation validators, `Validate()` methods. **Every thrown business exception is a rule**
   ("you cannot X when Y") — capture its message verbatim.
2. **Calculations / formulas / derivations** — tax, discount, interest, fee, totals, aggregation, date math
   (due dates, business days, age). Capture the **exact formula, operand order, rounding mode, and units**
   (`Math.Round` midpoint mode matters for money). These must port verbatim to the new system.
3. **Workflow / state machines** — status/state enums plus the methods that transition them. Reconstruct the
   **state‑transition table**: from‑state → event → guard → to‑state → side effects. Look at `switch(status)`
   and `if (status == X)` chains — they define legal and forbidden transitions. Use a Mermaid `stateDiagram-v2`.
4. **Domain invariants** — conditions always enforced before persisting (e.g. "sum of lines must equal header
   total"), usually just before the repository/`SaveChanges` call.
5. **Transactions** — `TransactionScope`, `BeginTransaction`, unit‑of‑work. The transaction boundary defines an
   **atomic business operation** ("these N steps all succeed or all fail") — capture the boundary and its steps.
6. **Constants, enums, magic numbers** — `const`/`static readonly`/`enum` members ARE the domain vocabulary and
   allowed values; extract names **and** numeric values (EF/DB may store the int). Name every magic number in a
   condition as a rule; if its business meaning is non‑obvious, add `[NEEDS-BUSINESS-INPUT]`.
7. **Server‑side authorization** — role/permission checks done independently of the UI (the real enforcement).
   Record in the security model and as `BR-SEC-*`.

## Easy‑to‑miss traps
- Logic injected via the DI graph — confirm which **concrete implementation** is actually bound (see
  di‑mapping instructions) before describing behavior; ignore stub/test implementations.
- Helpers/extension methods called from services (the formula may live in a `*Helper`/`*Util` class).
- `[DEAD-CODE?]` methods with no inbound caller/route — record but mark, do not spec as live.

## How to document
One entry per business operation in the module's `BR-` catalog and, where it represents a user goal, a
`UC-<MOD>-NNN` use case (`specs/_templates/use-case.md`). Include trigger, inputs, step‑by‑step logic,
formulas, state transitions, invariants, transaction boundary, outputs, and exceptions‑as‑rules. Put EF/DI
mechanics in **Developer Notes (legacy)**. Do **not** add Spring Boot/target‑stack hints here — those are
produced separately by `/migration-notes` into `specs/migration/`.
