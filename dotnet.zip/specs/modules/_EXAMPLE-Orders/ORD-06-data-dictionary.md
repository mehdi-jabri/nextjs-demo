# ORD — Domain Model / Data Dictionary  ⭐ EXAMPLE

> Fictional reference. Target‑agnostic (legacy types only; PostgreSQL mapping lives in
> [../../migration/_EXAMPLE-ORD-migration-notes.md](../../migration/_EXAMPLE-ORD-migration-notes.md)).
> Back to [module index](ORD-00-module-index.md).

## ERD
```mermaid
erDiagram
  CUSTOMER ||--o{ ORDER : places
  ORDER ||--o{ ORDER_LINE : contains
  ORDER_LINE }o--|| PRODUCT : references
```

## Entity: ENT-Order  (legacy: `Order.cs` / `dbo.Orders`)
- **Source (entity):** `Order.cs:1-90` · **Source (mapping):** `ShopContext.cs:OnModelCreating:30-60`
- **Description (business):** A customer's request to purchase one or more products.
- **Business identity:** Order number (`OrderNo`), unique per order.

### Attributes
| Attribute | Business meaning | Type (legacy) | Nullable | Constraints / domain | DB column | Default | Source | Confidence |
|---|---|---|---|---|---|---|---|---|
| Id | Internal identifier | int | No | identity, PK | OrderId | auto | `Order.cs:5` | High |
| OrderNo | Human order number | nvarchar(20) | No | unique | OrderNo | — | `Order.cs:8`; `ShopContext.cs:38` | High |
| CustomerId | Owning customer | int | No | FK → Customer | CustomerId | — | `Order.cs:11` | High |
| Status | Lifecycle state | enum OrderStatus | No | Draft=0/Placed=1/Shipped=2/Cancelled=3 | Status | Draft(0) | `Order.cs:18`; `OrderStatus.cs:1` | High |
| Total | Order monetary total | decimal(18,2) | No | derived (BR-ORD-010) | Total | 0 | `Order.cs:22`; `OrderService.cs:160` | High |
| PlacedDate | When placed | datetime | Yes | set on Place | PlacedDate | null | `Order.cs:25` | High |
| IsDeleted | Soft-delete flag | bit | No | filtered out everywhere (BR-ORD-030) | IsDeleted | 0 | `Order.cs:30` | High |
| CreatedBy/CreatedDate | Audit | nvarchar/datetime | No | stamped on save | CreatedBy/CreatedDate | — | `BaseEntity.cs:8-14` | High |

### Relationships
| Related entity | Cardinality | FK | Cascade behavior | Source |
|---|---|---|---|---|
| ENT-OrderLine | 1:N | OrderLine.OrderId | delete cascade | `ShopContext.cs:44` |
| ENT-Customer | N:1 | Order.CustomerId | restrict (no cascade) | `ShopContext.cs:48` |

### Invariants / constraints (link to rules)
- BR-ORD-010: `Total` = sum of line subtotals (2dp). Source: `OrderService.cs:160`.
- BR-ORD-030: deleted orders never appear in queries. Source: `ShopContext.cs:74`.

## Developer Notes (legacy)
- EF6 Code First; Fluent API in `ShopContext.OnModelCreating:30-60`. `OrderNo` unique index `ShopContext.cs:38`.
- `SaveChanges` override stamps audit columns and converts deletes to `IsDeleted=true` (`ShopContext.cs:74-90`).
- Concurrency: none observed on Order `[UNVERIFIED]`. Soft-delete: `IsDeleted` filter in `OrderRepository.cs:25`.

---

## Entity: ENT-OrderLine  (legacy: `OrderLine.cs` / `dbo.OrderLines`)
- **Source (entity):** `OrderLine.cs:1-50` · **Description:** A single product line within an order.

### Attributes
| Attribute | Business meaning | Type (legacy) | Nullable | Constraints / domain | DB column | Default | Source | Confidence |
|---|---|---|---|---|---|---|---|---|
| Id | Internal identifier | int | No | identity, PK | OrderLineId | auto | `OrderLine.cs:5` | High |
| OrderId | Parent order | int | No | FK → Order | OrderId | — | `OrderLine.cs:8` | High |
| ProductId | Product ordered | int | No | FK → Product | ProductId | — | `OrderLine.cs:11` | High |
| Quantity | Units ordered | int | No | > 0 (BR-ORD-002) | Quantity | — | `OrderLine.cs:14` | High |
| UnitPrice | Price per unit at order time | decimal(18,2) | No | ≥ 0 | UnitPrice | — | `OrderLine.cs:17` | High |
| DiscountRate | Line discount fraction | decimal(5,4) | No | 0..0.5 | DiscountRate | 0 | `OrderLine.cs:20` | Medium |
| Subtotal | Line total | decimal(18,2) | No | derived (BR-ORD-011) | Subtotal | — | `OrderLine.cs:33` | High |

### Relationships
| Related entity | Cardinality | FK | Cascade behavior | Source |
|---|---|---|---|---|
| ENT-Order | N:1 | OrderLine.OrderId | delete cascade (parent) | `ShopContext.cs:44` |
| ENT-Product | N:1 | OrderLine.ProductId | restrict | `ShopContext.cs:52` |

### Invariants / constraints
- BR-ORD-002: Quantity > 0. Source: `OrderEdit.aspx:62`; `OrderService.cs:88`.
- BR-ORD-011: Subtotal = UnitPrice × Quantity × (1 − DiscountRate). Source: `OrderLine.cs:33`.

## Developer Notes (legacy)
- `DiscountRate` upper bound (0.5) is `[UNVERIFIED]` — inferred from a `CompareValidator` on the edit screen
  (`OrderEdit.aspx:70`); no server-side check found. Raised as open question Q-014.
