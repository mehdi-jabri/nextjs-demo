# 09 — Reports Catalog

> **Status:** Not started · **Last updated:** _(date)_ · Back to [index](../00-index.md).
> Populated by `/extract-integrations-jobs`. One `RPT-NNN` per report (template: `../_templates/report.md`).

## Report register
| ID | Report | Audience (roles) | Output | Confidence | Status | Source |
|---|---|---|---|---|---|---|
| _(none yet)_ | | | | | | |

---
_(Append full `RPT-NNN` records below, each from the report template.)_
