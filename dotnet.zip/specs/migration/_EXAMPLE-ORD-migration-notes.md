# Migration Notes — Module ORD (Order Management)  ⭐ EXAMPLE (DEV-ONLY)

> Fictional reference showing the **only** place target-stack guidance is allowed. Advisory for developers;
> references the confirmed ORD spec by ID + citation. Back to [migration index](00-migration-index.md).

- **Audience:** developers only · **Source spec:** [../modules/_EXAMPLE-Orders/](../modules/_EXAMPLE-Orders/ORD-00-module-index.md) (Confirmed) · **Status:** Example

## Data → PostgreSQL + JPA
| Entity (ENT) | Target table | Notable column mappings (SQL Server → PostgreSQL) | Keys / identity | Optimistic lock | Cascades |
|---|---|---|---|---|---|
| ENT-Order | `orders` | `Total decimal(18,2)`→`numeric(18,2)`; `PlacedDate datetime`→`timestamp`; `IsDeleted bit`→`boolean` | `OrderId identity`→`GENERATED ALWAYS AS IDENTITY`; unique `order_no` | none in legacy → add `@Version` if needed | Order→OrderLine = `ON DELETE CASCADE` |
| ENT-OrderLine | `order_lines` | `DiscountRate decimal(5,4)`→`numeric(5,4)`; `Subtotal decimal(18,2)`→`numeric(18,2)` | identity | — | line→product = `RESTRICT` |

## Rules → Spring Boot
| Rule/UC | Where it belongs | Notes |
|---|---|---|
| BR-ORD-001 (min total) | `OrderService.placeOrder` validator | Hardcoded 10.00 in legacy — externalize to config. Admin bypass unconfirmed (Q-001). |
| BR-ORD-010/011 (totals) | domain method on `Order`/`OrderLine` | **Replicate `MidpointRounding.AwayFromZero`** with `BigDecimal.setScale(2, RoundingMode.HALF_UP→HALF_EVEN?)` — legacy uses AwayFromZero; use `RoundingMode.HALF_UP` carefully and unit-test. |
| BR-ORD-002 (qty>0) | bean validation `@Min(1)` + service | Was both client+server in legacy; keep server-authoritative. |
| BR-ORD-011 discount cap | server validator | Legacy enforced **client-only** (`[CONFLICT]`) — MUST add server-side check (Q-014). |
| BR-ORD-015 (stock) | `@Transactional placeOrder` | Replace `usp_ReserveStock` with a service/repo method; confirm proc body first (Q-014). |
| BR-ORD-020 (cancel window) | `OrderService.cancel` | Legacy uses `DateTime.Now` (server local) — decide UTC strategy. |
| BR-ORD-030 (soft delete) | JPA `@Where`/global filter | Apply consistently (legacy did per-repository). |

## Screens → Vue
| Screen (SCR) | Suggested view/components | Client vs server validation | Routing / state |
|---|---|---|---|
| SCR-ORD-002 | `OrderEditView` + `OrderLinesTable` + `AddLinePanel` | client computes total for UX; **server re-validates** total/min/discount | route `/orders/:id`; replace `ViewState["Lines"]` with component state, `Session["ReturnUrl"]` with router history |

## Integrations / jobs / reports → target equivalents
| Item | Target approach | Notes |
|---|---|---|
| `usp_ReserveStock` | Spring service + PG function or app-level locking | Confirm proc body before porting (Q-014). |

## Risks & anti-patterns to avoid in the rebuild
- Lazy-loading N+1 on `Order.Lines` — use explicit `JOIN FETCH`.
- Midpoint rounding mismatch (legacy AwayFromZero) — unit-test BR-ORD-010/011 to the cent.
- `DateTime.Now` vs UTC in BR-ORD-020 — pick a timezone policy explicitly.
- Client-only legacy validators (discount cap) must become server rules.

## Open assumptions
- [NEEDS-BUSINESS-INPUT] Admin bypass of minimum total (Q-001); discount cap as a real rule (Q-014).
