---
description: "Extract business rules, calculations, workflows and use cases from one Business-tier module"
agent: agent
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "findTestFiles", "problems", "fetch", "editFiles"]
argument-hint: "targetModule e.g. src/Company.Business/Orders  (one module per run)"
---

# Task: Extract business rules & use cases from a module

Analyze **only** `${input:targetModule}` (use `#codebase` for cross‑references; resolve interfaces to their
bound implementation using the DI graph in `specs/01-system-overview.md`). Follow
`.github/instructions/csharp-bll.instructions.md` and `.github/copilot-instructions.md`. **Read‑only on code.**

## Steps (per public method)
1. Preconditions (guard clauses), the computation/decision, postconditions, side effects.
2. **Validation** rules (thrown business exceptions → capture message verbatim).
3. **Calculations/formulas** — exact formula, operand order, rounding mode, units.
4. **Workflows / state machines** — build the from→event→guard→to transition table.
5. **Invariants** enforced before persist; **transaction boundaries** = atomic operations.
6. **Constants/enums/magic numbers** named as rules; **server‑side authorization** checks.

## Output (emulate `specs/modules/_EXAMPLE-Orders/`)
- `specs/modules/<MOD>/<MOD>-05-business-rules.md` — a `BR-<MOD>-NNN` catalog (summary table + full records from
  `specs/_templates/business-rule.md`), every rule cited and carrying Category, Confidence, Status, Enforcement layer.
- `specs/modules/<MOD>/<MOD>-03-use-cases.md` — `UC-<MOD>-NNN` for each user goal (`specs/_templates/use-case.md`).
- `specs/modules/<MOD>/<MOD>-07-processes.md` — `PRC-<MOD>-NNN` for any workflow/state machine (Mermaid `stateDiagram-v2`).
- **Glossary upkeep:** add any new domain terms/enum vocabulary you encounter to `specs/02-glossary.md`
  (canonical term ↔ legacy code identifier), with a citation.
- Add every `[NEEDS-BUSINESS-INPUT]` to `specs/cross-cutting/13-open-questions.md`; add rows to
  `specs/cross-cutting/12-traceability-matrix.md`; update `specs/00-index.md` coverage.
