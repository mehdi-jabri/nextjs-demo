---
description: 'Pinia store standards using Setup Store syntax with TypeScript'
applyTo: 'stores/**/*.ts'
---

# Pinia Store Instructions

## Setup Store Pattern (Required)

```typescript
import { defineStore } from 'pinia'

export const useUserStore = defineStore('user', () => {
  // 1. State
  const user = ref<User | null>(null)
  const isLoading = ref(false)
  const error = ref<string | null>(null)

  // 2. Getters (computed)
  const isAuthenticated = computed(() => !!user.value)
  const fullName = computed(() => user.value?.name ?? 'Guest')

  // 3. Actions
  async function fetchUser() {
    isLoading.value = true
    error.value = null
    try {
      user.value = await $fetch<User>('/api/user/me')
    } catch (e) {
      error.value = e instanceof Error ? e.message : 'Unknown error'
    } finally {
      isLoading.value = false
    }
  }

  function clearUser() {
    user.value = null
  }

  // 4. Return - expose state as readonly
  return {
    // State (readonly for external access)
    user: readonly(user),
    isLoading: readonly(isLoading),
    error: readonly(error),
    // Getters
    isAuthenticated,
    fullName,
    // Actions
    fetchUser,
    clearUser,
  }
})
```

## Naming Convention

- Store name: `use[Domain]Store`
- File name: `[domain].ts`
- Examples: `useUserStore` in `user.ts`, `useCartStore` in `cart.ts`

## State Exposure

- Use `readonly()` for state to prevent external mutations
- Only mutate state through actions
- Getters are automatically readonly

## Store Composition

```typescript
// Using other stores
export const useCheckoutStore = defineStore('checkout', () => {
  const cartStore = useCartStore()
  const userStore = useUserStore()

  const canCheckout = computed(() => 
    userStore.isAuthenticated && cartStore.totalItems > 0
  )

  return { canCheckout }
})
```

## Guidelines

- Keep stores focused on single domain
- Use TanStack Query for server state caching
- Pinia for UI state and user preferences
