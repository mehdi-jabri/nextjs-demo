# TEMPLATE — Business Rule

> Copy one **summary row** into the module's `*-05-business-rules.md` table, and one **full record** below it.
> Every field marked _required_ must be filled or carry a marker. See `_EXAMPLE-Orders/ORD-05-business-rules.md`.

## Summary row (top-of-catalog table)
```
| ID | Name | Category | Trigger | Confidence | Status | Source |
|----|------|----------|---------|------------|--------|--------|
| BR-<MOD>-NNN | <short name> | <category> | <when evaluated> | High/Medium/Low | Confirmed/Assumed/Needs-business-input/Dead-code? | <file:line> |
```

## Full record
```
### BR-<MOD>-NNN — <short imperative name>
- **Category:** <Validation | Calculation/Derivation | Constraint | Process/Workflow | Authorization | Defaulting | Data integrity | Configuration>   _(required)_
- **Rule type:** Structural/Definitional | Operative/Behavioral
- **Statement:** It is obligatory/prohibited/necessary that <one-sentence plain-language rule>.   _(required)_
- **Trigger / Condition:** <event/screen action/save/schedule that evaluates the rule>   _(required)_
- **Inputs:** <fields/values involved>
- **Logic / Formula / Condition:** <exact formula, operand order, rounding, units; or the precise condition>
- **Action / Outcome:** <what happens when the condition holds (and the else branch if relevant)>   _(required)_
- **Exceptions:** <documented carve-outs / overrides, or "none">
- **Enforcement layer:** UI/Client | Server/BLL | Database | Multiple   _(required — tells the rebuild where to re-implement)_
- **Source location(s):** <file:line> [; <file:line> …]   _(required — one per enforcement point)_
- **Related rules:** <BR-IDs>
- **Related artifacts:** <UC-…, SCR-…, ENT-…>
- **Examples:** <concrete pass example> / <concrete fail example>   _(required for validation & calculation rules)_
- **Confidence:** High | Medium | Low   _(required)_
- **Status:** Confirmed | Assumed | Needs-business-input | Dead-code?   _(required)_
- **Notes:** <edge cases, legacy quirks, [SUSPECTED-BUG], [CONFLICT] details>
```
