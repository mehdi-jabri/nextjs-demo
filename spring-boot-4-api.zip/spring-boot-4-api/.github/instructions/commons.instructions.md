---
applyTo: "**/api/**/*Advice.java,**/exception/**,**/security/**,**/SecurityConfig.java"
description: "Internal common-libs decision tree — never reinvent what the libs provide"
---

**Decision tree (apply BEFORE writing any security or error-handling code):**

1. Is this about web security (authn, authz, CORS, JWT, method-security)?
   → Use `<<org>>-common-security`. Configure via properties (`<<org-prefix>>.security.*`). Do NOT register a `SecurityFilterChain`. See `security.instructions.md` for the rare extension case.

2. Is this about generic error handling (mapping exceptions to HTTP responses)?
   → Use `<<org>>-common-error-handling`. The lib registers a global `@RestControllerAdvice` returning `ProblemDetail`. To map a new domain exception:
   - Extend `<<org>>.commons.errorhandling.DomainException` (or the appropriate subclass).
   - The lib's advice maps it automatically based on the `@ResponseStatus` on your subclass OR a `<<org>>.commons.errorhandling.ErrorCode` enum value.
   - For non-trivial mappings, register a `<<org>>.commons.errorhandling.ExceptionMapper<MyException>` bean (per the lib's contract) — do NOT add a service-local `@RestControllerAdvice`.

3. Is this about something the lib does not yet support?
   → Raise a PR against the lib repo. Do NOT work around it locally — that creates lib drift and erodes the platform.

4. Banned local patterns (forbidden-imports CI gate fails the build):
   - A second `@RestControllerAdvice` in this service.
   - A second `SecurityFilterChain` bean (without the `@AllowLocalSecurityFilterChain` marker + ADR link).
   - Service-local `ProblemDetail` envelope or custom error-response DTO.
   - Service-local CORS filter or `WebMvcConfigurer.addCorsMappings`.

5. Where is the lib's documentation?
   → `docs/dependencies/common-security.md` and `docs/dependencies/common-error-handling.md` (copied at build time from each lib repo). If they are missing, ASK; do not invent the lib's API.

See `docs/snippets/CommonSecurityExtensionExample.java`, `docs/snippets/CommonErrorHandlingExtensionExample.java`.
