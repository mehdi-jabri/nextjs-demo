---
name: vue-shadcn
description: Expert knowledge for Vue 3 Composition API with shadcn-vue component library and Tailwind CSS. Use when building UI components, implementing design systems, or working with Radix Vue primitives.
---

# Vue 3 + shadcn-vue Development Skill

## shadcn-vue Setup

### Installation
```bash
# Initialize shadcn-vue in Nuxt project
npx shadcn-vue@latest init

# Add components
npx shadcn-vue@latest add button
npx shadcn-vue@latest add input
npx shadcn-vue@latest add card
npx shadcn-vue@latest add dialog
npx shadcn-vue@latest add dropdown-menu
npx shadcn-vue@latest add form
```

### Configuration (components.json)
```json
{
  "$schema": "https://shadcn-vue.com/schema.json",
  "style": "new-york",
  "typescript": true,
  "tailwind": {
    "config": "tailwind.config.ts",
    "css": "assets/css/tailwind.css",
    "baseColor": "slate",
    "cssVariables": true
  },
  "framework": "nuxt",
  "aliases": {
    "components": "@/components",
    "utils": "@/lib/utils"
  }
}
```

## Core Component Patterns

### Button Component
```vue
<script setup lang="ts">
import { Button } from '@/components/ui/button'
</script>

<template>
  <div class="flex gap-2">
    <Button>Default</Button>
    <Button variant="secondary">Secondary</Button>
    <Button variant="destructive">Delete</Button>
    <Button variant="outline">Outline</Button>
    <Button variant="ghost">Ghost</Button>
    <Button variant="link">Link</Button>
    
    <!-- Sizes -->
    <Button size="sm">Small</Button>
    <Button size="lg">Large</Button>
    <Button size="icon"><IconPlus /></Button>
    
    <!-- Loading state -->
    <Button :disabled="loading">
      <Loader2 v-if="loading" class="mr-2 h-4 w-4 animate-spin" />
      {{ loading ? 'Loading...' : 'Submit' }}
    </Button>
  </div>
</template>
```

### Input with Form Field
```vue
<script setup lang="ts">
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
</script>

<template>
  <FormField v-slot="{ componentField }" name="email">
    <FormItem>
      <FormLabel>Email</FormLabel>
      <FormControl>
        <Input 
          type="email" 
          placeholder="Enter your email" 
          v-bind="componentField" 
        />
      </FormControl>
      <FormDescription>
        We'll never share your email.
      </FormDescription>
      <FormMessage />
    </FormItem>
  </FormField>
</template>
```

### Card Component
```vue
<script setup lang="ts">
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'
</script>

<template>
  <Card class="w-[350px]">
    <CardHeader>
      <CardTitle>Create Project</CardTitle>
      <CardDescription>
        Deploy your new project in one-click.
      </CardDescription>
    </CardHeader>
    <CardContent>
      <form>
        <div class="grid w-full items-center gap-4">
          <div class="flex flex-col space-y-1.5">
            <Label for="name">Name</Label>
            <Input id="name" placeholder="Project name" />
          </div>
        </div>
      </form>
    </CardContent>
    <CardFooter class="flex justify-between">
      <Button variant="outline">Cancel</Button>
      <Button>Deploy</Button>
    </CardFooter>
  </Card>
</template>
```

### Dialog (Modal)
```vue
<script setup lang="ts">
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from '@/components/ui/dialog'

const open = ref(false)

async function handleSubmit() {
  // Handle submission
  open.value = false
}
</script>

<template>
  <Dialog v-model:open="open">
    <DialogTrigger as-child>
      <Button variant="outline">Edit Profile</Button>
    </DialogTrigger>
    <DialogContent class="sm:max-w-[425px]">
      <DialogHeader>
        <DialogTitle>Edit profile</DialogTitle>
        <DialogDescription>
          Make changes to your profile here.
        </DialogDescription>
      </DialogHeader>
      <div class="grid gap-4 py-4">
        <!-- Form fields -->
      </div>
      <DialogFooter>
        <DialogClose as-child>
          <Button type="button" variant="secondary">Cancel</Button>
        </DialogClose>
        <Button type="submit" @click="handleSubmit">Save changes</Button>
      </DialogFooter>
    </DialogContent>
  </Dialog>
</template>
```

### Dropdown Menu
```vue
<script setup lang="ts">
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
</script>

<template>
  <DropdownMenu>
    <DropdownMenuTrigger as-child>
      <Button variant="outline">Open</Button>
    </DropdownMenuTrigger>
    <DropdownMenuContent class="w-56">
      <DropdownMenuLabel>My Account</DropdownMenuLabel>
      <DropdownMenuSeparator />
      <DropdownMenuGroup>
        <DropdownMenuItem>
          <User class="mr-2 h-4 w-4" />
          <span>Profile</span>
          <DropdownMenuShortcut>⇧⌘P</DropdownMenuShortcut>
        </DropdownMenuItem>
        <DropdownMenuItem>
          <Settings class="mr-2 h-4 w-4" />
          <span>Settings</span>
          <DropdownMenuShortcut>⌘S</DropdownMenuShortcut>
        </DropdownMenuItem>
      </DropdownMenuGroup>
      <DropdownMenuSeparator />
      <DropdownMenuItem class="text-red-600">
        <LogOut class="mr-2 h-4 w-4" />
        <span>Log out</span>
      </DropdownMenuItem>
    </DropdownMenuContent>
  </DropdownMenu>
</template>
```

### Data Table
```vue
<script setup lang="ts">
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'

interface User {
  id: string
  name: string
  email: string
  role: string
}

defineProps<{
  users: User[]
}>()
</script>

<template>
  <Table>
    <TableCaption>A list of your users.</TableCaption>
    <TableHeader>
      <TableRow>
        <TableHead>Name</TableHead>
        <TableHead>Email</TableHead>
        <TableHead>Role</TableHead>
        <TableHead class="text-right">Actions</TableHead>
      </TableRow>
    </TableHeader>
    <TableBody>
      <TableRow v-for="user in users" :key="user.id">
        <TableCell class="font-medium">{{ user.name }}</TableCell>
        <TableCell>{{ user.email }}</TableCell>
        <TableCell>
          <Badge :variant="user.role === 'admin' ? 'default' : 'secondary'">
            {{ user.role }}
          </Badge>
        </TableCell>
        <TableCell class="text-right">
          <Button variant="ghost" size="sm">Edit</Button>
        </TableCell>
      </TableRow>
    </TableBody>
  </Table>
</template>
```

### Toast Notifications
```vue
<script setup lang="ts">
import { useToast } from '@/components/ui/toast/use-toast'

const { toast } = useToast()

function showSuccess() {
  toast({
    title: 'Success!',
    description: 'Your changes have been saved.',
  })
}

function showError() {
  toast({
    title: 'Error',
    description: 'Something went wrong.',
    variant: 'destructive',
  })
}
</script>
```

## Vue 3 Composition API Patterns

### Props & Emits
```vue
<script setup lang="ts">
// Props with defaults
interface Props {
  title: string
  count?: number
  items: string[]
}

const props = withDefaults(defineProps<Props>(), {
  count: 0,
})

// Emits with validation
const emit = defineEmits<{
  submit: [data: FormData]
  update: [id: string, value: string]
  close: []
}>()

// Model (two-way binding)
const model = defineModel<string>()
// Usage: <Component v-model="value" />
</script>
```

### Composable Pattern
```typescript
// composables/useCounter.ts
export function useCounter(initial = 0) {
  const count = ref(initial)
  const double = computed(() => count.value * 2)
  
  function increment() {
    count.value++
  }
  
  function decrement() {
    count.value--
  }
  
  return {
    count: readonly(count),
    double,
    increment,
    decrement,
  }
}
```

### Provide/Inject Pattern
```typescript
// Parent component
import type { InjectionKey, Ref } from 'vue'

interface ThemeContext {
  theme: Ref<'light' | 'dark'>
  toggleTheme: () => void
}

export const ThemeKey: InjectionKey<ThemeContext> = Symbol('theme')

// In parent
const theme = ref<'light' | 'dark'>('light')
provide(ThemeKey, {
  theme,
  toggleTheme: () => {
    theme.value = theme.value === 'light' ? 'dark' : 'light'
  },
})

// In child
const themeContext = inject(ThemeKey)
if (!themeContext) throw new Error('ThemeKey not provided')
```

### Slots Pattern
```vue
<script setup lang="ts">
defineSlots<{
  default(props: { item: Item }): any
  header(): any
  footer(): any
}>()
</script>

<template>
  <div>
    <header>
      <slot name="header" />
    </header>
    <main>
      <slot :item="currentItem" />
    </main>
    <footer>
      <slot name="footer" />
    </footer>
  </div>
</template>
```

## Tailwind CSS Patterns

### Responsive Design
```vue
<template>
  <div class="
    grid 
    grid-cols-1 
    sm:grid-cols-2 
    md:grid-cols-3 
    lg:grid-cols-4 
    gap-4
  ">
    <!-- Responsive grid -->
  </div>
</template>
```

### Dark Mode
```vue
<template>
  <!-- Automatic dark mode -->
  <div class="bg-white dark:bg-gray-900 text-black dark:text-white">
    <h1 class="text-gray-900 dark:text-gray-100">
      Dark mode support
    </h1>
  </div>
</template>
```

### Custom Utility Classes
```css
/* assets/css/tailwind.css */
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer components {
  .btn-primary {
    @apply bg-primary text-primary-foreground hover:bg-primary/90
      px-4 py-2 rounded-md font-medium transition-colors;
  }
  
  .card-hover {
    @apply hover:shadow-lg transition-shadow duration-200;
  }
}
```

### cn() Utility for Class Merging
```typescript
// lib/utils.ts
import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Usage
<div :class="cn(
  'base-class',
  variant === 'primary' && 'bg-primary',
  className
)">
```

## Component Best Practices

1. **Single Responsibility** - One component, one purpose
2. **Props Down, Events Up** - Unidirectional data flow
3. **Use TypeScript** - Define prop and emit types
4. **Composables for Logic** - Extract reusable logic
5. **Consistent Naming** - PascalCase for components
6. **Accessible by Default** - Use Radix primitives
7. **Lazy Load** - Heavy components on demand
8. **Error Boundaries** - Handle component errors gracefully
