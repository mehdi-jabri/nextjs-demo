---
applyTo: "**/config/**/*.java,**/application*.yml,**/application*.yaml"
description: "Configuration conventions"
---

- One `@Configuration` class per concern: `RedisConfig`, `ObservabilityConfig`, `KeyVaultConfig`, `HttpClientsConfig`, `SoapClientsConfig`, `OpenApiConfig`. Security is provided by `<<org>>-common-security` — NO `SecurityConfig` in the service unless extending the lib's documented extension point.
- Property prefix per concern: `<<org-prefix>>.<<service-name>>.<concern>.*`. Bind with `@ConfigurationProperties` records (`@ConstructorBinding` is implicit on records in Boot 4).
- All public configuration properties are documented in `README.md` § Configuration with default, profile applicability, and source (Key Vault vs static).
- Profiles: `local`, `dev`, `staging`, `prod`. Never put secrets in any committed YAML.
- Key Vault: secrets resolved via `${<<org-prefix>>.keyvault.<name>}` — the property source is registered by the Azure starter; do not read `KeyVaultClient` directly in code.
- `@Bean` methods: lower-case method names match bean names; prefer `@Bean` over `@Component` for explicitness.
- One `@Bean` per logical thing — no factory methods returning collections of beans.
- `application.yml` is the default; `application-<profile>.yml` overrides only what differs. Never duplicate the entire config across profiles.
- See `docs/snippets/RedisCacheConfigExample.java`, `docs/snippets/HttpClientsConfigExample.java`.
