---
description: "Run the boot4-upgrade-checker agent's checklist over the current diff"
mode: agent
---

Switch to the `boot4-upgrade-checker` agent. Run its checklist over the current diff (or the files the user provides).

Output the report in the format the agent specifies. End with the merge recommendation.

If any BLOCKER is found, propose the smallest fix (one paragraph per blocker, with the exact replacement code). Do NOT modify files.
