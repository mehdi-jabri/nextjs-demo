---
applyTo: "**/SecurityConfig.java,**/security/**"
description: "Security — anchored to <<org>>-common-security; rare service-local extensions only"
---

**Default rule: do not write security configuration in this service.** Web security is provided by `<<org>>-common-security`. Configure it via properties; do not register a `SecurityFilterChain` bean.

Lib extension points (documented in the lib's README — confirm against the actual version pinned in the parent BOM):
- `<<org-prefix>>.security.public-paths` — list of ant patterns made public.
- `<<org-prefix>>.security.cors.*` — CORS overrides (origins, methods, headers).
- `<<org-prefix>>.security.method-security.enabled` — method-security toggle.
- `<<org-prefix>>.security.audience` / `issuer-uri` — JWT resource-server settings.

When a service-local `SecurityFilterChain` is unavoidable (rare):
- File requires the `@AllowLocalSecurityFilterChain` marker annotation (defined locally) AND a linked ADR explaining why the lib's extension points are insufficient.
- The local chain MUST declare `@Order(Ordered.HIGHEST_PRECEDENCE)` AND a narrow `securityMatcher(...)` so it does not override the lib's chain globally.
- Document the deviation in `README.md` § Security.

Banned in any case:
- `WebSecurityConfigurerAdapter` (removed in Spring Security 6+).
- `@EnableGlobalMethodSecurity` (use `@EnableMethodSecurity`).
- Custom JWT decoders that bypass the lib's audience/issuer validation.
- Custom CORS filters when the lib's CORS config can express the requirement.

Method security:
- `@PreAuthorize("hasRole('ADMIN')")` and `@PreAuthorize("@accessGuard.canRead(#id, authentication)")` are the two acceptable forms. Reach for SpEL bean references when the rule is non-trivial.
- Do NOT mix annotation-based and DSL-based authorisation in the same module.

See `docs/snippets/CommonSecurityExtensionExample.java`.
