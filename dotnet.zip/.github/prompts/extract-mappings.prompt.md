---
description: "Extract business logic hidden in AutoMapper profiles (MapFrom, resolvers, AfterMap)"
agent: agent
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "findTestFiles", "problems", "fetch", "editFiles"]
argument-hint: "targetFolder e.g. src/Company.Web/Mapping  (or a profile file)"
---

# Task: Extract rules from AutoMapper profiles

Analyze `${input:targetFolder}`. Follow `.github/instructions/di-mapping.instructions.md` and
`.github/copilot-instructions.md`. **Read‑only.**

## Steps
1. Read every `Profile` / `CreateMap`.
2. Capture each `ForMember(...).MapFrom(...)` expression (a derivation rule), every `.Ignore()` (field not
   exposed), and **fully read** custom `IValueResolver`/`ITypeConverter`, `BeforeMap`/`AfterMap`,
   `ConstructUsing`/`ConvertUsing`, and conditional `Condition(...)` logic.

## Output
- Each `MapFrom`/resolver/`AfterMap` business rule → a `BR-… Calculation` entry in the relevant module catalog,
  cited to `file:line`.
- `.Ignore()` fields → note in `specs/cross-cutting/10-security-authorization.md` (data not exposed) where they
  look security/PII‑related.
- Keep the DTO↔entity field‑mapping tables in **Developer Notes** of the relevant screen/use‑case docs.
- Update coverage rows in `specs/00-index.md`.
