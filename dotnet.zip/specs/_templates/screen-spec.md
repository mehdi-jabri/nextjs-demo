# TEMPLATE — Screen / UI Specification (Web Forms page or control)

> One `SCR-<MOD>-NNN` per `.aspx`/`.ascx`, in `*-04-screens/`. See `_EXAMPLE-Orders/ORD-04-screens/`.

```
# Screen Spec — SCR-<MOD>-NNN: <page title>
- **Source page:** <Page.aspx> · **Code-behind:** <Page.aspx.cs> · **Master:** <Site.Master>
- **URL / route:** <Page.aspx?param=>
- **Actors with access:** <roles> (see D10) · **Authorization source:** <web.config / Page_Load check file:line>
- **Related use cases:** UC-… · **Related rules:** BR-… · **Related entities:** ENT-…
- **Confidence:** … · **Status:** …

## Purpose
<Plain language: what the user accomplishes here.>

## Layout / wireframe (textual)
<Regions: header, grid, form panel, action bar.>

## Controls inventory
| Control ID | Label | Type | Bound field (D6) | Required? | Validation rules | Default | Visible/Enabled when | Source (file:line) |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |

## Actions / buttons
| Action | Trigger | Behavior | Rules | Navigates to | Source |
|---|---|---|---|---|---|
| | | | BR-… | | |

## Field-level validation detail
| Field | Rule | Message shown | Server/Client | Source |
|---|---|---|---|---|
| | | | | |

## Navigation in / out
```mermaid
flowchart LR
  Prev[SCR-…] -->|action| This[SCR-<MOD>-NNN]
  This -->|action| Next[SCR-…]
```

## Conditional UI / dynamic behavior
- When <condition>, <control> becomes hidden/disabled — Source: <file:line> — Rule: BR-…

## State used
| Key | Store (Session/ViewState/hidden/Cache) | Set when | Read when | Supports rule |
|---|---|---|---|---|

## Open questions
- [UNVERIFIED] / [NEEDS-BUSINESS-INPUT] <…>

## Developer Notes (legacy)
<ViewState usage, postback model, UpdatePanel/AJAX, grid binding code.>
```
> Target‑stack (Vue) rebuild guidance is **not** written here — it lives only in `specs/migration/`
> and is produced by `/migration-notes`.
