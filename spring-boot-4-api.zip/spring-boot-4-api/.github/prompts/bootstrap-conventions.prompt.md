---
description: "Extract this repo's actual conventions and append to .github/copilot-instructions.md"
mode: agent
---

Goal: discover conventions that exist in code but are not yet written down, and append them to `.github/copilot-instructions.md` under a new section "## Repo-specific conventions".

Do NOT invent conventions. Only record patterns you can point to with `file:line` evidence.

Investigate (cite `file:line` for each finding):

1. Package layout under `src/main/java/**` — confirm or correct the assumed `api/application/domain/infrastructure/config` split.
2. Controllers — return types, validation placement, error mapping, OpenAPI annotation style.
3. Application services — transaction boundaries, port interface naming, where virtual threads are used.
4. Domain — record vs class, sealed hierarchies, domain event patterns.
5. Infrastructure — JPA repository naming, custom impl pattern, query style; Redis cache name list with TTLs; HTTP/SOAP gateway pattern.
6. Configuration — `application.yml` structure, profiles, property prefixes, Key Vault property source order.
7. Security — confirm `<<org>>-common-security` is the source; list any service-local extensions and their justification.
8. Error handling — confirm `<<org>>-common-error-handling` is the source; list domain exceptions and their `ErrorCode` mapping.
9. Mapping — MapStruct vs hand-rolled, mapper component model, common helpers.
10. SOAP (if present) — list each consumed service, WSDL path, generated package, gateway class, fault-mapping convention.
11. Tests — slice test convention (`@WebMvcTest` + `@MockitoBean`?), pure unit test convention (`@ExtendWith(MockitoExtension.class)`), naming, fixture classes.
12. Build/Docker — Maven/Gradle, plugin versions, Dockerfile base image, JLink/AOT use.
13. Observability — Micrometer config, log format, App Insights connection-string source.
14. Resilience — Resilience4j configs, circuit-breaker names, retry policies.
15. OpenAPI — code-first or contract-first? Where is the spec? Which annotations are consistently used?

For each, write 1–3 lines in this form:
- "Controllers return `ResponseEntity<T>` (e.g., `OrderController.java:42`)."

If a finding contradicts an existing rule in `.github/copilot-instructions.md`, FLAG it at the top of your output — do NOT silently overwrite. Append the rest under "## Repo-specific conventions" and stop.

Do NOT modify any other file. Do NOT generate code. This is a read-and-document task only.
