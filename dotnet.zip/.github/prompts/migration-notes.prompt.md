---
description: "Produce DEV-ONLY rebuild guidance (Spring Boot + Vue + PostgreSQL) for a module, into specs/migration/"
agent: analyst
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "editFiles"]
argument-hint: "targetModule e.g. ORD"
---

# Task: Write migration notes for the dev team

Produce target‑stack rebuild guidance for `${input:targetModule}`. This is the **only** place target‑stack
content may appear — write it under `specs/migration/`, **never** in the `specs/` business body. Run this
only **after** the module's English spec is `Confirmed`. Follow `.github/copilot-instructions.md`.

## Inputs (read, do not duplicate)
The confirmed module spec: business rules, use cases, screens, data dictionary, processes — referenced by ID.

## Produce `specs/migration/<MOD>-migration-notes.md` (from `specs/_templates/migration-notes.md`)
- **Domain → JPA:** each `ENT-…` → JPA entity/table; the SQL Server→PostgreSQL type mapping (use the table in
  `.github/instructions/data-ef6.instructions.md`); keys/sequences/identity; optimistic‑lock column; cascades.
- **Services → Spring Boot:** each business rule/use case (`BR-…`/`UC-…`) → where it should live (controller/
  service/validator/domain), transaction boundaries, and **rules that must be re‑implemented server‑side**
  (e.g. client‑only legacy validators → mandatory server validation).
- **Screens → Vue:** each `SCR-…` → suggested Vue view/components, client vs. server validation split,
  navigation/routing, state handling (replacing ViewState/Session).
- **Integrations/jobs/reports → target equivalents**, and **risks/anti‑patterns to avoid** (lazy‑loading N+1,
  `DateTime.Now` vs. UTC, midpoint rounding differences, soft‑delete filters).
- Reference every item back to its spec **ID and citation**; do not restate business behavior — link to it.
- Mark anything uncertain `[ASSUMPTION]`/`[NEEDS-BUSINESS-INPUT]`. This is advisory; the dev team decides.

## Output
The per‑module migration notes file plus an updated `specs/migration/00-migration-index.md`. Do **not** edit
any business doc under `specs/` while doing this.
