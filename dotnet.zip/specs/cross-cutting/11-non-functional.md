# 11 — Non-Functional Requirements

> **Status:** Not started · **Last updated:** _(date)_ · Back to [index](../00-index.md).
> Observed or implied NFRs, each cited. Always probe: Performance, Volume/scale, Concurrency, Retention/archival,
> Audit/logging, Localization/i18n, Availability, Compliance/regulatory, Browser support.

| NFR ID | Category | Requirement (observed or implied) | Evidence / Source | Confidence | Status |
|---|---|---|---|---|---|
| _(example)_ NFR-PERF-001 | Performance | Grids page 25 rows server‑side | `ProductList.aspx:80` | High | Confirmed |
| _(example)_ NFR-AUD-001 | Audit | CreatedBy/ModifiedBy stamped on save | `BaseEntity.cs:12` | High | Confirmed |
| | | | | | |
