# 12 — Traceability Matrix

> **Status:** Not started · **Last updated:** _(date)_ · Back to [index](../00-index.md).
>
> The bidirectional chain so reviewers can verify coverage and developers know provenance:
> **Source code (file:line) → Business Rule (BR) → Requirement/Use Case (UC) → Screen (SCR) → Entity (ENT) →
> Acceptance Criterion (AC) → Rebuild artifact (filled by the dev team later)**. IDs are the linking keys.

## Forward matrix
| Source (file:line) | Artifact type | Rule(s) | Use case (UC) | Screen (SCR) | Entity (ENT) | NFR/Sec | AC | Confidence | Status |
|---|---|---|---|---|---|---|---|---|---|
| _(example)_ `OrderService.cs:55` | BLL method | BR-ORD-001 | UC-ORD-003 | SCR-ORD-002 | ENT-Order | — | AC1 | High | Confirmed |
| | | | | | | | | | |

## Orphan reports (must be empty or justified at Done)
- **Rules with no requirement:** _(list)_
- **Requirements with no rule:** _(list)_
- **Screens with no use case:** _(list)_
- **Entities with no rule:** _(list)_
