# TEMPLATE — Use Case

> One `UC-<MOD>-NNN` per user goal, in the module's `*-03-use-cases.md`. See `_EXAMPLE-Orders/ORD-03-use-cases.md`.

```
## UC-<MOD>-NNN: <use case name>
- **Status:** Confirmed | Assumed | Needs-business-input
- **Confidence:** High | Medium | Low
- **Actors:** <primary>, <secondary>
- **Source:** <file:line>; <ServiceMethod(): file:line>
- **Related rules:** BR-… · **Related screens:** SCR-… · **Related entities:** ENT-…

### Description
<Plain-language goal from the user's perspective — one sentence first, then detail.>

### Preconditions
- <state that must hold> — Source: <file:line>

### Main flow (happy path)
| Step | Actor action | System response | Rules invoked | Source |
|------|--------------|-----------------|---------------|--------|
| 1 | | | BR-… | <file:line> |

### Alternative flows
- **A1 — <name>:** at step <n>, if <condition> then <behavior>. Source: <file:line>

### Exception flows
- **E1 — <name>:** <condition> → <behavior/message>. Source: <file:line>

### Postconditions
- <resulting state> — Source: <file:line>

### Acceptance criteria (verifiable, "shall" form)
- AC1: The system **shall** <verifiable behavior>. (verifies BR-…)

### Open questions
- [NEEDS-BUSINESS-INPUT] <question>

## Developer Notes (legacy)
<EF queries, Ninject bindings, AutoMapper profiles, ViewState/postback mechanics relevant to this UC.>
```
> Target‑stack (Spring Boot/Vue/PostgreSQL) rebuild guidance is **not** written here — it lives only in
> `specs/migration/` and is produced by `/migration-notes`.
