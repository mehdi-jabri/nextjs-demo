---
description: 'Vue 3 component standards using Composition API, TypeScript, and shadcn-vue patterns'
applyTo: '**/*.vue'
---

# Vue Component Instructions (Nuxt 4)

In Nuxt 4, components are in `app/components/` by default.

## Required Structure

Use `<script setup lang="ts">` exclusively:

```vue
<script setup lang="ts">
// 1. Imports
import { Button } from '@/components/ui/button'

// 2. Props with types
interface Props {
  title: string
  count?: number
}
const props = withDefaults(defineProps<Props>(), {
  count: 0,
})

// 3. Emits with types
const emit = defineEmits<{
  submit: [data: FormData]
}>()

// 4. Composables & State
const route = useRoute()
const isLoading = ref(false)

// 5. Computed
const displayTitle = computed(() => props.title.toUpperCase())

// 6. Methods
async function handleSubmit() {
  // Implementation
}

// 7. Lifecycle
onMounted(() => {
  // Setup
})
</script>
```

## TypeScript Requirements

- Always type props with `defineProps<T>()`
- Always type emits with `defineEmits<T>()`
- Type slots with `defineSlots<T>()`
- No `any` types without justification

## Styling

- Use Tailwind CSS classes
- Use `cn()` utility for conditional classes
- Support dark mode with `dark:` variants
- Mobile-first responsive design

## Accessibility

- Use semantic HTML elements
- Include ARIA attributes where needed
- Ensure keyboard navigation
- Support screen readers

## State Handling

- Handle loading states
- Handle error states  
- Handle empty states
- Check for `undefined` (Nuxt 4 default for data/error)

## Data Fetching (Nuxt 4)

```typescript
// Data defaults to undefined (not null)
const { data, pending, error } = await useFetch('/api/resource')

if (data.value === undefined) {
  // Not yet fetched
}

// Use deep: true if mutating nested properties
const { data } = await useFetch('/api/resource', { deep: true })

// Reactive keys for auto-refetching
const id = ref('123')
const { data } = await useFetch(
  () => `/api/users/${id.value}`,
  { key: () => `user-${id.value}` }
)
```
