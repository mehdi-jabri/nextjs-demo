---
name: ui-ux-design
description: Expert knowledge for UI/UX design systems, accessibility, responsive design, and user experience patterns. Use when designing interfaces, improving usability, or implementing design systems.
---

# UI/UX Design Skill

## Design System Architecture

### Design Tokens
```css
/* assets/css/tokens.css */
:root {
  /* Colors - Light Mode */
  --background: 0 0% 100%;
  --foreground: 222.2 84% 4.9%;
  --card: 0 0% 100%;
  --card-foreground: 222.2 84% 4.9%;
  --primary: 222.2 47.4% 11.2%;
  --primary-foreground: 210 40% 98%;
  --secondary: 210 40% 96.1%;
  --secondary-foreground: 222.2 47.4% 11.2%;
  --muted: 210 40% 96.1%;
  --muted-foreground: 215.4 16.3% 46.9%;
  --accent: 210 40% 96.1%;
  --accent-foreground: 222.2 47.4% 11.2%;
  --destructive: 0 84.2% 60.2%;
  --destructive-foreground: 210 40% 98%;
  --border: 214.3 31.8% 91.4%;
  --input: 214.3 31.8% 91.4%;
  --ring: 222.2 84% 4.9%;
  
  /* Spacing */
  --spacing-xs: 0.25rem;
  --spacing-sm: 0.5rem;
  --spacing-md: 1rem;
  --spacing-lg: 1.5rem;
  --spacing-xl: 2rem;
  --spacing-2xl: 3rem;
  
  /* Border Radius */
  --radius-sm: 0.25rem;
  --radius-md: 0.5rem;
  --radius-lg: 0.75rem;
  --radius-xl: 1rem;
  --radius-full: 9999px;
  
  /* Shadows */
  --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  --shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
  --shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1);
  
  /* Transitions */
  --transition-fast: 150ms;
  --transition-normal: 200ms;
  --transition-slow: 300ms;
}

.dark {
  --background: 222.2 84% 4.9%;
  --foreground: 210 40% 98%;
  --card: 222.2 84% 4.9%;
  --card-foreground: 210 40% 98%;
  --primary: 210 40% 98%;
  --primary-foreground: 222.2 47.4% 11.2%;
  /* ... dark mode tokens */
}
```

### Typography Scale
```typescript
// tailwind.config.ts
export default {
  theme: {
    extend: {
      fontSize: {
        'display-2xl': ['4.5rem', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
        'display-xl': ['3.75rem', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
        'display-lg': ['3rem', { lineHeight: '1.2', letterSpacing: '-0.02em' }],
        'display-md': ['2.25rem', { lineHeight: '1.25', letterSpacing: '-0.02em' }],
        'display-sm': ['1.875rem', { lineHeight: '1.3' }],
        'display-xs': ['1.5rem', { lineHeight: '1.4' }],
        'body-xl': ['1.25rem', { lineHeight: '1.6' }],
        'body-lg': ['1.125rem', { lineHeight: '1.6' }],
        'body-md': ['1rem', { lineHeight: '1.6' }],
        'body-sm': ['0.875rem', { lineHeight: '1.5' }],
        'body-xs': ['0.75rem', { lineHeight: '1.5' }],
      },
    },
  },
}
```

## Responsive Design

### Breakpoint Strategy
```vue
<template>
  <!-- Mobile First Approach -->
  <div class="
    grid
    grid-cols-1
    sm:grid-cols-2
    md:grid-cols-3
    lg:grid-cols-4
    xl:grid-cols-5
    gap-4
    sm:gap-6
    lg:gap-8
  ">
    <Card v-for="item in items" :key="item.id" />
  </div>
  
  <!-- Responsive Typography -->
  <h1 class="
    text-display-xs
    sm:text-display-sm
    md:text-display-md
    lg:text-display-lg
  ">
    Headline
  </h1>
  
  <!-- Responsive Spacing -->
  <section class="
    px-4 py-8
    sm:px-6 sm:py-12
    lg:px-8 lg:py-16
    xl:px-12 xl:py-24
  ">
    Content
  </section>
</template>
```

### Container Queries
```css
/* Modern container queries */
.card-container {
  container-type: inline-size;
}

@container (min-width: 400px) {
  .card {
    display: grid;
    grid-template-columns: 1fr 2fr;
  }
}

@container (min-width: 600px) {
  .card {
    grid-template-columns: 1fr 3fr;
  }
}
```

### Responsive Navigation
```vue
<script setup lang="ts">
const isMenuOpen = ref(false)
const isMobile = useMediaQuery('(max-width: 768px)')
</script>

<template>
  <nav class="relative">
    <!-- Desktop Navigation -->
    <div class="hidden md:flex items-center space-x-8">
      <NuxtLink 
        v-for="item in navItems" 
        :key="item.href"
        :to="item.href"
        class="text-sm font-medium hover:text-primary transition-colors"
      >
        {{ item.label }}
      </NuxtLink>
    </div>
    
    <!-- Mobile Menu Button -->
    <Button
      class="md:hidden"
      variant="ghost"
      size="icon"
      @click="isMenuOpen = !isMenuOpen"
      :aria-expanded="isMenuOpen"
      aria-controls="mobile-menu"
    >
      <Menu v-if="!isMenuOpen" class="h-6 w-6" />
      <X v-else class="h-6 w-6" />
    </Button>
    
    <!-- Mobile Navigation -->
    <Transition
      enter-active-class="transition duration-200 ease-out"
      enter-from-class="opacity-0 -translate-y-2"
      enter-to-class="opacity-100 translate-y-0"
      leave-active-class="transition duration-150 ease-in"
      leave-from-class="opacity-100 translate-y-0"
      leave-to-class="opacity-0 -translate-y-2"
    >
      <div
        v-if="isMenuOpen && isMobile"
        id="mobile-menu"
        class="absolute top-full left-0 right-0 bg-background border shadow-lg"
      >
        <NuxtLink
          v-for="item in navItems"
          :key="item.href"
          :to="item.href"
          class="block px-4 py-3 hover:bg-muted"
          @click="isMenuOpen = false"
        >
          {{ item.label }}
        </NuxtLink>
      </div>
    </Transition>
  </nav>
</template>
```

## Accessibility (a11y)

### ARIA Patterns
```vue
<!-- Accessible Button -->
<Button
  :aria-pressed="isActive"
  :aria-label="label"
  :aria-describedby="descriptionId"
  @click="toggle"
>
  <Icon :name="iconName" aria-hidden="true" />
  <span class="sr-only">{{ label }}</span>
</Button>

<!-- Accessible Form -->
<form @submit.prevent="handleSubmit" aria-labelledby="form-title">
  <h2 id="form-title">Contact Form</h2>
  
  <div>
    <Label for="email">Email</Label>
    <Input
      id="email"
      type="email"
      aria-required="true"
      :aria-invalid="!!errors.email"
      :aria-describedby="errors.email ? 'email-error' : undefined"
    />
    <p v-if="errors.email" id="email-error" role="alert" class="text-destructive">
      {{ errors.email }}
    </p>
  </div>
</form>

<!-- Accessible Dialog -->
<Dialog>
  <DialogTrigger as-child>
    <Button>Open Dialog</Button>
  </DialogTrigger>
  <DialogContent
    aria-labelledby="dialog-title"
    aria-describedby="dialog-description"
  >
    <DialogHeader>
      <DialogTitle id="dialog-title">Confirm Action</DialogTitle>
      <DialogDescription id="dialog-description">
        This action cannot be undone.
      </DialogDescription>
    </DialogHeader>
    <!-- Content -->
  </DialogContent>
</Dialog>
```

### Keyboard Navigation
```vue
<script setup lang="ts">
const menuItems = ref<HTMLElement[]>([])
const currentIndex = ref(0)

function handleKeyDown(event: KeyboardEvent) {
  switch (event.key) {
    case 'ArrowDown':
      event.preventDefault()
      currentIndex.value = (currentIndex.value + 1) % menuItems.value.length
      menuItems.value[currentIndex.value]?.focus()
      break
    case 'ArrowUp':
      event.preventDefault()
      currentIndex.value = (currentIndex.value - 1 + menuItems.value.length) % menuItems.value.length
      menuItems.value[currentIndex.value]?.focus()
      break
    case 'Home':
      event.preventDefault()
      currentIndex.value = 0
      menuItems.value[0]?.focus()
      break
    case 'End':
      event.preventDefault()
      currentIndex.value = menuItems.value.length - 1
      menuItems.value[currentIndex.value]?.focus()
      break
    case 'Escape':
      closeMenu()
      break
  }
}
</script>
```

### Focus Management
```typescript
// composables/useFocusTrap.ts
export function useFocusTrap(containerRef: Ref<HTMLElement | null>) {
  const previousFocus = ref<HTMLElement | null>(null)

  function getFocusableElements() {
    if (!containerRef.value) return []
    return containerRef.value.querySelectorAll<HTMLElement>(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    )
  }

  function trapFocus(event: KeyboardEvent) {
    if (event.key !== 'Tab' || !containerRef.value) return

    const focusable = getFocusableElements()
    const first = focusable[0]
    const last = focusable[focusable.length - 1]

    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault()
      last?.focus()
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault()
      first?.focus()
    }
  }

  function activate() {
    previousFocus.value = document.activeElement as HTMLElement
    document.addEventListener('keydown', trapFocus)
    nextTick(() => getFocusableElements()[0]?.focus())
  }

  function deactivate() {
    document.removeEventListener('keydown', trapFocus)
    previousFocus.value?.focus()
  }

  return { activate, deactivate }
}
```

### Screen Reader Only Content
```css
/* Visually hidden but accessible to screen readers */
.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}
```

## Animation & Motion

### Subtle Transitions
```vue
<template>
  <!-- Hover animations -->
  <Button class="
    transition-all
    duration-200
    hover:scale-105
    hover:shadow-lg
    active:scale-95
  ">
    Interactive
  </Button>
  
  <!-- Fade transitions -->
  <Transition
    enter-active-class="transition-opacity duration-200"
    enter-from-class="opacity-0"
    enter-to-class="opacity-100"
    leave-active-class="transition-opacity duration-150"
    leave-from-class="opacity-100"
    leave-to-class="opacity-0"
  >
    <div v-if="show">Content</div>
  </Transition>
  
  <!-- Slide animations -->
  <Transition
    enter-active-class="transition-all duration-300 ease-out"
    enter-from-class="opacity-0 translate-y-4"
    enter-to-class="opacity-100 translate-y-0"
    leave-active-class="transition-all duration-200 ease-in"
    leave-from-class="opacity-100 translate-y-0"
    leave-to-class="opacity-0 translate-y-4"
  >
    <div v-if="show">Sliding content</div>
  </Transition>
</template>
```

### Reduced Motion
```css
/* Respect user preferences */
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

```vue
<script setup lang="ts">
const prefersReducedMotion = useMediaQuery('(prefers-reduced-motion: reduce)')

const transitionDuration = computed(() => 
  prefersReducedMotion.value ? 0 : 200
)
</script>
```

## Loading States

### Skeleton Loaders
```vue
<template>
  <div v-if="isLoading" class="space-y-4">
    <Skeleton class="h-12 w-full" />
    <Skeleton class="h-4 w-3/4" />
    <Skeleton class="h-4 w-1/2" />
  </div>
  <div v-else>
    <h1>{{ title }}</h1>
    <p>{{ description }}</p>
  </div>
</template>
```

### Progress Indicators
```vue
<template>
  <!-- Spinner -->
  <Loader2 class="h-4 w-4 animate-spin" />
  
  <!-- Progress bar -->
  <Progress :value="progress" class="w-full" />
  
  <!-- Indeterminate loading -->
  <div class="h-1 w-full bg-muted overflow-hidden">
    <div class="h-full bg-primary animate-indeterminate" />
  </div>
</template>

<style>
@keyframes indeterminate {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(400%); }
}
.animate-indeterminate {
  width: 30%;
  animation: indeterminate 1.5s infinite ease-in-out;
}
</style>
```

## UX Patterns

### Empty States
```vue
<template>
  <div v-if="items.length === 0" class="text-center py-12">
    <Inbox class="mx-auto h-12 w-12 text-muted-foreground" />
    <h3 class="mt-4 text-lg font-semibold">No items yet</h3>
    <p class="mt-2 text-muted-foreground">
      Get started by creating your first item.
    </p>
    <Button class="mt-6" @click="openCreateDialog">
      <Plus class="mr-2 h-4 w-4" />
      Create Item
    </Button>
  </div>
</template>
```

### Error States
```vue
<template>
  <div v-if="error" class="rounded-lg border border-destructive/50 p-4">
    <div class="flex items-start gap-4">
      <AlertCircle class="h-5 w-5 text-destructive mt-0.5" />
      <div class="flex-1">
        <h4 class="font-semibold text-destructive">Something went wrong</h4>
        <p class="mt-1 text-sm text-muted-foreground">{{ error.message }}</p>
        <div class="mt-4 flex gap-2">
          <Button variant="outline" size="sm" @click="retry">
            Try Again
          </Button>
          <Button variant="ghost" size="sm" @click="dismiss">
            Dismiss
          </Button>
        </div>
      </div>
    </div>
  </div>
</template>
```

### Confirmation Actions
```vue
<script setup lang="ts">
async function handleDelete() {
  const confirmed = await confirm({
    title: 'Delete Item',
    description: 'This action cannot be undone. Are you sure?',
    confirmText: 'Delete',
    cancelText: 'Cancel',
    variant: 'destructive',
  })
  
  if (confirmed) {
    await deleteItem()
    toast({ title: 'Item deleted' })
  }
}
</script>
```

## Best Practices

1. **Mobile-first** - Design for small screens first
2. **Consistent spacing** - Use design tokens
3. **Accessible by default** - ARIA, keyboard, focus
4. **Meaningful animations** - Purpose over flash
5. **Respect preferences** - Dark mode, reduced motion
6. **Clear feedback** - Loading, success, error states
7. **Progressive disclosure** - Show what's needed
8. **Touch-friendly** - 44px minimum touch targets
