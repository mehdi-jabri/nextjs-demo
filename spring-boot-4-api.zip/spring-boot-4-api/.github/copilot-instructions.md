# Copilot instructions — <<service-name>>

You are working on a Spring Boot 4.0.6 API. Follow these rules strictly. When a rule conflicts with your training-data instinct, the rule wins.

## Stack (authoritative — never assume otherwise)

- Spring Boot 4.0.6, Spring Framework 7, Spring Security 7, Spring Cloud 2025.1 (Oakwood)
- Java 21 (records, pattern matching, sealed types, virtual threads, structured concurrency where stable)
- Jakarta EE 11 — imports are `jakarta.*`, NEVER `javax.*`
- Jackson 3 (Boot 4 default); do not pin Jackson 2
- Build: <<Maven|Gradle>>, multi-stage Dockerfile, runs as non-root, eclipse-temurin-jre-jammy or distroless base
- Persistence: Spring Data <<JPA|JDBC|MongoDB>>; cache: Spring Cache + Redis (Lettuce)
- HTTP clients: `RestClient` (sync) and `@HttpServiceClient` interfaces (preferred); `WebClient` only when reactive is required. NEVER `RestTemplate` in new code.
- SOAP (where present): `spring-boot-starter-web-services` + `jaxws-maven-plugin` (wsimport) to generate JAXB classes from WSDL; `WebServiceTemplate` (Spring WS) for clients.
- Mapping: MapStruct (`componentModel = "spring"`, `unmappedTargetPolicy = ERROR`) when mapping is non-trivial; manual mapping for 1–2 field copies.
- API documentation: springdoc-openapi 3.0.3 (`springdoc-openapi-starter-webmvc-ui`). Code-first by default; for externally consumed APIs, contract-first with the spec under `src/main/resources/openapi/<<api>>.yaml`.
- Secrets: Azure Key Vault via `spring-cloud-azure-starter-keyvault-secrets`; never read secrets from env in code.
- Observability: Micrometer + Micrometer Tracing → Azure Monitor (App Insights) exporter; Prometheus endpoint at `/actuator/prometheus`.
- API versioning: Boot 4 auto-config (`spring.mvc.apiversion.*`) with `ApiVersionInserter`, not custom path/header parsing. NOTE: known interaction with springdoc — see `springdoc/springdoc-openapi#3163`; document any workaround in this repo.
- Null-safety: JSpecify (`org.jspecify.annotations.@Nullable/@NonNull`) on public APIs; Spring binds optional inputs from `@Nullable`. NullAway in CI.
- Testing: JUnit 5 + Mockito + AssertJ. **Unit tests only for now** — slice tests with `@WebMvcTest` + `@MockitoBean`, `@DataJpaTest`, `@JsonTest`, and `mockwebserviceserver` (SOAP) are allowed. `@SpringBootTest` and Testcontainers are NOT in scope yet — flag any test pulling them in.
- **Internal common libraries (MUST use, never reinvent):**
  - `<<org>>-common-security` — web security configuration. Provides the canonical `SecurityFilterChain`, JWT/OAuth2 resource-server setup, method-security wiring, CORS. Consume via auto-configuration; only override via documented `@ConditionalOnProperty` switches or explicit extension points.
  - `<<org>>-common-error-handling` — error management. Provides the canonical `@RestControllerAdvice`, `ProblemDetail` mapping, base `DomainException` hierarchy. New domain exceptions extend the lib's base class; do NOT register a new advice in the service.
  - Versions are pinned in a parent BOM `<<org>>-platform-bom` (or `<<org>>-dependencies`). Bump via Renovate; never override transitive versions in a service POM.

## Hard rules (MUST)

- Spring Security 7 lambda DSL only: `http.authorizeHttpRequests(a -> a.requestMatchers(...).hasRole(...))`. Never `WebSecurityConfigurerAdapter` or chained `.and()`. **In this codebase, security config comes from `<<org>>-common-security` — do NOT define a `SecurityFilterChain` bean in a service unless extending the lib's documented extension point. Configure via the lib's properties (`<<org-prefix>>.security.*`).**
- `@RestControllerAdvice` returns `ProblemDetail` (RFC 9457). No custom error envelopes. **In this codebase, the global advice is provided by `<<org>>-common-error-handling` — do NOT add a second `@RestControllerAdvice` in the service. Add new mappings by extending the lib's base exception or registering a `<<org>>.errorhandling.ExceptionMapper` bean (per the lib's contract).**
- DTOs are Java `record`s with `jakarta.validation` annotations. Entities never cross the application-service boundary.
- Constructor injection only (Lombok `@RequiredArgsConstructor` allowed if Lombok is the team policy). No field `@Autowired`.
- `@Cacheable` keys explicit (`key = "#id"`); TTL declared per cache name in `RedisCacheConfiguration`, never globally.
- HTTP clients: declare a `@HttpServiceClient` interface and rely on auto-registration when its package is scanned, or register via `@ImportHttpServices`. Do not hand-roll `RestClient` calls in services.
- MapStruct: `@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.ERROR)`; never silently ignore fields. Generated impls live in `target/generated-sources/annotations/` and are gitignored. **Records:** use MapStruct ≥1.6 record support; do not generate builders for record targets; map via canonical constructor.
- SOAP clients: WSDL lives at `src/main/resources/wsdl/<<vendor>>/<<service>>.wsdl`; `jaxws-maven-plugin` (`wsimport`) generates into `target/generated-sources/wsimport/` with a stable `packageName`; the generated package is gitignored. Wrap `WebServiceTemplate` in a domain-named gateway class — controllers/services never see JAXB types.
- OpenAPI: every endpoint has `@Operation(summary)` and `@ApiResponse` for non-2xx outcomes that are part of the contract; security schemes declared once in an `OpenApiConfig` bean.
- Tests:
  - Pure unit tests use `@ExtendWith(MockitoExtension.class)`, `@Mock`, `@InjectMocks`. No Spring context.
  - Web slice tests use `@WebMvcTest(XxxController.class)` + `@MockitoBean` for collaborators (NOT deprecated `@MockBean`). Inject `MockMvc`.
  - One assertion concept per test; AssertJ chains preferred over multiple `assertEquals`.
  - Test naming: `methodUnderTest_condition_expectedOutcome`.
- Logging: SLF4J with structured key-value pairs (`log.atInfo().addKeyValue("orderId", id).log("...")`); trace and span IDs come from Micrometer Tracing automatically. Never `System.out.println`.
- ArchUnit test enforces package boundaries (api → application → domain → infrastructure, no upward edges, no `jakarta.persistence.*` outside `infrastructure`).

## Hard rules (MUST NOT)

- **Do NOT reimplement what an internal common lib provides.** No service-local `SecurityFilterChain` bean (use `common-security`). No service-local `@RestControllerAdvice` for generic errors (use `common-error-handling`). If the lib lacks something you need, raise a PR against the lib — do not work around it locally.
- **Do NOT override common-lib versions in a service POM.** Parent BOM is the source of truth.
- No `javax.*`. No `WebMvcConfigurerAdapter`. No `@EnableGlobalMethodSecurity` (use `@EnableMethodSecurity`).
- No `RestTemplate` in new code. No `Optional` as a method parameter or as a field type.
- No string-concatenated SQL/JPQL. Parameterised queries only; bulk ops via Criteria API or named queries.
- No deprecated `@MockBean`/`@SpyBean` — use `@MockitoBean`/`@MockitoSpyBean`.
- No business logic in controllers. No persistence calls in controllers.
- No checked exceptions across module boundaries.
- No silent catch-and-log. Either rethrow or map to a domain exception.
- No `@SpringBootTest` or Testcontainers in this iteration.

## Architecture (hexagonal / ports-and-adapters)

- Package layout: `<<org>>.<<service-name>>.{api, application, domain, infrastructure, config}`
  - `api` — REST controllers, DTO records, exception mappings (extending common-error-handling), OpenAPI annotations. Depends on `application` only.
  - `application` — orchestration (use cases / application services), transaction boundaries, port interfaces. Depends on `domain`.
  - `domain` — entities, value objects, domain services, domain events. Pure — no Spring, no Jakarta Persistence annotations.
  - `infrastructure` — adapters: JPA repositories, Redis, SOAP gateways, `@HttpServiceClient` impls, Azure clients. Implements ports from `application`.
  - `config` — one `@Configuration` per concern (RedisConfig, ObservabilityConfig, KeyVaultConfig, HttpClientsConfig, SoapClientsConfig, OpenApiConfig). Security config comes from `common-security`.
- Transactions on application services, not controllers, not repositories. Read-only marked.
- Idempotency: write endpoints accept `Idempotency-Key` header; key + response cached in Redis with TTL ≥ retry window.
- Resilience: Resilience4j on every outbound boundary (HTTP and SOAP gateways) — `@CircuitBreaker`, `@Retry`, `@TimeLimiter` with virtual-thread executor. Configure per-client, not globally.
- Outbound integration events use the transactional outbox pattern when consistency matters.
- Container: multi-stage build, JLink/CDS where startup matters; AOT (`spring-aot`) for native if cold-start critical. Health/readiness/liveness probes wired to actuator.

## Verify-before-writing protocol (CRITICAL — no MCP available)

Before writing code that calls a Spring/Azure/third-party API you are not 100% sure about:

1. Search the workspace first (`#codebase`, grep) for an existing usage of the same class/method.
2. Check `docs/snippets/` for a canonical example — copy from there before inventing.
3. If absent, fetch the official reference (Spring Boot 4 / Spring Framework 7 / Azure SDK for Java / Maven Central) using your web tool and cite the URL in chat.
4. If you still cannot verify, STOP and ask the user — do not guess Maven coordinates, annotation names, method signatures, or property keys.
5. For SOAP, always read the WSDL file before writing client code; never invent operation names or message shapes.
6. For internal common libs (`<<org>>-common-*`), read `docs/snippets/CommonSecurityExtensionExample.java` and `docs/snippets/CommonErrorHandlingExtensionExample.java` — these libs are not in your training data.

## When generating code, ALWAYS

- Read the closest existing controller/service/test/mapper/gateway in the same package and mirror its style.
- Add a unit test in the same change.
- Update `application.yml` (and `application-<<profile>>.yml`) when adding configuration; document the property in `README.md` under "Configuration".
- For new outbound calls, register a Resilience4j config and a fallback method.
- Annotate public APIs with JSpecify; ensure NullAway passes.
- Update OpenAPI annotations and (if contract-first) the YAML spec.

## House style

- Method names: imperative for actions (`createOrder`); `findX` returns `Optional`, `getX` throws.
- Domain exceptions extend the `<<org>>.commons.errorhandling.DomainException` base provided by the lib; mapped 1:1 to `ProblemDetail` automatically.
- Records over classes for immutable data.
- Lombok policy (TEAM DECISION — pick one and document in an ADR):
  - Option A: **Drop Lombok.** Use records + manual constructors + SLF4J `Logger` field. Cleaner with JSpecify; no annotation-processor surprises.
  - Option B: **Keep Lombok with a tight allowlist.** Only `@RequiredArgsConstructor`, `@Slf4j`, `@Builder` on test fixtures only. No `@Data`, no `@Value`, no `@SneakyThrows`.

## Autonomous-execution scope

GREEN — agent mode may execute autonomously after plan approval:
- Add a CRUD endpoint mirroring an existing one in the same package.
- Add a JPA query method to an existing repository.
- Add a MapStruct mapper for a new pair within an existing module.
- Add a `@Cacheable` method when an existing cache name and TTL apply.
- Add a unit test for an existing class.
- Refactor within a single class (extract method, rename, inline).
- Add JSpecify annotations to existing public APIs.
- Update OpenAPI annotations on existing endpoints.

YELLOW — agent mode may execute but the diff MUST be reviewed before merge:
- New `@HttpServiceClient` interface or new SOAP gateway.
- New cache name or new `RedisCacheConfiguration` entry.
- New domain exception mapped via `common-error-handling`.
- Cross-module mapper.
- New OpenAPI operation with non-trivial schema changes.
- New Resilience4j config block.

RED — agent mode MUST NOT execute autonomously; produce a plan only:
- Any change that adds a service-local `SecurityFilterChain` or `@RestControllerAdvice` (would conflict with `common-security` / `common-error-handling`).
- Any version override of `<<org>>-common-*` libs or the parent BOM.
- Any change in `**/SecurityConfig.java` or `**/security/**`.
- Any change in `**/config/RedisCacheConfiguration.java` (TTL or eviction policy).
- Any change in `application*.yml` that touches secrets, profiles, datasource, or auth.
- Any new SOAP service introduction (WSDL ingestion, JAXB plugin config).
- Transactional outbox additions, async / virtual-thread changes.
- Database schema migrations.
- Anything touching `Idempotency*` classes.
- New `@Bean` in any class outside `config/`.

If a task spans multiple buckets, treat the whole task as the most restrictive bucket.

## Definition of done (every PR)

- Build green; ArchUnit green; NullAway green; Spotless formatted; OpenAPI lint green (Spectral); no breaking changes (oasdiff).
- New properties documented; new endpoints in OpenAPI; new metrics named with the service prefix.
- No new `RestTemplate`/`javax.*`/`WebSecurityConfigurerAdapter`/`@MockBean`/duplicate-`SecurityFilterChain`/duplicate-`@RestControllerAdvice` (CI grep gates).
- Unit-test coverage on changed lines ≥ <<threshold>>%.
