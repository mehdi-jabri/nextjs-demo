---
description: "Scaffold a new REST endpoint following project conventions"
mode: agent
---

You are extending the API in this repo. Follow `.github/copilot-instructions.md` and `.github/instructions/controllers.instructions.md` strictly.

Inputs from the user (ask if missing): HTTP method, path, request shape, response shape, auth requirement (public / authenticated / role), is it idempotent.

## Bucket check

This is a GREEN task ONLY if it mirrors an existing endpoint in the same package. Otherwise YELLOW — diff must be reviewed before merge. Stop if the user requests RED.

## Steps

1. Read the most recent controller in `api/` and the most recent application service in `application/` to mirror style. Cite `file:line`.
2. Read `docs/snippets/ControllerExample.java` for the canonical pattern. If it exists, follow it.
3. Generate:
   - Request DTO record (if needed) under `<<org>>.<<service-name>>.api.dto` with `jakarta.validation` annotations.
   - Response DTO record under the same package.
   - Controller method on the existing controller (or a new controller if the resource is new) — `@Operation`, `@ApiResponse` for success and documented errors.
   - Application service method (or new service) under `<<org>>.<<service-name>>.application` — `@Transactional` (read-only if applicable).
   - Port + adapter if a new outbound dependency is needed.
   - Domain exception extending `<<org>>.commons.errorhandling.DomainException` if a new error case is introduced. Do NOT add a service-local `@RestControllerAdvice` — `common-error-handling` handles the mapping.
4. Generate tests:
   - Slice test: `@WebMvcTest(ThisController.class)` + `@MockitoBean` — happy path, validation failure (400), auth failure (401/403 if applicable), not-found (404 if applicable).
   - Unit test for the application service: `@ExtendWith(MockitoExtension.class)`, all branches.
5. Update `application.yml` and `README.md` § Endpoints if new properties or operations are introduced.
6. List every file you changed at the end with one-line rationale.

## Banned

- Adding a service-local `@RestControllerAdvice` or `SecurityFilterChain`.
- Adding fields, endpoints, or abstractions beyond what the user asked for.
- Persistence calls in the controller.
- `RestTemplate`, `javax.*`, `WebSecurityConfigurerAdapter`, `@MockBean`.
