# ORD — Use Cases  ⭐ EXAMPLE

> Fictional reference. Back to [module index](ORD-00-module-index.md).

## UC-ORD-001: Create or edit a draft order
- **Status:** Confirmed · **Confidence:** High
- **Actors:** Sales staff
- **Source:** `OrderEdit.aspx.cs:Page_Load:40`; `OrderService.SaveDraft(): OrderService.cs:95`
- **Related rules:** BR-ORD-002, BR-ORD-010, BR-ORD-011 · **Related screens:** SCR-ORD-002 · **Related entities:** ENT-Order, ENT-OrderLine

### Description
A salesperson builds up an order by adding product lines and saving it as a draft for later submission.

### Preconditions
- User is authenticated and in role **Sales** or **Admin** — Source: `web.config:<location path="Orders">`.

### Main flow
| Step | Actor action | System response | Rules invoked | Source |
|---|---|---|---|---|
| 1 | Open new/existing order | Loads order, binds lines grid | — | `OrderEdit.aspx.cs:40-78` |
| 2 | Add a line (product, qty) | Validates qty>0, computes subtotal | BR-ORD-002, BR-ORD-011 | `OrderEdit.aspx.cs:120` |
| 3 | Click **Save Draft** | Recomputes total, persists as Draft | BR-ORD-010 | `OrderService.cs:95-110` |

### Alternative flows
- **A1 — Remove a line:** at step 2, removing a line recomputes the total (BR-ORD-010). Source: `OrderEdit.aspx.cs:150`.

### Exception flows
- **E1 — Quantity ≤ 0:** validation blocks save with *"Quantity must be greater than zero"*. Source: `OrderEdit.aspx:62`.

### Postconditions
- Order persisted with status `Draft` — Source: `OrderService.cs:108`.

### Acceptance criteria
- AC1: The system **shall** prevent saving a line with quantity ≤ 0. (verifies BR-ORD-002)
- AC2: The system **shall** recompute the order total whenever a line changes. (verifies BR-ORD-010)

## Developer Notes (legacy)
Lines grid is a `GridView` bound in `!IsPostBack` and re-bound after each add/remove; line state is held in
`ViewState["Lines"]` between postbacks (`OrderEdit.aspx.cs:200`).
> Target‑stack rebuild guidance for this use case is in
> [../../migration/_EXAMPLE-ORD-migration-notes.md](../../migration/_EXAMPLE-ORD-migration-notes.md).

---

## UC-ORD-003: Place an order
- **Status:** Confirmed · **Confidence:** High
- **Actors:** Sales staff
- **Source:** `OrderEdit.aspx.cs:btnPlace_Click:180`; `OrderService.PlaceOrder(): OrderService.cs:45`
- **Related rules:** BR-ORD-001, BR-ORD-005, BR-ORD-010, BR-ORD-015 · **Related screens:** SCR-ORD-002 · **Related entities:** ENT-Order

### Description
A salesperson submits a draft order; the system validates it, reserves stock, and moves it to `Placed`.

### Preconditions
- Order is in status `Draft` and has at least one line — Source: `OrderService.cs:46`.

### Main flow
| Step | Actor action | System response | Rules invoked | Source |
|---|---|---|---|---|
| 1 | Click **Place Order** | Validates customer present | BR-ORD-005 | `OrderService.cs:48` |
| 2 | — | Validates total ≥ 10.00 | BR-ORD-001 | `OrderService.cs:55` |
| 3 | — | Reserves stock | BR-ORD-015 | `OrderService.cs:120` |
| 4 | — | Sets status `Placed`, stamps `PlacedDate` | PRC-ORD-001 | `OrderService.cs:150` |

### Exception flows
- **E1 — Total below minimum:** rejected, stays `Draft`. Source: `OrderService.cs:55` (BR-ORD-001).
- **E2 — Insufficient stock:** rejected, stays `Draft`. Source: `OrderService.cs:120` (BR-ORD-015). `[UNVERIFIED]` partial fulfilment.

### Postconditions
- Order status `Placed`, `PlacedDate` set; stock reserved — Source: `OrderService.cs:150`.

### Acceptance criteria
- AC1: The system **shall** reject an order whose total is below the minimum. (verifies BR-ORD-001)
- AC2: The system **shall** reject placing an order without a customer. (verifies BR-ORD-005)
- AC3: The system **shall** not place an order exceeding available stock. (verifies BR-ORD-015)

### Open questions
- [NEEDS-BUSINESS-INPUT] Is partial fulfilment allowed when stock is short? (Q-014)

## Developer Notes (legacy)
`PlaceOrder` runs inside a `TransactionScope` (`OrderService.cs:45-152`): validate → reserve stock → set status,
all atomic.
> Target‑stack rebuild guidance for this use case is in
> [../../migration/_EXAMPLE-ORD-migration-notes.md](../../migration/_EXAMPLE-ORD-migration-notes.md).
