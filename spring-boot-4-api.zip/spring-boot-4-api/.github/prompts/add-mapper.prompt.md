---
description: "Add a MapStruct mapper for a (source, target) pair"
mode: agent
---

Follow `.github/instructions/mappers.instructions.md`.

## Bucket: GREEN within an existing module; YELLOW if cross-module.

## Inputs (ask if missing)

- Source type (FQN).
- Target type (FQN).
- Direction (one-way / bidirectional).
- Any non-trivial conversions (date formats, enum mapping, nested collections).

## Steps

1. Read `docs/snippets/MapStructRecordMapperExample.java`.
2. Create the mapper interface at `<<org>>.<<service-name>>.<module>.mapper.<<Source>>To<<Target>>Mapper`:
   ```java
   @Mapper(
       componentModel = "spring",
       unmappedTargetPolicy = ReportingPolicy.ERROR,
       nullValueCheckStrategy = NullValueCheckStrategy.ALWAYS
   )
   public interface XxxToYyyMapper {
       Yyy toTarget(Xxx source);
   }
   ```
3. For records as targets: rely on canonical-constructor mapping. Do NOT enable builder generation.
4. For each non-name-matching field pair, add `@Mapping(source = "...", target = "...")`. For conversions, use `@Named` helpers on the same mapper; for enum mapping, use `@ValueMapping`.
5. Add a unit test that:
   - Builds a fully-populated source via `TestFixtures.<<Source>>.fully()`.
   - Maps it.
   - Asserts every field on the target. Use AssertJ chained assertions.
   - Tests at least one null-input case if the mapper accepts nulls.
6. If a similar mapper already exists, point to it as the style reference and mirror.

## Banned

- `unmappedTargetPolicy = IGNORE` or omitted (defaults to WARN — too lenient).
- Inline conversions in `expression` — use `@Named` helpers.
- One mapper handling > 2 directions or > 1 (source, target) pair.
