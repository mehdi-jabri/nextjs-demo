# TEMPLATE — Domain Entity / Data Dictionary

> One `ENT-<Name>` per entity, in the module's `*-06-data-dictionary.md`. Include a Mermaid `erDiagram` per module.
> See `_EXAMPLE-Orders/ORD-06-data-dictionary.md`.

```
## ERD (per module)
```mermaid
erDiagram
  PARENT ||--o{ CHILD : contains
  CHILD }o--|| OTHER : references
```

## Entity: ENT-<Name>  (legacy: <Class.cs> / <dbo.Table>)
- **Source (entity):** <Class.cs:1-NN> · **Source (table/EDMX):** <…>
- **Description (business):** <what this entity represents — one plain sentence>
- **Business identity:** <the natural key / how a user identifies one>

### Attributes
| Attribute | Business meaning | Type (legacy) | Nullable | Constraints / domain | DB column | Default | Source | Confidence |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |

### Relationships
| Related entity | Cardinality | FK | Cascade behavior | Source |
|---|---|---|---|---|
| | 1:1 / 1:N / M:N | | cascade / restrict | <OnModelCreating:line> |

### Invariants / constraints (link to rules)
- BR-…: <invariant> — Source: <file:line>

## Developer Notes (legacy)
- EF6 mapping: <Fluent API OnModelCreating:line / data annotations / EDMX>
- Indexes / stored procs / triggers touching this table: <usp_…:line; trg_…:line>
- Concurrency: <[Timestamp]/rowversion?> · Soft-delete: <IsDeleted filter?> · Audit columns: <…>
```
> The PostgreSQL target schema and JPA mapping are **not** written here — they live only in
> `specs/migration/<MOD>-migration-notes.md` (produced by `/migration-notes`). Keep this entry's types in
> their **legacy** form.
