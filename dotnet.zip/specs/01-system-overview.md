# 01 — System Overview

> **Status:** Not started · **Last updated:** _(date)_ · **Source snapshot:** _(commit/label)_
> Audience: Business (body) + Developers (appendices). Back to [index](00-index.md).

## 1. Purpose & business context
_(2–4 plain‑language paragraphs: what business problem the application solves. No technical terms.)_
`[NEEDS-BUSINESS-INPUT]` if the purpose cannot be derived from code.

## 2. Scope
### 2.1 Modules in scope
| Module code `<MOD>` | Module name | Spec docs | Coverage status |
|---|---|---|---|
| _(seed from `/00-inventory`)_ | | | Not started |

### 2.2 Out of scope / not yet analyzed
- _(item — reason; use `[NEEDS-BUSINESS-INPUT]` if uncertain)_

## 3. Actors / user roles (business view)
| Actor | Description | Key responsibilities | Maps to security role (D10) |
|---|---|---|---|
| | | | |

## 4. System context
```mermaid
flowchart LR
  User[Business user] --> App[Legacy application]
  App --> DB[(SQL Server)]
  App --> Ext[External systems]
```

## 5. Module map (capabilities)
```mermaid
flowchart TD
  App[Application]
  App --> MOD1[Module 1]
  App --> MOD2[Module 2]
```

## 6. High-level capabilities
| Capability | Description | Primary use cases (D3) |
|---|---|---|

## 7. Assumptions & constraints (system level)
- `[ASSUMPTION]` …
- `[NEEDS-BUSINESS-INPUT]` …

---

## Developer Notes (legacy)
- **Tech stack observed:** ASP.NET Web Forms (.NET Framework 4.8), EF 6.4.4, Ninject 3.3.6, AutoMapper 10.1.1, SQL Server.
- **Solution / project layout:** _(from `/00-inventory`)_
- **Source roots scanned:** _(paths)_

### Dependency Injection graph (from `/map-dependencies`)
| Interface | Implementation (live) | Scope | Conditional? | Source |
|---|---|---|---|---|
| | | | | |

> Target‑stack rebuild guidance (Spring Boot + Vue + PostgreSQL) is **not** in this business spec — it lives
> in [migration/00-migration-index.md](migration/00-migration-index.md), produced by `/migration-notes`.
