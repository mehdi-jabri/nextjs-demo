# TEMPLATE — Report Specification

> One `RPT-NNN` per report, appended in `cross-cutting/09-reports.md`.

```
# Report Spec — RPT-NNN: <report name>
- **Audience:** <roles> · **Output:** grid / PDF / Excel / SSRS .rdl
- **Source:** <ReportPage.aspx.cs / .rdl / stored proc file:line>
- **Confidence:** … · **Status:** …

## Purpose (business)
<What decision/insight this report supports — one plain sentence.>

## Parameters / filters
| Parameter | Type | Required | Default | Allowed values | Source |
|---|---|---|---|---|---|

## Columns
| Column | Business meaning | Source field/expr (D6) | Format | Aggregation | Source |
|---|---|---|---|---|---|

## Underlying query / data source
- Source query: <usp_Name:line / view> — grouping/sort/filter logic described.

## Business rules embedded in the report
- BR-RPT-NNN: <e.g. excludes cancelled orders> — Source: <SQL WHERE clause file:line>

## Developer Notes (legacy)
<legacy implementation detail>
```
> Target‑stack rebuild guidance lives only in `specs/migration/` (via `/migration-notes`).
