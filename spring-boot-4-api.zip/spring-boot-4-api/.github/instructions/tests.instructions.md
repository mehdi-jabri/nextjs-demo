---
applyTo: "**/src/test/**"
description: "Testing conventions — Mockito unit tests only, no Testcontainers"
---

- JUnit 5, Mockito, AssertJ. No JUnit 4. No `@RunWith`.
- **Pure unit tests:** `@ExtendWith(MockitoExtension.class)`, `@Mock` on collaborators, `@InjectMocks` on the SUT. No Spring context.
- **Web slice tests:** `@WebMvcTest(XxxController.class)`, inject `MockMvc`, declare collaborators with `@MockitoBean` (NOT deprecated `@MockBean`).
- **Repository slice tests:** `@DataJpaTest` with `@AutoConfigureTestDatabase(replace = NONE)` if you need a specific dialect; otherwise H2 is fine. No Testcontainers.
- **Json slice tests:** `@JsonTest` for serialisation/deserialisation contracts.
- **SOAP gateway tests:** `MockWebServiceServer` from `spring-ws-test` — verify the request payload and stub the response.
- NO `@SpringBootTest`. NO `@AutoConfigureMockMvc` on `@SpringBootTest`. NO Testcontainers. Flag any PR that introduces these.
- Naming: `methodUnderTest_condition_expectedOutcome` (e.g., `createOrder_whenCustomerNotFound_throwsCustomerNotFoundException`).
- One assertion concept per test. Multiple AssertJ chained assertions are fine; multiple unrelated `assertThat` calls are not.
- Use `assertThatThrownBy` for exception assertions, not `assertThrows`.
- Stable fixtures live in `src/test/java/**/support/TestFixtures.java`. Reuse them; do not copy fixture data across test classes.
- Coverage gate on changed lines: ≥ <<threshold>>%. Mutation testing (PIT) on changed packages — kill ≥ 70%.
- See `docs/snippets/MockitoUnitTestExample.java` and `docs/snippets/WebMvcTestExample.java`.
