---
applyTo: "**/application/**/*.java"
description: "Conventions for application services (use cases)"
---

- One application service per use case (`CreateOrderService`, `CancelOrderService`) or one per aggregate (`OrderService`) — pick one and stay consistent within the module.
- Constructor injection only. Final fields. No `@Autowired`.
- `@Transactional` on the application service method, not on the controller, not on the repository. Mark read-only methods `@Transactional(readOnly = true)`.
- Define ports (interfaces) in `application` package; implementations live in `infrastructure`. The application layer never imports JPA, Redis, or HTTP-client classes directly.
- Throw domain exceptions extending `<<org>>.commons.errorhandling.DomainException` (from `common-error-handling`). Do not catch and translate exceptions in the controller — let the lib's advice handle it.
- Validation: business invariants enforced in the domain or application layer. `jakarta.validation` belongs at the API boundary; do not annotate domain types.
- Virtual threads: `@Async` methods may use virtual-thread executor. For fan-out within a single request, prefer structured concurrency (`StructuredTaskScope.ShutdownOnFailure`) over manual `CompletableFuture` chains.
- Outbound calls are made through ports. Resilience4j (`@CircuitBreaker`, `@Retry`, `@TimeLimiter`) is applied on the infrastructure adapter, not on the application service.
- Domain events published via `ApplicationEventPublisher`; persistent events use the transactional outbox pattern.
- See `docs/snippets/ApplicationServiceExample.java`.
