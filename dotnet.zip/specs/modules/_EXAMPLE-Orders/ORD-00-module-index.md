# Module ORD — Order Management  ⭐ EXAMPLE / GOLD STANDARD

> **This is a fictional, fully-worked reference module.** It exists to show the exact quality bar — citations,
> markers, confidence/status, WHAT/HOW separation, Mermaid diagrams, and concrete examples — that every **real**
> module must match. The file/line citations point at imaginary files; when you spec a real module, replace them
> with real ones. Do **not** edit this folder for a real project; copy its structure into `specs/modules/<MOD>/`.

- **Status:** In Review · **Last updated:** 2026-05-29 · **Source snapshot:** `example` · Back to [index](../../00-index.md)

## Capability overview
Order Management lets sales staff create, edit, submit, and cancel customer orders, automatically pricing each
order from its lines and enforcing a minimum order value and a stock check before an order can be placed.

## Documents
- Use cases: [ORD-03-use-cases.md](ORD-03-use-cases.md)
- Business rules: [ORD-05-business-rules.md](ORD-05-business-rules.md)
- Data dictionary: [ORD-06-data-dictionary.md](ORD-06-data-dictionary.md)
- Processes: [ORD-07-processes.md](ORD-07-processes.md)
- Screens: [ORD-04-screens/SCR-ORD-002-order-edit.md](ORD-04-screens/SCR-ORD-002-order-edit.md)

## Definition of Done
- [x] Every .aspx/.ascx in the module has a SCR- spec (count: 2 / 2 — list & edit; only edit shown in this example)
- [x] Every code-behind event handler traced to a UC or BR, or marked [DEAD-CODE?]
- [x] Every public BLL/service method traced to ≥1 rule or [DEAD-CODE?]
- [x] Every EF entity & property in the data dictionary
- [x] Every validator → a BR
- [x] Every authorization check → D10 + BR-SEC
- [ ] Every stored proc / raw SQL referenced → described — *1 proc `usp_ReserveStock` pending confirmation* `[UNVERIFIED]`
- [x] Every BR has citation, confidence, status, enforcement layer
- [x] No dangling IDs in the traceability matrix
- [ ] All [NEEDS-BUSINESS-INPUT] consolidated into D13 — *2 open questions (Q-001, Q-014) raised*
- [x] Coverage row in 00-index.md updated

## Confidence & status rollup
| | Confirmed | Assumed | Needs-input | Dead-code? |
|---|---|---|---|---|
| Rules | 6 | 1 | 2 | 1 |
| Use cases | 2 | 0 | 0 | 0 |
