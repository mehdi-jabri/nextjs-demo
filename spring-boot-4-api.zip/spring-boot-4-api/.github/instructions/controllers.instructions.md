---
applyTo: "**/api/**/*Controller.java"
description: "Conventions for REST controllers"
---

- Return `ResponseEntity<T>` only when status code or headers vary; otherwise return the body directly with `@ResponseStatus` on the method.
- `@Valid` on the body record; `@Validated` on the controller for path/query.
- Idempotency: write endpoints (POST, PUT, PATCH, DELETE with side effects) MUST accept `Idempotency-Key` header; delegate to `IdempotencyGuard.run(...)`.
- Errors thrown from services map via `<<org>>-common-error-handling`'s global advice to `ProblemDetail`. Never catch in the controller. Never register a service-local `@RestControllerAdvice`.
- OpenAPI: every method has `@Operation(summary, description)` and `@ApiResponse` for documented non-2xx outcomes.
- Slice test required: `@WebMvcTest(ThisController.class)` with `@MockitoBean` for service dependencies. Use `MockMvc` (not `WebTestClient` unless reactive).
- No business logic in controllers. No persistence calls. Inject the application service only.
- Method names match the use case: `createOrder`, `getOrder`, `cancelOrder` — not `post`, `get`, `delete`.
- Public DTOs are records under `<<org>>.<<service-name>>.api.dto`. Never expose entities.
- See `docs/snippets/ControllerExample.java` for the canonical pattern.
