# ORD — Processes / Workflows  ⭐ EXAMPLE

> Fictional reference. Back to [module index](ORD-00-module-index.md).

## PRC-ORD-001: Order lifecycle
- **Type:** User workflow (status lifecycle)
- **Trigger:** Order actions (save, place, ship, cancel)
- **Source:** `OrderService.cs:45-260`; `OrderStatus.cs:1`
- **Related UCs / rules:** UC-ORD-001, UC-ORD-003 / BR-ORD-001, BR-ORD-015, BR-ORD-020
- **Confidence:** High (transitions) · **Status:** Confirmed (Draft→Placed); Needs-business-input (cancel window)

### Narrative
An order is created as a **Draft**, **Placed** once validated and stock is reserved, **Shipped** when fulfilled,
or **Cancelled**. Cancellation is only allowed within a limited window after placing.

### State machine
```mermaid
stateDiagram-v2
  [*] --> Draft
  Draft --> Placed: place (BR-ORD-001, BR-ORD-005, BR-ORD-015)
  Placed --> Shipped: ship
  Placed --> Cancelled: cancel within 24h (BR-ORD-020)
  Draft --> Cancelled: discard
  Shipped --> [*]
  Cancelled --> [*]
```
| Transition | From | To | Guard / condition | Rule | Source |
|---|---|---|---|---|---|
| place | Draft | Placed | customer set, total ≥ 10.00, stock available | BR-ORD-001/005/015 | `OrderService.cs:45-150` |
| ship | Placed | Shipped | (fulfilment) `[UNVERIFIED]` exact trigger | — | `OrderService.cs:170` |
| cancel | Placed | Cancelled | within 24h of PlacedDate | BR-ORD-020 | `OrderService.cs:210` |
| discard | Draft | Cancelled | any time `[UNVERIFIED]` | — | `OrderService.cs:240` |

### Sequence — Place order
```mermaid
sequenceDiagram
  actor U as Sales user
  U->>Web: Click Place Order
  Web->>BLL: PlaceOrder(orderId)
  BLL->>BLL: validate customer + total (BR-ORD-005/001)
  BLL->>DB: usp_ReserveStock (BR-ORD-015)
  BLL->>DB: set Status=Placed, PlacedDate
  BLL-->>Web: confirmation / error
```

## Developer Notes (legacy)
`OrderStatus` is an `int`-backed enum (`OrderStatus.cs:1`); the DB stores the int. The transition methods live in
`OrderService` and run inside a `TransactionScope` for `place`. `ship`/`discard` triggers are not fully traced
(`[UNVERIFIED]`) — raised as open questions.
> Target‑stack rebuild guidance is in
> [../../migration/_EXAMPLE-ORD-migration-notes.md](../../migration/_EXAMPLE-ORD-migration-notes.md).
