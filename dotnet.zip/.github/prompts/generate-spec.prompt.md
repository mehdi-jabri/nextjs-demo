---
description: "Consolidate a module's extracted docs (cross-link + module index) — run BEFORE verify/review"
agent: agent
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "findTestFiles", "problems", "fetch", "editFiles"]
argument-hint: "targetModule e.g. ORD"
---

# Task: Assemble & polish the module specification

Consolidate everything extracted for `${input:targetModule}` into clean, business‑readable documents. Run this
**after** the per‑module extracts and **before** `/verify-coverage` + `/review-spec`, so the reviewer audits the
final consolidated docs. Follow `.github/copilot-instructions.md` and emulate `specs/modules/_EXAMPLE-Orders/`.
**Read‑only on code** (write only `specs/`).

## Steps
1. Ensure the module folder `specs/modules/<MOD>/` has: `<MOD>-00-module-index.md`, `<MOD>-03-use-cases.md`,
   `<MOD>-05-business-rules.md`, `<MOD>-06-data-dictionary.md`, `<MOD>-07-processes.md`, and
   `<MOD>-04-screens/SCR-*.md` — each conforming to the templates.
2. Verify the **WHAT/HOW separation**: business behavior in the body (plain‑language first sentence, tables,
   Mermaid diagrams, concrete pass/fail examples for validation/calculation rules); legacy implementation
   mechanics in `## Developer Notes (legacy)`. The body must stay **strictly target‑agnostic** — no
   Spring Boot/Vue/PostgreSQL content anywhere in `specs/` (that lives only in `specs/migration/`).
3. Cross‑link by ID (rules ↔ use cases ↔ screens ↔ entities) and confirm the traceability matrix rows exist.
4. Write the `<MOD>-00-module-index.md` summary: capability overview, doc links, DoD status, confidence rollup.

## Output
A complete, internally consistent module spec set. Do **not** invent content to fill gaps — leave
`[NEEDS-BUSINESS-INPUT]`/`[UNVERIFIED]` markers in place. Update `specs/00-index.md` (module status → "In Review")
and run a final check that no claim is un‑cited and no ID is dangling.
