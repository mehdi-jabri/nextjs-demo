---
name: nuxt-development
description: Expert knowledge for Nuxt 3 development including file-based routing, composables, SSR/SSG, server routes, middleware, and deployment patterns. Use when working with Nuxt configuration, pages, layouts, server-side functionality, or data fetching.
---

# Nuxt 3 Development Skill

## Core Concepts

### File-Based Routing
```
pages/
├── index.vue           # /
├── about.vue           # /about
├── users/
│   ├── index.vue       # /users
│   ├── [id].vue        # /users/:id
│   └── [...slug].vue   # /users/* (catch-all)
└── [[optional]].vue    # Optional param
```

### Nuxt Configuration (nuxt.config.ts)
```typescript
export default defineNuxtConfig({
  devtools: { enabled: true },
  
  modules: [
    '@nuxtjs/tailwindcss',
    '@pinia/nuxt',
    '@sidebase/nuxt-auth',
    '@vueuse/nuxt',
    'shadcn-nuxt',
  ],
  
  // Runtime config (env variables)
  runtimeConfig: {
    secretKey: '', // Server-only
    public: {
      apiBase: '', // Client accessible
    }
  },
  
  // SSR/SSG configuration
  ssr: true,
  routeRules: {
    '/': { prerender: true },
    '/api/**': { cors: true },
    '/dashboard/**': { ssr: false }, // SPA mode for this route
  },
  
  // TypeScript strict mode
  typescript: {
    strict: true,
    typeCheck: true,
  },
  
  // Experimental features
  experimental: {
    typedPages: true,
  },
})
```

## Data Fetching

### useFetch - For Pages/Components
```typescript
// Basic fetch
const { data, pending, error, refresh } = await useFetch('/api/users')

// With options
const { data: user } = await useFetch(`/api/users/${id}`, {
  key: `user-${id}`,
  transform: (data) => data.user,
  pick: ['id', 'name', 'email'],
  watch: [id], // Re-fetch when id changes
  lazy: true, // Don't block navigation
  server: true, // Fetch on server
  immediate: true, // Fetch immediately
})
```

### useAsyncData - For Custom Async Logic
```typescript
const { data, pending, error } = await useAsyncData(
  'unique-key',
  () => $fetch('/api/data'),
  {
    transform: (result) => result.items,
    default: () => [],
  }
)
```

### $fetch - Direct API Calls
```typescript
// Use for event handlers and non-reactive fetching
async function submitForm() {
  try {
    const result = await $fetch('/api/submit', {
      method: 'POST',
      body: { data },
    })
  } catch (error) {
    // Handle error
  }
}
```

## Server Routes

### API Endpoints (server/api/)
```typescript
// server/api/users/index.get.ts
export default defineEventHandler(async (event) => {
  const query = getQuery(event)
  // Return data directly (auto-serialized)
  return { users: [] }
})

// server/api/users/index.post.ts
export default defineEventHandler(async (event) => {
  const body = await readBody(event)
  // Validation with Zod
  const validated = UserSchema.parse(body)
  return { success: true }
})

// server/api/users/[id].get.ts
export default defineEventHandler(async (event) => {
  const id = getRouterParam(event, 'id')
  return { user: { id } }
})
```

### Server Middleware
```typescript
// server/middleware/auth.ts
export default defineEventHandler((event) => {
  const session = getCookie(event, 'session')
  if (!session && event.path.startsWith('/api/protected')) {
    throw createError({
      statusCode: 401,
      message: 'Unauthorized',
    })
  }
})
```

## Composables

### Creating Composables
```typescript
// composables/useUser.ts
export function useUser() {
  const user = useState<User | null>('user', () => null)
  const isLoggedIn = computed(() => !!user.value)
  
  async function fetchUser() {
    user.value = await $fetch('/api/auth/user')
  }
  
  async function logout() {
    await $fetch('/api/auth/logout', { method: 'POST' })
    user.value = null
    navigateTo('/login')
  }
  
  return {
    user: readonly(user),
    isLoggedIn,
    fetchUser,
    logout,
  }
}
```

### useState - SSR-Safe State
```typescript
// Shared state across components (SSR-safe)
const counter = useState('counter', () => 0)
const user = useState<User | null>('user', () => null)
```

## Layouts & Pages

### Layouts
```vue
<!-- layouts/default.vue -->
<template>
  <div class="min-h-screen">
    <AppHeader />
    <main class="container mx-auto py-4">
      <slot />
    </main>
    <AppFooter />
  </div>
</template>

<!-- layouts/dashboard.vue -->
<template>
  <div class="flex">
    <DashboardSidebar />
    <main class="flex-1">
      <slot />
    </main>
  </div>
</template>
```

### Pages with definePageMeta
```vue
<script setup lang="ts">
definePageMeta({
  layout: 'dashboard',
  middleware: ['auth'],
  title: 'Dashboard',
  // Route rules
  alias: ['/home'],
  keepalive: true,
})

// SEO
useSeoMeta({
  title: 'Dashboard | My App',
  description: 'Your personal dashboard',
})
</script>
```

## Navigation & Middleware

### Navigation
```typescript
// Programmatic navigation
const router = useRouter()
navigateTo('/dashboard')
navigateTo({ path: '/users', query: { page: 1 } })
navigateTo('/external', { external: true })

// Route info
const route = useRoute()
console.log(route.params.id)
```

### Route Middleware
```typescript
// middleware/auth.ts
export default defineNuxtRouteMiddleware((to, from) => {
  const { loggedIn } = useAuth()
  
  if (!loggedIn.value && to.path !== '/login') {
    return navigateTo('/login')
  }
})

// middleware/admin.ts
export default defineNuxtRouteMiddleware((to) => {
  const { user } = useAuth()
  
  if (user.value?.role !== 'admin') {
    return abortNavigation()
  }
})
```

## Plugins

### Creating Plugins
```typescript
// plugins/api.ts
export default defineNuxtPlugin(() => {
  const api = $fetch.create({
    baseURL: useRuntimeConfig().public.apiBase,
    onRequest({ options }) {
      options.headers = {
        ...options.headers,
        Authorization: `Bearer ${useCookie('token').value}`,
      }
    },
    onResponseError({ response }) {
      if (response.status === 401) {
        navigateTo('/login')
      }
    },
  })
  
  return {
    provide: {
      api,
    },
  }
})
```

## Error Handling

### Error Page
```vue
<!-- error.vue -->
<script setup lang="ts">
const props = defineProps<{
  error: {
    statusCode: number
    message: string
  }
}>()

const handleError = () => clearError({ redirect: '/' })
</script>

<template>
  <div class="p-4">
    <h1>{{ error.statusCode }}</h1>
    <p>{{ error.message }}</p>
    <button @click="handleError">Go Home</button>
  </div>
</template>
```

### Error Boundaries
```vue
<template>
  <NuxtErrorBoundary>
    <ComponentThatMightFail />
    <template #error="{ error, clearError }">
      <div>Error: {{ error.message }}</div>
      <button @click="clearError">Retry</button>
    </template>
  </NuxtErrorBoundary>
</template>
```

## Performance Optimization

### Component Lazy Loading
```vue
<template>
  <!-- Lazy load heavy components -->
  <LazyHeavyChart v-if="showChart" />
  
  <!-- Client-only rendering -->
  <ClientOnly>
    <ThirdPartyWidget />
    <template #fallback>
      <LoadingSpinner />
    </template>
  </ClientOnly>
</template>
```

### Preloading
```typescript
// Preload route
preloadRouteComponents('/dashboard')

// Preload components
const LazyModal = defineAsyncComponent(() => 
  import('~/components/Modal.vue')
)
```

## Best Practices

1. **Use `useFetch` for reactive data** - Automatically handles SSR/CSR
2. **Prefer server routes** for API logic - Keep secrets server-side
3. **Use `useState` for shared state** - SSR-safe and synced
4. **Implement proper error handling** - Use error boundaries
5. **Leverage route rules** for hybrid rendering
6. **Use lazy loading** for heavy components
7. **Implement proper middleware** for auth/authorization
8. **Use TypeScript** with strict mode enabled
9. **Follow Nuxt conventions** for auto-imports
