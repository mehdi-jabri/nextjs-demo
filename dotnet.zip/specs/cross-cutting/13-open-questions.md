# 13 — Open Questions / Decision Log

> **Status:** Not started · **Last updated:** _(date)_ · Back to [index](../00-index.md).
>
> Every `[NEEDS-BUSINESS-INPUT]`, `[UNVERIFIED]`, `[CONFLICT]`, and `[ASSUMPTION]` raised anywhere in the specs is
> consolidated here for business workshops. When a question is answered, record the decision and flip the related
> rule/requirement status from `Assumed`/`Needs-business-input` → `Confirmed` (and update its source doc).

| ID | Module | Question | Raised by (doc / rule) | Source (file:line) | Marker | Priority | Answer / Decision | Resolved? |
|---|---|---|---|---|---|---|---|---|
| Q-001 | _(example)_ ORD | Are orders below the minimum total ever allowed for admins? | BR-ORD-001 | `OrderService.cs:55` | `[UNVERIFIED]` | High | _(pending)_ | No |
| | | | | | | | | |
