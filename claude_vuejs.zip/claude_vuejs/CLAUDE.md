# Nuxt.js Frontend Development Agent

This workspace is configured for autonomous AI-driven frontend development with Claude skills and subagents.

## Project Stack

- **Framework**: Nuxt 3 (Vue 3 with Composition API)
- **UI Components**: shadcn-vue (Radix Vue primitives)
- **Styling**: Tailwind CSS 4
- **State Management**: Pinia + TanStack Query (Vue Query)
- **Authentication**: @sidebase/nuxt-auth
- **Form Handling**: VeeValidate + Zod
- **API Layer**: VueUse's built-in $fetch (or tRPC for type-safe APIs)
- **Testing**: Vitest (unit) + Playwright (E2E)
- **Utilities**: VueUse composables

## Development Workflow

### Task Management
All requirements and features are tracked in the `docs/` folder:
- `docs/requirements/` - Product requirements, user stories, specs
- `docs/tasks/` - Task breakdowns, implementation status, priorities
- `docs/tasks/active.md` - Current active tasks with status

### Subagent Orchestration
When implementing complex features:
1. **project-orchestrator** agent coordinates the work
2. **frontend-architect** plans component architecture and data flow
3. **component-developer** implements Vue components
4. **feature-implementer** builds complete features
5. **debugger** troubleshoots issues

### Skills System
Skills provide domain expertise:
- `/nuxt-development` - Nuxt 3 patterns and best practices
- `/vue-shadcn` - Vue 3 + shadcn-vue component development
- `/state-management` - Pinia + TanStack Query patterns
- `/auth-forms` - Authentication and form validation
- `/api-integration` - API design and type-safe fetching
- `/testing` - Vitest and Playwright testing (optional)
- `/ui-ux-design` - Design systems and accessibility

## Conventions

### File Structure
```
src/
├── components/       # Shared UI components
│   ├── ui/          # shadcn-vue base components
│   └── common/      # Common business components
├── composables/     # Vue composables
├── layouts/         # Nuxt layouts
├── pages/           # File-based routing
├── stores/          # Pinia stores
├── server/          # Server routes and middleware
│   ├── api/         # API endpoints
│   └── middleware/  # Server middleware
├── utils/           # Utility functions
└── types/           # TypeScript types
```

### Coding Standards
- Use TypeScript with strict mode
- Prefer `<script setup>` syntax for Vue components
- Use Composition API with `defineComponent` for complex components
- Follow Vue 3 naming conventions (PascalCase for components)
- Use `useFetch` or `useAsyncData` for data fetching in Nuxt
- Implement proper error boundaries and loading states
- Always add proper TypeScript types

### Component Structure
```vue
<script setup lang="ts">
// 1. Imports
// 2. Props & Emits
// 3. Composables
// 4. Reactive state
// 5. Computed properties
// 6. Methods
// 7. Lifecycle hooks
</script>

<template>
  <!-- Single root element recommended -->
</template>

<style scoped>
/* Tailwind @apply for complex styles */
</style>
```

### State Management Patterns
- Use Pinia for global application state
- Use TanStack Query for server state (caching, refetching)
- Use Vue refs/reactive for local component state
- Never mutate state directly outside stores

### Testing Guidelines (Optional)
- Unit tests with Vitest for composables and utilities
- Component tests for critical UI components
- E2E tests with Playwright for critical user flows
- Tests can be skipped with `SKIP_TESTS=true` environment variable

## Environment Variables
- `SKIP_TESTS=true` - Skip all test execution during development
- `NUXT_PUBLIC_API_BASE` - API base URL

## Quick Commands
- `pnpm dev` - Start development server
- `pnpm build` - Build for production
- `pnpm test` - Run tests (skipped if SKIP_TESTS=true)
- `pnpm lint` - Lint code
- `pnpm typecheck` - TypeScript type checking

## Important Notes

1. **Always check `docs/tasks/active.md`** for current task status before starting work
2. **Update task status** after completing work
3. **Use appropriate subagent** for specialized tasks
4. **Follow the component patterns** defined in skills
5. **Commit frequently** with meaningful messages
