---
applyTo: "**/infrastructure/soap/**,**/resources/wsdl/**"
description: "SOAP integration — Spring WS + jaxws-maven-plugin"
---

- Stack: `spring-boot-starter-web-services` + `jaxws-maven-plugin` (`wsimport`).
- WSDL location: `src/main/resources/wsdl/<<vendor>>/<<service>>.wsdl`. Commit the WSDL.
- Generated JAXB classes go to `target/generated-sources/wsimport/` with a stable, vendor-prefixed `packageName` (e.g., `<<org>>.<<service-name>>.infrastructure.soap.<<vendor>>.generated`). The generated package is gitignored AND in `.copilotignore`.
- ALWAYS wrap `WebServiceTemplate` in a domain-named gateway class:
  - `XxxSoapGateway` interface in `application` (port).
  - `XxxSoapGatewayImpl` in `infrastructure/soap` (adapter) extending `WebServiceGatewaySupport`.
  - Gateway returns/accepts DOMAIN types (records). Translate JAXB ↔ domain inside the gateway. Controllers and application services NEVER see JAXB types.
- Resilience4j on every gateway method: `@CircuitBreaker(name = "<<vendor>>-<<service>>")`, `@Retry`, `@TimeLimiter` configured per gateway.
- Fault handling: catch `SoapFaultClientException`, translate to a domain exception extending `<<org>>.commons.errorhandling.DomainException`. Map fault codes to error-code enum values.
- Marshaller: `Jaxb2Marshaller` with `contextPath` matching the generated package. One marshaller per vendor; reuse via `@Bean` in `SoapClientsConfig`.
- Security: WS-Security via `Wss4jSecurityInterceptor` when required; credentials come from Key Vault — never inline.
- XXE protection: marshaller MUST disable external entity processing (`mtomEnabled = false`, secure XML reader).
- Tests: `MockWebServiceServer` from `spring-ws-test`. Verify request payload (`mockServer.expect(payload(...))`) and stub the response. NO real network calls in tests.
- See `docs/snippets/SoapGatewayExample.java`.
