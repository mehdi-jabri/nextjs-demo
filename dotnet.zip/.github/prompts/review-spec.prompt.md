---
description: "Adversarially review a module's spec against source — citations, completeness, hallucinations, orphans"
agent: reviewer
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "problems", "editFiles"]
argument-hint: "targetModule e.g. ORD"
---

# Task: Independent adversarial review of a module spec

Review the specifications for `${input:targetModule}` against the source code. Your goal is to **find
defects**, not to approve. Follow `.github/copilot-instructions.md` and the `reviewer` agent rules.
**Read‑only on code; you may only update review findings/DoD/dashboard under `specs/`.**

## Checks (report each with evidence)
1. **Cite‑or‑flag:** open every cited `file:line` and confirm the code says what the spec claims. List every
   un‑cited behavioral claim and every citation that does not support its claim (`[CONFLICT]`).
2. **No hallucination:** verify all numbers, thresholds, rounding modes, formulas, enum values, and statuses
   match the code exactly.
3. **Completeness vs. manifest:** using `specs/00-index.md`, confirm every `.aspx`/service method/entity/
   validator/authorization check/stored proc in scope is specced or justified (`[DEAD-CODE?]`/out‑of‑scope).
   List anything missing.
4. **Definition of Done:** verify each box with counts; reject boxes you cannot prove.
5. **Traceability:** report dangling IDs and orphans (rules↔requirements↔screens↔entities).
6. **Target‑agnosticism:** flag any Spring/Vue/PostgreSQL leakage in the spec body (allowed only in `specs/migration/`).
7. **Open questions:** confirm every `[NEEDS-BUSINESS-INPUT]` is in `specs/cross-cutting/13-open-questions.md`.

## Output
A prioritized **defect list** (`file → issue → required fix`), the orphan report, and unmet DoD items.
Update the module DoD checkboxes and the review status in `specs/00-index.md`. State **"REVIEW PASSED"**
(with counts) only if there are zero open defects. When in doubt, raise it as a defect.
