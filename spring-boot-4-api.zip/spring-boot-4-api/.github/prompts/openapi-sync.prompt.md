---
description: "Reconcile annotations vs OpenAPI YAML (contract-first) or regenerate the YAML (code-first)"
mode: agent
---

Determine which mode this repo uses by checking for `src/main/resources/openapi/*.yaml`.

## Code-first

Goal: ensure every controller method has consistent OpenAPI annotations matching the actual behaviour.

For every controller method:
- `@Operation(summary, description, operationId)` present and unique.
- `@ApiResponse` for success and every documented non-2xx outcome (matching what the global `<<org>>-common-error-handling` advice maps).
- DTOs annotated with `@Schema` on each property.

Output a list of fixes (`file:line — what's missing`). Apply only if the user approves.

## Contract-first

Goal: detect drift between `src/main/resources/openapi/<<api>>.yaml` and the controller implementations.

For every operation in the YAML:
- A controller method exists with matching path, method, and request/response shapes.
- The implemented `operationId` matches.
- Validation constraints in YAML match `jakarta.validation` on the DTO.

For every controller method:
- A YAML operation exists.

Output a drift report. Propose the smallest set of changes to reconcile (prefer YAML-as-truth — controllers must match the contract).

End with: run `npx @stoplight/spectral-cli lint src/main/resources/openapi/*.yaml` and `oasdiff breaking <main>.yaml <head>.yaml` and report results.
