---
description: 'Zod validation schema standards for forms and API validation'
applyTo: 'schemas/**/*.ts'
---

# Zod Schema Instructions

## Schema Definition Pattern

```typescript
import { z } from 'zod'
import { toTypedSchema } from '@vee-validate/zod'

// 1. Define the base schema
export const userSchema = z.object({
  name: z
    .string()
    .min(1, 'Name is required')
    .min(2, 'Name must be at least 2 characters'),
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Invalid email address'),
  age: z
    .number()
    .min(18, 'Must be at least 18')
    .optional(),
})

// 2. Export typed schema for VeeValidate
export const userFormSchema = toTypedSchema(userSchema)

// 3. Export inferred type
export type UserInput = z.infer<typeof userSchema>
```

## Common Patterns

```typescript
// Password with requirements
const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters')
  .regex(/[A-Z]/, 'Must contain uppercase letter')
  .regex(/[a-z]/, 'Must contain lowercase letter')
  .regex(/[0-9]/, 'Must contain number')

// Password confirmation
const registerSchema = z
  .object({
    password: passwordSchema,
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  })

// Optional with default
const paginationSchema = z.object({
  page: z.number().min(1).default(1),
  limit: z.number().min(1).max(100).default(10),
})

// Enum values
const roleSchema = z.enum(['admin', 'user', 'guest'])

// Arrays
const tagsSchema = z.array(z.string()).min(1, 'At least one tag required')
```

## File Naming

- `auth.ts` - Authentication schemas (login, register)
- `user.ts` - User-related schemas
- `[resource].ts` - Resource-specific schemas

## Server-Side Usage

```typescript
// In server/api handlers
const body = await readBody(event)
const result = userSchema.safeParse(body)

if (!result.success) {
  throw createError({
    statusCode: 400,
    data: result.error.flatten(),
  })
}

// result.data is fully typed
```
