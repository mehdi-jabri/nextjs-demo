---
description: 'Server API route standards for Nuxt.js with validation and error handling'
applyTo: 'server/api/**/*.ts'
---

# Server API Instructions

## Handler Structure

```typescript
import { z } from 'zod'

// Define input schema
const inputSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
})

export default defineEventHandler(async (event) => {
  // 1. Parse and validate input
  const body = await readBody(event)
  const result = inputSchema.safeParse(body)
  
  if (!result.success) {
    throw createError({
      statusCode: 400,
      statusMessage: 'Validation failed',
      data: result.error.flatten(),
    })
  }
  
  // 2. Business logic
  const data = result.data
  // ... process data
  
  // 3. Return response
  return { success: true, data }
})
```

## File Naming

Use HTTP method suffixes:
- `index.get.ts` - GET /api/resource
- `index.post.ts` - POST /api/resource
- `[id].get.ts` - GET /api/resource/:id
- `[id].patch.ts` - PATCH /api/resource/:id
- `[id].delete.ts` - DELETE /api/resource/:id

## Error Handling

```typescript
// Always use createError for HTTP errors
throw createError({
  statusCode: 404,
  statusMessage: 'Not found',
})

// Include data for validation errors
throw createError({
  statusCode: 400,
  statusMessage: 'Validation failed',
  data: { field: 'email', message: 'Invalid email' },
})
```

## Authentication

```typescript
// Check session in protected routes
const session = await getServerSession(event)
if (!session) {
  throw createError({ statusCode: 401, statusMessage: 'Unauthorized' })
}

// Access user from session
const userId = session.user.id
```

## Query Parameters

```typescript
// GET request with query params
const query = getQuery(event)
const page = Number(query.page) || 1
const limit = Number(query.limit) || 10
```
