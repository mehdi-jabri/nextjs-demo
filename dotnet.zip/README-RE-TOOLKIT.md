# Legacy .NET → Specifications: GitHub Copilot Reverse-Engineering Toolkit

A drop-in toolkit that drives **GitHub Copilot (agent mode, Claude Opus 4.6, VS Code 1.114+)** to
reverse-engineer a legacy application into **complete, cited, human-readable specifications and business
rules** — validated by business, then used by developers to rebuild on a modern stack.

- **Legacy stack it targets:** C# / .NET Framework 4.8 · ASP.NET **Web Forms** · 3-tier · Ninject 3.3.6 ·
  AutoMapper 10.1.1 · Entity Framework 6.4.4 · SQL Server.
- **Output:** Markdown under `specs/` (English, source of truth) → French mirror under `specs-fr/`.
- **Rebuild guidance** for the target stack (Spring Boot + Vue + PostgreSQL) is kept **separate** for
  developers under `specs/migration/` — the business spec stays strictly target-agnostic.

> **About "100% confidence":** automation cannot *guarantee* perfection. This toolkit makes confidence
> **earned and auditable** — every claim is cited to `file:line` or explicitly flagged, a coverage manifest
> + Definition-of-Done forces every artifact to be specced or justified, and an independent reviewer agent
> re-audits each module. Whatever can't be proven from code becomes an **open question for business sign-off**.
> That is how you reach "no missing rules" defensibly.

---

## 1. Install (on the machine that has the legacy code + Copilot)

1. Copy these folders into the **root of the legacy repository**:
   - `.github/` (instructions, prompts, agents, tool set)
   - `specs/` (output skeleton + templates + the gold-standard example)
   - `specs-fr/` (French mirror, filled later)
   - `.vscode/settings.json` (enables the customization files)
2. Open the repo in **VS Code 1.114+** with GitHub Copilot signed in.
3. In the Copilot Chat **model picker**, select **Claude Opus 4.6**. (Business/Enterprise admins may need to
   enable the Claude policy at `github.com/settings/copilot`.)
4. Open the Chat **agents dropdown** — you should see `orchestrator`, `analyst`, `reviewer`, `translator`.
   Type `/` to see the prompts (`/00-inventory`, `/extract-business-rules`, …).

> If agents/prompts don't appear, confirm `.vscode/settings.json` loaded and your VS Code is ≥1.114. The
> tool-set file (`.github/copilot/reverse-engineer.toolsets.jsonc`) and tool names degrade gracefully —
> unavailable tools are ignored.

---

## 2. Two ways to run it

### A. Orchestrated (recommended)
Select the **`orchestrator`** agent and tell it: *"Begin reverse-engineering. Start with inventory."* It
reads the coverage dashboard and **delegates each bounded task to a fresh subagent** — this is how a large
codebase fits Opus 4.6's ~200K window (each subagent gets its own context):
`analyst` extracts a module → `reviewer` audits it → `analyst` fixes defects → repeat until clean → next
module → finally `translator` produces the French mirror. Use the **handoff buttons** to approve each step,
or let it loop autonomously (it pauses for `[NEEDS-BUSINESS-INPUT]`).

### B. Manual (full control)
Run the `/`-prompts yourself, **one module per chat session** (start a new chat to reset context):
```
# 1) Foundation (run once)
/00-inventory                         # registers + coverage manifest + seed glossary
/map-dependencies                     # Ninject interface -> implementation -> scope
/extract-data-model   <DataFolder>    # EF6 entities, constraints, migrations, stored procs/triggers
/extract-mappings     <MappingFolder> # AutoMapper rules

# 2) Per module (repeat for each module)
/extract-business-rules <ModuleFolder>
/extract-ui-screen      <Page.aspx>
/generate-spec          <MOD>         # consolidate + module index + cross-links (BEFORE review)
/verify-coverage        <MOD>         # self-check: DoD, orphans, dangling IDs
/review-spec            <MOD>         # independent adversarial review (reviewer agent); fix & repeat

# 3) Cross-cutting (run once, after the modules)
/extract-security                     # roles + authorization matrix (whole app)
/extract-integrations-jobs            # external systems, batch jobs, reports
/edge-case-hunt                       # hidden-rule sweep + capture NFRs
# then re-run /verify-coverage on any module these touched

# 4) Delivery
/migration-notes        <MOD>         # DEV-ONLY rebuild guidance -> specs/migration/ (after Confirmed)
/translate-fr           <MOD>         # French mirror -> specs-fr/ (after Confirmed)
```

---

## 3. The review & iteration loop (how quality is enforced)
`extract` → `/verify-coverage` (self-check) → `/review-spec` (independent reviewer audits citations,
hallucinations, completeness vs. the manifest, orphans, target-agnosticism) → fix → re-review until
**REVIEW PASSED** → business answers `specs/cross-cutting/13-open-questions.md` → statuses flip
`Assumed`/`Needs-business-input` → `Confirmed`. A module is **Done** only when every artifact row is ✅ or
justified, the Definition of Done is fully checked, and the reviewer reports zero defects.

---

## 4. Context & token management (Opus 4.6 ≈ 200K — treat it as scarce)
The toolkit is built so a big codebase never has to fit in one context:
- **Subagent isolation** — the orchestrator delegates discrete tasks; each runs in a fresh context.
- **Specs are external memory** — every step writes to `specs/` and re-reads the small dashboard/registers,
  not raw code. Inventory once, reuse forever. A compaction never loses work.
- **One module per chat session**; scope with `#file:`/`#folder:`; use `#codebase` only to *locate* code.
- **Lean always-on instructions** — `copilot-instructions.md` is kept short; detail loads via `applyTo`.
- **Close unneeded editors** and avoid opening large/generated files (they leak into context).
- **Optional upgrade:** if **Claude Opus 4.8 (1M context)** is available in your Copilot, selecting it (or
  setting `model:` in the agents/prompts) greatly relaxes these limits.

---

## 5. Output structure
```
specs/
  00-index.md            # coverage dashboard = proof nothing was skipped (start here)
  01-system-overview.md  02-glossary.md
  _templates/            # canonical formats every doc emulates
  modules/_EXAMPLE-Orders/   # ⭐ fully-worked gold-standard module (the quality bar)
  modules/<MOD>/             # one folder per real module (index, use-cases, business-rules,
                             #   data-dictionary, processes, screens/)
  migration/             # DEV-ONLY target-stack rebuild guidance (separate from business specs)
  cross-cutting/         # integrations, reports, security, NFRs, traceability, open questions
specs-fr/                # French mirror of CONFIRMED business docs
```
**Reading guide:** business reviewers read `01`, each module's use-cases/business-rules/processes, the
reports & security docs, and answer the open questions. Developers read everything plus `migration/` and the
`## Developer Notes (legacy)` appendices.

---

## 6. How the toolkit is wired (for maintainers)
- `.github/copilot-instructions.md` — always-on rules: mission, stack, cite-or-flag, marker vocabulary,
  context discipline, ID conventions, output conventions.
- `.github/instructions/*.instructions.md` — per-tier "how to read this code", auto-applied by `applyTo`.
- `.github/prompts/*.prompt.md` — the `/`-commands (one bounded task each).
- `.github/agents/*.agent.md` — `orchestrator` (delegates) + `analyst` / `reviewer` / `translator` workers,
  wired with `agents:` (subagents) and `handoffs:`.
- `.github/copilot/reverse-engineer.toolsets.jsonc` — read-only/author tool sets.

---

## 7. First-run smoke test (validate before committing to a full pass)
1. `/00-inventory` → confirm `specs/00-index.md` fills with the project topology + artifact inventory.
2. Pick one small module; run `/extract-business-rules` + `/extract-ui-screen` (or let `orchestrator` do it).
   Confirm output matches the `_EXAMPLE-Orders` quality: **every rule cited or marked**, confidence/status set,
   dashboard row updated, no target-stack content in the body.
3. `/review-spec <MOD>` → confirm it reports defects/orphans (or PASSES with counts).
4. `/migration-notes <MOD>` then `/translate-fr <MOD>` → confirm `specs/migration/` and `specs-fr/` populate.

---

## 8. Notes
- The `_EXAMPLE-Orders` module and `_EXAMPLE-ORD-migration-notes.md` are **fictional**; they exist as the
  quality standard. Delete them once you have real modules, or keep them as a reference.
- English is the source of truth; generate French only **after** a module is `Confirmed` to avoid translating
  churn.
- The toolkit is tailored to Web Forms + EF6 + Ninject + AutoMapper, but the `specs/` format is reusable for
  other legacy apps.
