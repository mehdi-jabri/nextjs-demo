---
applyTo: "**/api/**/*Controller.java,**/resources/openapi/**.yaml,**/OpenApiConfig.java"
description: "OpenAPI / springdoc conventions"
---

- springdoc-openapi 3.0.3 (`springdoc-openapi-starter-webmvc-ui`).
- Code-first by default. Externally consumed APIs MUST be contract-first: spec at `src/main/resources/openapi/<<api>>.yaml`, generator-produced interfaces under `target/generated-sources/openapi/`, controllers implement those interfaces.
- Every endpoint method:
  - `@Operation(summary = "<imperative phrase>", description = "<2–3 sentences>", operationId = "<camelCase, unique across the API>")`
  - `@ApiResponse(responseCode = "200", ...)` for success.
  - `@ApiResponse` entries for every documented non-2xx outcome (400, 401, 403, 404, 409, 422, 5xx as relevant) with `content = @Content(schema = @Schema(implementation = ProblemDetail.class))`.
- Security schemes declared once in `OpenApiConfig` via `@OpenAPIDefinition` + `@SecurityScheme`; endpoints reference them via `@SecurityRequirement`.
- DTO records carry `@Schema(description = "...", example = "...")` on each component property.
- Versioning: align with Boot 4 `ApiVersionInserter`. Note the known `springdoc#3163` interaction — if Swagger UI 400s with versioned paths, document the workaround in this repo and link the issue.
- CI gates: Spectral (`.spectral.yaml`) + oasdiff (breaking-change vs `main`). Both must be green.
- See `docs/snippets/OpenApiConfigExample.java`.
