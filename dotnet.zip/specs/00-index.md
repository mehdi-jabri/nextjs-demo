# 00 — Specification Index & Coverage Dashboard

> **Status:** Not started · **Last updated:** _(date)_ · **Source snapshot:** _(commit/label)_
>
> This is the master entry point and the **proof of completeness**. `/00-inventory` seeds it; every extraction
> prompt updates it; `/verify-coverage` audits it. A module reaches 100 % coverage only when every artifact row
> is ✅ or explicitly justified (🚫 dead‑code / out‑of‑scope) **and** its Definition of Done is fully checked.

## Reading guide
- **Business reviewers** → read `01-system-overview.md`, each module's use cases (`*-03-use-cases.md`) and
  business rules (`*-05-business-rules.md`), processes (`*-07-processes.md`), `cross-cutting/09-reports.md`,
  `cross-cutting/10-security-authorization.md` — and answer the ❓ items in `cross-cutting/13-open-questions.md`.
- **Developers** → read everything, including the `## Developer Notes (legacy)` and `## Migration Notes`
  appendices and `cross-cutting/12-traceability-matrix.md`.

Legend: ✅ done · ⚠ partial / medium confidence · ❓ needs business input · 🚫 dead‑code/out‑of‑scope · ⛔ not done.

## Document index
| Doc | Title | Status | Link |
|---|---|---|---|
| D0 | Index & Coverage Dashboard | — | (this file) |
| D1 | System Overview | Not started | [01-system-overview.md](01-system-overview.md) |
| D2 | Glossary / Ubiquitous Language | Not started | [02-glossary.md](02-glossary.md) |
| D8 | Integrations & Interfaces | Not started | [cross-cutting/08-integrations.md](cross-cutting/08-integrations.md) |
| D9 | Reports Catalog | Not started | [cross-cutting/09-reports.md](cross-cutting/09-reports.md) |
| D10 | Security & Authorization | Not started | [cross-cutting/10-security-authorization.md](cross-cutting/10-security-authorization.md) |
| D11 | Non‑Functional Requirements | Not started | [cross-cutting/11-non-functional.md](cross-cutting/11-non-functional.md) |
| D12 | Traceability Matrix | Not started | [cross-cutting/12-traceability-matrix.md](cross-cutting/12-traceability-matrix.md) |
| D13 | Open Questions / Decision Log | Not started | [cross-cutting/13-open-questions.md](cross-cutting/13-open-questions.md) |
| — | Migration Notes (dev-only, target stack) | Not started | [migration/00-migration-index.md](migration/00-migration-index.md) |
| — | French mirror (business) | Not started | [../specs-fr/README-fr.md](../specs-fr/README-fr.md) |

A fully‑worked reference module lives at [modules/_EXAMPLE-Orders/](modules/_EXAMPLE-Orders/ORD-00-module-index.md) —
copy its structure for every real module. Its dev-only rebuild guidance is at
[migration/_EXAMPLE-ORD-migration-notes.md](migration/_EXAMPLE-ORD-migration-notes.md).

## Module coverage
> One row per module (short `<MOD>` code defined in `01-system-overview.md`). Fill `#specced` as you go.

| Module | #aspx | specced | #services | specced | #entities | specced | #rules | %Confirmed | %Needs‑input | DoD |
|---|---|---|---|---|---|---|---|---|---|---|
| _(none yet — run `/00-inventory`)_ | | | | | | | | | | ⛔ |

## Artifact inventory (the proof nothing was skipped)
> Every source artifact, marked as covered or justified. `/00-inventory` populates this with status `Not started`.

| Source artifact (file) | Type | Module | Covered by | Status |
|---|---|---|---|---|
| _(none yet)_ | | | | Not started |

## Confidence & status rollup
| | Confirmed | Assumed | Needs‑input | Dead‑code? |
|---|---|---|---|---|
| Rules | 0 | 0 | 0 | 0 |
| Requirements | 0 | 0 | 0 | 0 |

## Project topology (from `/00-inventory`)
```mermaid
flowchart TD
  Web[Presentation] --> BLL[Business]
  BLL --> DAL[Data Access]
  DAL --> DB[(SQL Server)]
```
_(Replace with the real project/tier graph.)_
