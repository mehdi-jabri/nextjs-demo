---
applyTo: "**/*Repository*.cs, **/*DbContext*.cs, **/*Context.cs, **/*.edmx, **/Migrations/**/*.cs, **/*Entities*/**/*.cs, **/*Model*/**/*.cs, **/*DAL*/**/*.cs, **/*Data*/**/*.cs"
description: "How to read EF6 + SQL Server and derive the domain model, schema, and data-integrity rules"
---

# Reading the Data Access tier (Entity Framework 6 + SQL Server)

## Step 0 — Determine the modeling style first
- **Code First** (POCO + Fluent API in `OnModelCreating` and/or data annotations),
- **Database First / EDMX** (parse `*.edmx`: `EntityType`, `Property` `Nullable`/`MaxLength`/`Precision`/`Scale`/
  `StoreGeneratedPattern`, `Key`, `Association` multiplicity, `ReferentialConstraint`, function/SP imports), or
- **Code First from existing DB**. This decides where schema truth lives.

## What to extract
1. **Entities & relationships** — per entity: properties, types, nullability, length, precision/scale (money!),
   navigation properties. Derive cardinality: 1:1 (`HasRequired().WithRequiredDependent()`), 1:N
   (`HasMany().WithRequired/Optional`), M:N (`HasMany().WithMany().Map(...)` → join table).
2. **Keys & constraints** — PKs (`HasKey`/`[Key]`), composite keys, FKs, unique indexes
   (`HasIndex().IsUnique()` / `[Index(IsUnique=true)]`), `IsRequired`, `HasMaxLength`, `HasPrecision`.
   Each non‑null / unique / length / precision constraint is a **data‑integrity business rule** (`BR-…` category `Constraint`).
3. **Cascade rules** — `WillCascadeOnDelete(true/false)` → "deleting X deletes Y" vs "blocked if referenced".
4. **Defaults / computed columns** — `[DatabaseGenerated(...)]`, `StoreGeneratedPattern`, SQL defaults in
   migrations. Computed columns encode derivation rules at the DB level.
5. **Concurrency** — `[Timestamp]`/`rowversion`, `[ConcurrencyCheck]`, `IsConcurrencyToken()` → optimistic‑lock rule.
6. **Soft‑delete & audit** — `IsDeleted`/`IsActive`, `CreatedBy/CreatedDate/ModifiedBy/ModifiedDate`. Soft‑delete
   implies a **filtering rule everywhere** ("never show deleted rows") — verify it is applied in every repository.
7. **`DbContext` deep dive** — list `DbSet<>` (the aggregate roots), read **all** of `OnModelCreating`, and
   **always read any `SaveChanges`/`SaveChangesAsync` override fully** — a primary EF6 rule‑injection point:
   audit stamping, soft‑delete conversion, pre‑save validation, tenant stamping, domain‑event dispatch.
8. **EF interceptors** — `IDbCommandInterceptor`/`IDbCommandTreeInterceptor` registered via `DbConfiguration`
   or `<entityFramework><interceptors>`; they can mutate every query globally (tenant/soft‑delete filters).
9. **Migrations** — read `Migrations/`: `Configuration.cs` **`Seed()`** = reference/lookup data and default
   roles/admins (= business rules); each migration `Up()` incl. raw `Sql(...)` that creates SPs/triggers/indexes
   not visible in the model.
10. **Raw / dynamic SQL** — `Database.SqlQuery`, `ExecuteSqlCommand`, string‑built SQL → inline rules and filters.

## SQL Server → PostgreSQL type map (reference for `/migration-notes` only — NOT for the spec body)
> The data dictionary stays target‑agnostic (legacy types only). This map is used by `/migration-notes`
> when producing dev‑only guidance under `specs/migration/`.
| SQL Server | PostgreSQL |
|---|---|
| `nvarchar(n)` / `varchar(n)` | `varchar(n)` |
| `nvarchar(max)` | `text` |
| `int` / `bigint` / `smallint` | `integer` / `bigint` / `smallint` |
| `bit` | `boolean` |
| `decimal(p,s)` / `money` | `numeric(p,s)` |
| `datetime` / `datetime2` | `timestamp` |
| `datetimeoffset` | `timestamptz` |
| `uniqueidentifier` | `uuid` |
| `varbinary(max)` | `bytea` |
| `rowversion`/`timestamp` | app‑level optimistic‑lock column (`xmin` or version int) |
| `IDENTITY` | `GENERATED ... AS IDENTITY` / sequence |

## How to document
Produce a `ENT-<Name>` data‑dictionary entry per entity (`specs/_templates/data-dictionary-entity.md`) with the
attribute table, relationships, invariants (link to `BR-…`), and a Mermaid `erDiagram`. Stored procs/views/
triggers go to `/extract-data-model` output and `specs/cross-cutting/09-reports.md` where relevant. Put EF
mapping detail in **Developer Notes (legacy)**. The PostgreSQL target schema is **not** written here — it is
produced separately by `/migration-notes` into `specs/migration/`. Keep this entry target‑agnostic.
