---
description: "Extract a screen specification + UI/validation rules from a Web Forms page or control"
agent: agent
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "findTestFiles", "problems", "fetch", "editFiles"]
argument-hint: "targetPage e.g. src/Company.Web/Orders/OrderEdit.aspx"
---

# Task: Extract a Web Forms screen specification

Analyze `${input:targetPage}` together with its code‑behind, the master page, and any base page/control class.
Follow `.github/instructions/webforms-ui.instructions.md` and `.github/copilot-instructions.md`. **Read‑only.**

## Steps
1. Decode **every validator** in the markup into a rule (translate regex to English; note `ValidationGroup`,
   `CausesValidation="false"`, and `CustomValidator` client + server logic).
2. Read `Page_Load` (both `!IsPostBack` and postback branches) and **every control event handler**:
   preconditions → validation set → effect → navigation → side effects.
3. Capture data‑binding (columns, formatting, `Eval/Bind`, `RowDataBound`/`ItemDataBound` display/authz rules),
   navigation out (redirects + query‑string contract), state (Session/ViewState/hidden), client‑side JS rules,
   and role‑based show/hide.

## Output (emulate `specs/modules/_EXAMPLE-Orders/ORD-04-screens/`)
- `specs/modules/<MOD>/<MOD>-04-screens/SCR-<MOD>-NNN-<slug>.md` from `specs/_templates/screen-spec.md`:
  purpose, actors/access, entry parameters, controls+validation table, actions→behavior, display rules,
  navigation in/out, state used. ViewState/postback mechanics → **Developer Notes (legacy)**. Do NOT add
  target‑stack (Vue) hints — those are produced separately by `/migration-notes`.
- Each UI/validation rule → a `BR-<MOD>-NNN` entry in the module catalog (flag client‑only rules and `[CONFLICT]`s).
- Update `specs/cross-cutting/12-traceability-matrix.md`, `13-open-questions.md`, and `specs/00-index.md` coverage.
