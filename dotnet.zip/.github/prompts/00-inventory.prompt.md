---
description: "Phase 1 — inventory the solution and build the coverage manifest (run this first)"
agent: agent
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "findTestFiles", "problems", "fetch", "editFiles"]
argument-hint: "(no argument needed — scans the whole solution)"
---

# Task: Build the codebase inventory & coverage manifest

You are starting the reverse‑engineering effort. Do **not** extract rules yet — first build the complete map
so coverage becomes measurable. **Read‑only. Do not modify code.** Follow the rules in
`.github/copilot-instructions.md`.

## Steps
1. Read every `*.sln` and `*.csproj`. Enumerate projects; classify each as **Presentation / Business / Data /
   Shared** (heuristics: `System.Web` + `.aspx` = Presentation; `*Service`/`*Manager` = Business;
   `EntityFramework` + `DbContext`/`*Repository` = Data; `*.Common`/`*.Contracts`/`*.Entities` = Shared).
   Draw the inter‑project dependency graph (from `<ProjectReference>`).
2. Read `packages.config` / `<PackageReference>`; confirm Ninject 3.3.6, AutoMapper 10.1.1, EF 6.4.4, and flag
   any package implying behavior (logging, scheduling, validation, mail, reporting, payment/SMS/cloud SDKs).
3. Read the root and every nested `web.config` + transforms and `Global.asax.cs` (connection strings, appSettings,
   auth, modules/handlers, sessionState, globalization, EF config).
4. Build these **registers** (each row is later marked analyzed): Page/Control sitemap, Entity register, Service
   register, Repository/SP register, AutoMapper profile register, Ninject binding register, Config register,
   Integration register.

## Output
Create / update **`specs/00-index.md`** from `specs/_templates/module-index.md` conventions and the dashboard
format already in `specs/00-index.md`:
- The **module list** (with short `<MOD>` codes) → also seed `specs/01-system-overview.md` §Scope.
- The **artifact inventory** table (every `.aspx`, service class, entity, stored proc) with status `Not started`.
- The project/tier topology and a Mermaid dependency `flowchart`.
- **Seed `specs/02-glossary.md`** with the obvious domain terms surfaced by project/entity/table names
  (canonical term ↔ legacy code identifier), each cited; extraction prompts enrich it per module.
List anything ambiguous as `[NEEDS-BUSINESS-INPUT]` and append to `specs/cross-cutting/13-open-questions.md`.
Do not guess a module's purpose — derive it from names/folders and mark uncertainty.
