---
description: "Add a new SOAP client — WSDL ingestion, JAXB generation, gateway scaffold"
mode: agent
---

Switch to the `soap-integrator` agent first if not already active. Follow `.github/instructions/soap.instructions.md` strictly.

## Bucket: RED. Plan-only mode — do NOT execute autonomously. Produce the plan and stop.

## Inputs (ask if missing)

- Vendor name and short identifier (used for package suffix and circuit-breaker name).
- WSDL URL or local file (will be committed under `src/main/resources/wsdl/<<vendor>>/`).
- One operation to scaffold first.
- Auth: WS-Security username/password from Key Vault, mutual TLS, or none.

## Plan output

Produce a numbered plan covering:

1. WSDL placement: exact path under `src/main/resources/wsdl/<<vendor>>/<<service>>.wsdl`.
2. `jaxws-maven-plugin` execution block to add to `pom.xml` — `wsdlDirectory`, `packageName` (vendor-prefixed), `sourceDestDir = target/generated-sources/wsimport`. Show the exact XML.
3. `.gitignore` and `.copilotignore` entries for the generated package.
4. New beans in `SoapClientsConfig`:
   - `Jaxb2Marshaller` with `contextPath` matching the generated package, XXE protection enabled.
   - `WebServiceTemplate` (named) wired with the marshaller and the message factory.
   - `<<Vendor>>SoapGateway` bean wiring the template into the adapter.
5. Port interface in `<<org>>.<<service-name>>.application.port.<<vendor>>.<<Vendor>>Gateway` — domain types only, no JAXB.
6. Adapter in `<<org>>.<<service-name>>.infrastructure.soap.<<vendor>>.<<Vendor>>GatewayImpl` extending `WebServiceGatewaySupport`. Translate JAXB ↔ domain inside.
7. Resilience4j config block `<<vendor>>-<<service>>` in `application.yml`. Apply `@CircuitBreaker`, `@Retry`, `@TimeLimiter` on the adapter method.
8. Fault mapping: domain exception extending `<<org>>.commons.errorhandling.DomainException`; `SoapFaultClientException` translated in the adapter; `ErrorCode` value chosen.
9. WS-Security: if needed, `Wss4jSecurityInterceptor` wired with credentials from `<<org-prefix>>.keyvault.<<vendor>>.{username,password}`.
10. Test plan: `MockWebServiceServer` test verifying request payload (build expected XML from the WSDL message types) and stubbing both happy path and one fault.
11. README and ADR updates.

End with:
- Files to create / modify (paths only).
- Open questions (auth, retry policy, idempotency of the operation).

Do NOT generate code in this prompt — only the plan. The user will approve the plan, then dispatch implementation manually.
