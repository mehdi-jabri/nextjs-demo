# 08 — Integrations & Interfaces

> **Status:** Not started · **Last updated:** _(date)_ · Back to [index](../00-index.md).
> Populated by `/extract-integrations-jobs`. One `INT-NNN` per external interface (template: `../_templates/integration.md`).

## Integration register
| ID | Name | Direction | Protocol/format | Trigger | Confidence | Status | Source |
|---|---|---|---|---|---|---|---|
| _(none yet)_ | | | | | | | |

## Scheduled / background jobs
| ID (PRC) | Job | Frequency | Schedule source | What it does | Rules | Source |
|---|---|---|---|---|---|---|
| | | | | | | |

---
_(Append full `INT-NNN` records below, each from the integration template.)_
