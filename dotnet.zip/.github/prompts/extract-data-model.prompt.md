---
description: "Extract the EF6 domain model, schema, constraints, migrations and stored-proc/trigger logic"
agent: agent
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "findTestFiles", "problems", "fetch", "editFiles"]
argument-hint: "targetFolder e.g. src/Company.Data  (or a single entity area)"
---

# Task: Extract the data model & data-integrity rules

Analyze `${input:targetFolder}` (use `#codebase` for cross‑references). Follow
`.github/instructions/data-ef6.instructions.md`, `.github/instructions/sql.instructions.md`, and
`.github/copilot-instructions.md`. **Read‑only.**

## Steps
1. Determine the modeling style (Code First / EDMX / DB First).
2. For each entity: properties, types, nullability, length, precision/scale, relationships + cardinality,
   keys, unique indexes, defaults, computed columns, concurrency tokens, soft‑delete/audit columns.
3. Read the full `OnModelCreating` and **every `SaveChanges`/`SaveChangesAsync` override** and EF interceptors.
4. Read `Migrations/` — capture `Seed()` reference data and any raw `Sql(...)` creating SPs/triggers/indexes.
5. Read every stored procedure / view / function / **trigger** referenced; translate its logic to plain rules.

## Output
- One `ENT-<Name>` entry per entity in the relevant `specs/modules/<MOD>/<MOD>-06-data-dictionary.md`
  (use `specs/_templates/data-dictionary-entity.md`), each with attribute table, relationships, invariants,
  and a Mermaid `erDiagram`. Keep the entry **target‑agnostic** — do NOT add the PostgreSQL schema here; the
  SQL Server→PostgreSQL mapping is produced separately by `/migration-notes` into `specs/migration/`.
- Each data‑integrity / computed / SP / trigger rule → a `BR-… (Constraint | Calculation)` entry in the module's
  `<MOD>-05-business-rules.md`, cited to `file:line` or `usp_Name:line`.
- Mark anything you cannot confirm as live (e.g. SP not called from code) `[UNVERIFIED]` or `[DEAD-CODE?]`.
- Update coverage rows in `specs/00-index.md`.
