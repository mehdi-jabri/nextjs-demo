---
description: "Map the Ninject DI graph (interface -> implementation -> scope) to know the live behavior"
agent: agent
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "findTestFiles", "problems", "fetch", "editFiles"]
argument-hint: "(no argument needed)"
---

# Task: Map the Ninject dependency graph

Follow `.github/instructions/di-mapping.instructions.md` and `.github/copilot-instructions.md`. **Read‑only.**

## Steps
1. Read every `NinjectModule.Load()` and the kernel bootstrap (`CreateKernel`/`NinjectWebCommon`/`Global.asax`).
2. For each binding record: **interface → concrete implementation → scope** (Singleton/Request/Transient) and any
   `.When(...)`/named/conditional binding (possible feature flag or multi‑tenancy).
3. Identify which implementation is **live** when several exist; flag test/stub/fake bindings as not‑live.

## Output
Append a "Dependency Injection Graph" section to `specs/01-system-overview.md` (Developer Notes area) with the
interface→implementation→scope table and a short note on any conditional bindings (record those as
`[NEEDS-BUSINESS-INPUT]` if they look like feature toggles). This table is the reference every later extraction
uses to resolve an interface to its real behavior. Update the relevant coverage rows in `specs/00-index.md`.
