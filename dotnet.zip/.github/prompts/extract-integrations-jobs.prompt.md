---
description: "Extract external integrations, interfaces, reports, and scheduled/background jobs"
agent: agent
model: Claude Opus 4.6
tools: ["codebase", "search", "usages", "findTestFiles", "problems", "fetch", "editFiles"]
argument-hint: "(no argument needed — scans whole solution incl. non-web projects)"
---

# Task: Extract integrations, interfaces, reports & scheduled jobs

Follow `.github/instructions/config-crosscutting.instructions.md`, `.github/instructions/sql.instructions.md`,
and `.github/copilot-instructions.md`. **Read‑only.**

## Steps
1. **External integrations** — WCF/SOAP (`Reference.cs`, `.svcmap`, `<system.serviceModel><client>`), REST/
   `HttpClient`/`WebClient`, SMTP/email (templates + triggers), file IO (import/export formats, watched folders),
   message queues, payment/SMS/third‑party SDKs. For each: direction, protocol, endpoint (from config), payload
   shape, trigger condition, error/retry behavior.
2. **Scheduled/background jobs** — Quartz/Hangfire, `Application_Start` timers, Windows Service / console runner
   projects, SQL Agent jobs. These hold batch rules outside the web path (billing, expiry, reminders).
3. **Reports** — report pages, `.rdl`/SSRS, export to PDF/Excel, and the SP/query behind each.

## Output
- `specs/cross-cutting/08-integrations.md` — `INT-NNN` entries (`specs/_templates/integration.md`): contract,
  auth mechanism (describe, never copy secrets), error/retry, business trigger.
- `specs/cross-cutting/09-reports.md` — `RPT-NNN` entries (`specs/_templates/report.md`): purpose, parameters,
  columns, filters, underlying query, embedded rules.
- Scheduled jobs → `PRC-…` processes (in the owning module or `08-integrations.md`).
- Rules embedded in integrations/reports/jobs → `BR-…` entries, cited. Update `13-open-questions.md` and
  `specs/00-index.md` coverage.
