# Migration Notes — Index (DEV-ONLY)

> **Status:** Not started · **Last updated:** _(date)_ · Back to [spec index](../00-index.md).
>
> This area holds **developer-only rebuild guidance** for the target stack (**Spring Boot + Vue + PostgreSQL**).
> It is produced by `/migration-notes` **after** a module's English spec is `Confirmed`. The business
> specifications under `specs/` stay strictly target-agnostic; **all** new-stack content lives here.
> Business reviewers do not need to read this folder.

## Per-module migration notes
| Module | Migration notes | Source spec status | Status |
|---|---|---|---|
| _(example)_ ORD | [_EXAMPLE-ORD-migration-notes.md](_EXAMPLE-ORD-migration-notes.md) | Confirmed | Example |
| _(none yet — run `/migration-notes` per confirmed module)_ | | | Not started |

## Global conventions
- SQL Server → PostgreSQL type mapping table: see `.github/instructions/data-ef6.instructions.md`.
- Each note references spec items by **ID + citation**; it never restates business behavior.
- Cross-cutting target concerns (auth → Spring Security, DI → Spring beans, AutoMapper → MapStruct,
  Web Forms postback/ViewState → Vue state) can be summarized here once and referenced per module.
