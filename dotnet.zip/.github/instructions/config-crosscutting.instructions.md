---
applyTo: "**/web.config, **/app.config, **/Web.*.config, **/App.config, **/Global.asax, **/Global.asax.cs, **/*HttpModule*.cs, **/*HttpHandler*.cs"
description: "How to read configuration, Global.asax, and cross-cutting concerns for hidden rules"
---

# Reading configuration & cross-cutting concerns

## Configuration files (root AND every nested `web.config`)
Folder‑scoped `web.config` files are common and easy to miss. Catalogue:
- `<connectionStrings>` → databases touched (multiple = multi‑DB or multi‑tenant).
- `<appSettings>` → **every appSetting is a candidate configuration‑driven rule** (thresholds, limits, feature
  flags, endpoints, file paths, email addresses). Trace each to its `ConfigurationManager.AppSettings[...]`
  usage to learn which decision it controls. Record value + meaning; mark `[CONFIG-DEPENDENT]`.
- `<authentication mode>` + `<forms>` (login URL, timeout, ticket); `<membership>`/`<roleManager>`/`<profile>`.
- `<authorization>` (`<allow>`/`<deny>` by role/user/verb) — root **and** per‑folder / `<location>`. Feed the
  authorization matrix in `specs/cross-cutting/10-security-authorization.md`.
- `<httpModules>`/`<modules>` and `<httpHandlers>`/`<handlers>` → request‑wrapping cross‑cutting rules and
  custom endpoints (e.g. a handler streaming reports/files with its own auth).
- `<sessionState>` (mode/timeout), `<customErrors>`, `<globalization>` (**culture → number/date/currency parsing
  rules**), `<system.serviceModel>` (WCF clients/services = integrations), `<entityFramework>`/`DbConfigurationType`.
- `Web.Release.config` / `Web.Staging.config` **transforms** → environment‑specific values that can change rules.

## Global.asax.cs (read fully)
`Application_Start` (DI kernel build, route registration, AutoMapper init, startup seeding),
`Application_End`, `Session_Start`/`Session_End`, `Application_BeginRequest`/`AuthenticateRequest`/
`AuthorizeRequest` (tenant resolution, culture, request‑wide security), `Application_Error` (global error policy →
maps exception to user message/behavior). `RouteConfig`/`RouteTable.Routes.MapPageRoute(...)` → the public URL contract.

## HttpModules / HttpHandlers
Read their `Init`/`ProcessRequest` — they wrap every request with cross‑cutting rules (auth, logging, URL
rewriting, file/report serving).

## Other cross-cutting concerns to locate
- **Logging/audit** config (log4net/NLog/Serilog) → which actions are audited is a business/compliance rule.
- **Caching** (`Cache`, `MemoryCache`, `<%@ OutputCache %>`) → cached items + invalidation rules.
- **Scheduled/background jobs** (Quartz/Hangfire, `Application_Start` timers, Windows Service / console runner
  projects, SQL Agent jobs) → batch business rules outside the web request path (nightly billing, expiry,
  reminders). Document each as a first‑class `PRC-…` process via `/extract-integrations-jobs`.
- **Multi‑tenancy & feature flags** — determine whether the app is multi‑tenant (tenant resolution by
  subdomain/route/claim, per‑tenant filtering/config) before assuming single‑tenant.

## How to document
Config‑driven rules → `BR-… Configuration` with the setting name, current value, and effect. Auth config →
`10-security-authorization.md`. Jobs/integrations → `/extract-integrations-jobs`. Global error/culture policy →
non‑functional requirements. Keep raw config detail in **Developer Notes**.
