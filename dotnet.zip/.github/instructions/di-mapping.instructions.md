---
applyTo: "**/*Module*.cs, **/*NinjectWebCommon*.cs, **/*Bootstrapper*.cs, **/*Profile*.cs, **/*Mapping*.cs, **/*MappingProfile*.cs, **/*AutoMapper*.cs"
description: "How to read Ninject DI bindings and AutoMapper profiles — the dependency graph and hidden mapping logic"
---

# Reading DI (Ninject 3.3.6) and Object Mapping (AutoMapper 10.1.1)

## Ninject bindings — find the LIVE behavior
Read every `NinjectModule.Load()` and the kernel bootstrap (`CreateKernel` in `Global.asax`/`NinjectWebCommon`).
Build the **dependency graph**: interface → concrete implementation → **scope**
(`InSingletonScope`/`InRequestScope`/`InTransientScope`). This tells you:
- Which implementation actually runs in production when several exist (ignore test/stub/fake bindings).
- Singletons that hold shared state across requests.
- Request‑scoped units of work (often the `DbContext`).
- `.When(...)` / named / conditional bindings — these can implement **feature toggles or multi‑tenancy**.

Output an interface→implementation→scope table (`/map-dependencies`). When you later read a service that
depends on an interface, **resolve it to its bound implementation** before describing behavior.

## AutoMapper profiles — mapping hides business logic
Read every `Profile`/`CreateMap`. The mappings reveal the **DTO ↔ entity shape** (what the UI/API exposes vs.
what is internal). Pay special attention to:
- `ForMember(...).MapFrom(...)` expressions → **derivation/projection rules** (computed display fields) → emit as `BR-… Calculation`.
- `.Ignore()` → fields deliberately not exposed (security/PII or internal‑only) → note in security model.
- **Custom `IValueResolver`/`ITypeConverter`**, **`AfterMap`/`BeforeMap`**, `ConstructUsing`/`ConvertUsing`,
  conditional `Condition(...)` → real business logic inside mapping. **Read each fully** — commonly missed.
- Flattening conventions (`Order.Customer.Name` → `CustomerName`) reveal naming/relationship structure.

## How to document
The DI graph goes to `/map-dependencies` output (kept for reference, mostly Developer Notes material). Mapping‑
derived rules (MapFrom formulas, AfterMap logic) become `BR-…` entries with citations; `.Ignore()` fields feed
the security model. Keep the AutoMapper/Ninject mechanics in **Developer Notes**, not the business body.
