# GitHub Copilot Instructions for Nuxt.js Frontend Development

## Project Overview

This is a Nuxt 4 frontend application using:
- **Framework**: Nuxt 4 with Vue 3 Composition API
- **UI**: shadcn-vue components with Tailwind CSS
- **State**: Pinia (global state) + TanStack Query (server state)
- **Auth**: @sidebase/nuxt-auth
- **Forms**: VeeValidate + Zod validation
- **Utilities**: VueUse composables
- **API**: $fetch with singleton data fetching / tRPC for type-safe APIs
- **Testing**: Vitest (unit) + Playwright (e2e)

## Nuxt 4 Key Changes

- **New `app/` directory**: Default `srcDir` is now `app/`
- **Singleton data fetching**: Shared refs for same `useAsyncData`/`useFetch` key
- **Shallow reactivity**: `data` from `useFetch`/`useAsyncData` is `shallowRef`
- **Default undefined**: `data`/`error` default to `undefined` (not `null`)
- **TypeScript config splitting**: Separate tsconfig for app, server, node, shared
- **Reactive keys**: Computed refs/getters as keys auto-refetch data

## Coding Standards

### TypeScript
- Use strict TypeScript - no `any` without justification
- Define interfaces for all props, emits, and data structures
- Use `defineComponent` types for Vue components
- Export types from dedicated `types/` directory

### Vue Components
- Use `<script setup lang="ts">` syntax exclusively
- Define props with `defineProps<T>()` and defaults with `withDefaults()`
- Type emits with `defineEmits<T>()`
- Use `defineSlots<T>()` for typed slots
- Keep components focused and single-purpose

### File Naming
- Components: PascalCase (`UserCard.vue`)
- Composables: camelCase with 'use' prefix (`useCounter.ts`)
- Utilities: camelCase (`formatDate.ts`)
- Types: PascalCase (`User.ts`)
- Pages: kebab-case (`user-profile.vue`)

### Imports
- Use auto-imports (Nuxt composables, Vue utilities)
- Explicit imports for components from shadcn-vue
- Absolute imports using `@/` alias

## Component Patterns

### Standard Component Structure
```vue
<script setup lang="ts">
// 1. Imports
import { Button } from '@/components/ui/button'

// 2. Props
interface Props {
  title: string
  count?: number
}
const props = withDefaults(defineProps<Props>(), {
  count: 0,
})

// 3. Emits
const emit = defineEmits<{
  submit: [data: FormData]
}>()

// 4. Composables & State
const route = useRoute()
const isLoading = ref(false)

// 5. Computed
const displayTitle = computed(() => props.title.toUpperCase())

// 6. Methods
async function handleSubmit() {
  // ...
}

// 7. Lifecycle
onMounted(() => {
  // ...
})
</script>

<template>
  <!-- Template content -->
</template>
```

### Data Fetching
- Use `useFetch` for simple API calls in components
- Use `useAsyncData` for complex data fetching logic
- Use TanStack Query for cached server state
- Handle loading, error, and empty states

### Form Handling
- Use VeeValidate + Zod for all forms
- Define schemas in `schemas/` directory
- Use `toTypedSchema()` from `@vee-validate/zod`
- Show inline validation errors

## API Patterns

### Server Routes
- Place in `server/api/` directory
- Use HTTP method suffixes (`.get.ts`, `.post.ts`)
- Validate input with Zod
- Return typed responses
- Handle errors with `createError()`

### Client API Calls
```typescript
// Simple fetch
const { data } = await useFetch<User[]>('/api/users')

// With TanStack Query
const { data, isLoading, error } = useQuery({
  queryKey: ['users'],
  queryFn: () => $fetch<User[]>('/api/users'),
})
```

## State Management

### Pinia Stores
- Use Setup Store syntax (Composition API)
- Keep stores focused on specific domains
- Use `readonly()` for state exposure
- Define actions for state mutations

### TanStack Query
- Use for all server state
- Define query keys consistently
- Implement proper cache invalidation
- Use mutations for data changes

## Styling Guidelines

### Tailwind CSS
- Use design tokens from shadcn-vue theme
- Mobile-first responsive design
- Use `cn()` utility for conditional classes
- Prefer semantic color names (`text-primary`, `bg-muted`)

### Dark Mode
- All components must support dark mode
- Use CSS variables for theme colors
- Test both light and dark themes

## Accessibility

- Use semantic HTML elements
- Include proper ARIA attributes
- Ensure keyboard navigation
- Maintain focus management
- Support screen readers

## Testing

**DEFAULT: Test implementation is SKIPPED to focus on feature delivery.**

Tests are only implemented when explicitly requested by the user.

### When Tests ARE Implemented

User explicitly asks with phrases like:
- "Add tests", "Write tests", "Include tests"
- "With unit tests", "With E2E tests"
- "TDD", "Test-driven development"

### Test Standards (When Requested)

- Write unit tests for composables and utilities (Vitest)
- Write component tests for UI behavior (Vitest + Vue Test Utils)
- Write E2E tests for critical user flows (Playwright)
- Use data-testid for test selectors

### Environment Override

```bash
# Force tests in CI/CD
SKIP_TESTS=false npm run build
```

## Documentation

- Document complex logic with comments
- Add JSDoc for exported functions
- Update README for new features
- Create ADRs for architecture decisions

## Do NOT

- Use Options API (Composition API only)
- Use `any` type without explicit reason
- Skip TypeScript types
- Ignore accessibility requirements
- Create components without loading/error states
- Skip form validation
- Use inline styles (use Tailwind)
