---
applyTo: "**/*.aspx, **/*.ascx, **/*.master, **/*.aspx.cs, **/*.ascx.cs, **/*.master.cs"
description: "How to read ASP.NET Web Forms pages/controls and extract every UI and validation business rule"
---

# Reading ASP.NET Web Forms (Presentation tier)

This is the **densest source of hidden rules**. Behavior is split across markup, the page lifecycle, and
event handlers that fire at different times. Anchor on this lifecycle order — ViewState and posted values
are restored **before** `Page_Load`, and control event handlers fire **after** it:

`PreInit → Init → LoadViewState → LoadPostData → Page_Load → control events (Button_Click…) → PreRender → SaveViewState → Render → Unload`

## What to extract (tick each for every page/control)

1. **`Page_Load` + `if (!IsPostBack)`** — the `!IsPostBack` branch holds *initial‑state* rules: default
   values, dropdown population (**the allowed value set IS a business rule**), pre‑selection, permission‑
   driven `Visible`/`Enabled`, record loading. The postback branch holds re‑entrancy logic. Document both.
2. **Control event handlers** — `Button_Click`, `LinkButton`/`GridView.RowCommand` (note
   `CommandName`/`CommandArgument` dispatch = a mini state machine), `SelectedIndexChanged`,
   `RowUpdating`/`RowDeleting`/`RowDataBound`, `Repeater.ItemCommand`/`ItemDataBound`. Each = an action
   rule: preconditions → validation set → effect → navigation → side effects.
3. **ASP.NET validators (in markup)** — each is a literal validation rule; decode it:
   - `RequiredFieldValidator` → field mandatory.
   - `RangeValidator` (`MinimumValue`/`MaximumValue`/`Type`) → numeric/date bounds.
   - `RegularExpressionValidator` (`ValidationExpression`) → **translate the regex into plain English**.
   - `CompareValidator` (`Operator`/`ControlToCompare`/`ValueToCompare`/`Type`) → cross‑field/type rule.
   - `CustomValidator` → **read BOTH** `ClientValidationFunction` (JS) **and** `ServerValidate` (code‑behind);
     the richest, most bespoke rules live here.
   - `ValidationGroup` → which rules fire together for which button (a transactional validation set).
   - `CausesValidation="false"` → an action that deliberately bypasses validation (a rule in itself).
4. **Data‑binding controls** — `GridView`/`DetailsView`/`FormView`/`Repeater`/`ListView`: column
   definitions, `DataFormatString` (currency/date/number formatting rules), `Visible`/`Enabled` bindings,
   `<%# Eval/Bind %>` expressions, `EmptyDataTemplate` (what "no data" means), paging/sorting defaults.
   `SqlDataSource`/`ObjectDataSource`/`EntityDataSource` markup can hold **inline SQL/parameters** — capture it.
   `RowDataBound`/`ItemDataBound` often hide **display‑derivation rules** and **row‑level authorization**.
5. **Navigation & flow** — `Response.Redirect`/`Server.Transfer`/`RedirectToRoute`/`PostBackUrl` targets and
   the **query strings** they pass (`?orderId=&mode=edit` is the workflow contract). Build a page‑transition graph.
6. **State** — `Session[...]`, `Application[...]`, `Cache[...]`, `ViewState[...]`, `<asp:HiddenField>`,
   `Request.Form[...]`, cookies. For each key: what, when set, when read, lifetime, the rule it supports
   (e.g. a wizard storing partial data in Session).
7. **Master pages & base classes** — read every `BasePage`/base user‑control and master code‑behind;
   site‑wide auth, culture, and common `Page_Load` rules live there. Menus that show/hide links by role = authz rules.
8. **Client‑side script** — inline `<script>`, `.js`, `OnClientClick`, `RegisterStartupScript`,
   `UpdatePanel`/`ScriptManager`, `PageMethods`/`[WebMethod]`/`.asmx`. **JS frequently enforces rules never
   duplicated server‑side** (masks, totals, confirm dialogs gating destructive actions). Capture each and
   flag whether it is mirrored server‑side; a client‑only rule is still a real rule (mark `[CONFLICT]` if they differ).
9. **Authorization** — `User.IsInRole(...)`, `[PrincipalPermission]`, programmatic show/hide by role, plus
   folder‑level `web.config <authorization>` (covered in config instructions). Record in the security model.

## Easy‑to‑miss traps (hunt these explicitly)
- Dynamically created controls (`new TextBox()`, `LoadControl`, `Controls.Add`) built in `Page_Init`/
  `CreateChildControls` — invisible in markup, conditional on ViewState.
- `EnableViewState="false"` regions that must re‑bind manually (the re‑bind logic = rules).
- Hidden fields / `Request.Form` reads set by JavaScript.
- Cross‑page postback via `PreviousPage`.
- `.resx` resource strings holding validation/error messages and labels.

## How to document
Produce a `SCR-<MOD>-NNN` screen spec from `specs/_templates/screen-spec.md`: purpose, actors/access,
entry parameters, controls+validation table, actions→behavior, display rules, navigation in/out with the
query‑string contract, state used. Put ViewState/postback mechanics in **Developer Notes (legacy)**. Do
**not** add Vue/target‑stack hints here — those are produced separately by `/migration-notes` into
`specs/migration/`. Emit each UI/validation rule into the module's `BR-` catalog.
