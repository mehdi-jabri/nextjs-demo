---
applyTo: "**/*.sql"
description: "How to read SQL Server stored procedures, views, functions, and triggers for business logic"
---

# Reading SQL Server programmable objects

Legacy apps push substantial business logic into the database. These objects are **invisible from C#** and are
a top source of missed rules. Read the body of every one you find (in `.sql` files, DB projects, `Scripts/`,
migration `Sql(...)` blocks, or scripted from the live DB).

## What to extract
- **Stored procedures** — pricing, eligibility, validation, batch processing. Capture parameters, the decision
  logic (`IF`/`CASE`/`WHILE`), `WHERE` filters (= business filters, e.g. "excludes cancelled orders"),
  calculations and rounding, and what they `INSERT`/`UPDATE`/`DELETE`. Emit each rule as `BR-…` with the
  `usp_Name:line` citation.
- **Views** — encode derived/joined business datasets; the `SELECT` (joins, filters, computed columns) is a set
  of derivation rules. Note which screens/reports consume them.
- **Functions (scalar/table)** — reusable calculations/derivations → `BR-… Calculation`.
- **Triggers** — audit, denormalization, cascade‑like enforcement. Often the **only** place a rule is enforced;
  capture the table, event (`AFTER`/`INSTEAD OF` INSERT/UPDATE/DELETE), and effect. Flag any rule duplicated in
  C# and SQL as a single rule with multiple enforcement points (note `[CONFLICT]` if they differ).
- **CHECK / DEFAULT / computed columns / indexes** found in scripts → data‑integrity rules and defaulting rules.

## How to document
Translate each object into plain‑language rules in the relevant module's `BR-` catalog (and reports in
`09-reports.md`). Keep the SQL itself and execution detail in **Developer Notes (legacy)**. Do **not** put
PostgreSQL/target‑stack equivalents here — those are produced separately by `/migration-notes` into
`specs/migration/`. If you only have scripts and not a live DB, mark anything you cannot confirm as live
with `[UNVERIFIED]`.
