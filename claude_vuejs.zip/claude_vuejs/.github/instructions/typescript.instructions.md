---
description: 'TypeScript standards for Nuxt 4 applications with strict typing'
applyTo: '**/*.ts'
---

# TypeScript Instructions (Nuxt 4)

## Nuxt 4 TypeScript Config Splitting

Nuxt 4 generates separate TypeScript configs for different contexts:
- `.nuxt/tsconfig.app.json` - App code (Vue components, composables)
- `.nuxt/tsconfig.server.json` - Server-side code (Nitro/server)
- `.nuxt/tsconfig.node.json` - Build-time code (modules, nuxt.config.ts)
- `.nuxt/tsconfig.shared.json` - Shared between app and server

### Using Project References

```json
// tsconfig.json (root)
{
  "files": [],
  "references": [
    { "path": "./.nuxt/tsconfig.app.json" },
    { "path": "./.nuxt/tsconfig.server.json" },
    { "path": "./.nuxt/tsconfig.shared.json" },
    { "path": "./.nuxt/tsconfig.node.json" }
  ]
}
```

### Type Augmentations

- App context types → `app/` directory
- Server context types → `server/` directory
- Shared types → `shared/` directory

## Strict Typing

- Enable strict mode in tsconfig
- No `any` types without explicit justification
- Define interfaces for all data structures
- Export types from `types/` directory

## Naming Conventions

```typescript
// Interfaces: PascalCase with descriptive names
interface UserProfile {
  id: string
  name: string
}

// Types: PascalCase
type UserRole = 'admin' | 'user' | 'guest'

// Functions: camelCase with verb prefix
function getUserById(id: string): Promise<User> {}

// Constants: SCREAMING_SNAKE_CASE
const MAX_RETRIES = 3

// Composables: camelCase with 'use' prefix
function useCounter() {}
```

## Error Handling

```typescript
// Always use typed errors
class AppError extends Error {
  constructor(
    message: string,
    public code: string,
    public statusCode?: number
  ) {
    super(message)
  }
}

// Use Result pattern for expected failures
type Result<T, E = Error> = 
  | { success: true; data: T }
  | { success: false; error: E }
```

## Async Patterns

```typescript
// Prefer async/await over .then()
async function fetchData(): Promise<Data> {
  try {
    const response = await $fetch<Data>('/api/data')
    return response
  } catch (error) {
    throw new AppError('Failed to fetch', 'FETCH_ERROR', 500)
  }
}
```

## Imports

- Use absolute imports with `@/` alias
- Group imports: external → internal → types
- Use type-only imports when appropriate

```typescript
import type { User } from '@/types/user'
```
